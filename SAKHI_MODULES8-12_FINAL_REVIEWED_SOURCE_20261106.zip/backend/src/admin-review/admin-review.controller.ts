import {
  Body,
  Controller,
  Delete,
  Get,
  Headers,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Put,
  Query,
  Res,
} from "@nestjs/common";
import type { Response } from "express";
import { DevelopmentMemberStateDto } from "./admin-member-state.dto.js";
import { ManualEligibilityDecisionDto } from "./admin-review.dto.js";
import { AdminReviewService } from "./admin-review.service.js";

function extractBearerHeader(authorization?: string): string | undefined {
  if (!authorization) return undefined;
  const trimmed = authorization.trim();
  if (/^Bearer\s+/i.test(trimmed)) {
    return trimmed.replace(/^Bearer\s+/i, "").trim() || undefined;
  }
  return undefined;
}

function pickAdminToken(
  primary?: string,
  fallback?: string,
  stagingSession?: string,
  authorizationHeader?: string,
): string | undefined {
  return (
    primary?.trim() ||
    fallback?.trim() ||
    stagingSession?.trim() ||
    extractBearerHeader(authorizationHeader) ||
    undefined
  );
}

@Controller("admin-review")
export class AdminReviewController {
  constructor(private readonly adminReview: AdminReviewService) {}

  @Get("session")
  session(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.session(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("rbac-profile")
  rbacProfile(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.rbacProfile(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("staff-login")
  @HttpCode(200)
  staffLogin(
    @Body() body: { token?: string },
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.rbacProfile(
      body?.token?.trim() ||
        pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("staff")
  listAdminStaff(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.listAdminStaff(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("staff")
  @HttpCode(201)
  createAdminStaff(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.createAdminStaff(
      body as any,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("staff/:staffId")
  updateAdminStaff(
    @Param("staffId") staffId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updateAdminStaff(
      staffId,
      body as any,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Delete("staff/:staffId")
  deleteAdminStaff(
    @Param("staffId") staffId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.deleteAdminStaff(
      staffId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("platform-config")
  getPlatformConfig(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.getPlatformConfig(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Put("platform-config")
  updatePlatformConfig(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updatePlatformConfig(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("businesses")
  listBusinesses(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.listBusinesses(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("businesses")
  @HttpCode(201)
  upsertBusiness(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.upsertBusiness(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("businesses/:businessId/review")
  reviewBusiness(
    @Param("businessId") businessId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.reviewBusiness(
      businessId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Delete("businesses/:businessId")
  deleteBusiness(
    @Param("businessId") businessId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.deleteBusiness(
      businessId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("registration-policy")
  getRegistrationPolicy(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.getRegistrationPolicy(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Put("registration-policy")
  updateRegistrationPolicy(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updateRegistrationPolicy(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("queue")
  queue(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.queue(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("history")
  history(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.history(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("members")
  members(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
    @Query("search") search?: string,
    @Query("accountStatus") accountStatus?: string,
    @Query("verificationStatus") verificationStatus?: string,
  ) {
    return this.adminReview.members(
      pickAdminToken(token, altToken, stagingSessionToken),
      page,
      pageSize,
      search,
      accountStatus,
      verificationStatus,
    );
  }

  @Post("members")
  @HttpCode(201)
  createMember(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.createMember(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("members/:accountId")
  memberDetail(
    @Param("accountId", new ParseUUIDPipe()) accountId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.getMember360Detail(
      accountId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("members/:accountId/state")
  updateMemberState(
    @Param("accountId", new ParseUUIDPipe()) accountId: string,
    @Body() dto: DevelopmentMemberStateDto,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updateMemberState(
      accountId,
      dto,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("members/:accountId/state")
  @HttpCode(201)
  updateMemberStatePost(
    @Param("accountId", new ParseUUIDPipe()) accountId: string,
    @Body() dto: DevelopmentMemberStateDto,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updateMemberState(
      accountId,
      dto,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("members/:accountId/eligibility-override")
  overrideMemberEligibility(
    @Param("accountId", new ParseUUIDPipe()) accountId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.overrideMemberEligibilityAndState(
      accountId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("members/:accountId/eligibility-override")
  @HttpCode(200)
  overrideMemberEligibilityPost(
    @Param("accountId", new ParseUUIDPipe()) accountId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.overrideMemberEligibilityAndState(
      accountId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("submissions/:submissionId/decision")
  @HttpCode(200)
  decide(
    @Param("submissionId", new ParseUUIDPipe()) submissionId: string,
    @Body() dto: ManualEligibilityDecisionDto,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.decide(
      submissionId,
      dto,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("seed-live")
  @HttpCode(200)
  seedLiveData(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.seedLiveData(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("community")
  communityOverview(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.communityOverview(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("community/posts")
  @HttpCode(201)
  createAdminPost(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.createAdminPost(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Delete("community/posts/:postId")
  deleteAdminPost(
    @Param("postId") postId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.deleteAdminPost(
      postId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Put("categories/:slug")
  updateCategoryConfig(
    @Param("slug") slug: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.updateCategoryConfig(
      slug,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("moderation/reports/:reportId/decision")
  @HttpCode(200)
  resolveReport(
    @Param("reportId") reportId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.resolveReport(
      reportId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("reports/:reportId/resolve")
  @HttpCode(200)
  resolveReportAlias(
    @Param("reportId") reportId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.resolveReport(
      reportId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("moderation/reports/:reportId/triage")
  triageReport(
    @Param("reportId") reportId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.triageReport(
      reportId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Patch("reports/:reportId/triage")
  triageReportAlias(
    @Param("reportId") reportId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.triageReport(
      reportId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("moderation/reports/:reportId")
  getReportDetail(
    @Param("reportId") reportId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.getReportDetail(
      reportId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("media/:uploadId/preview")
  async previewMediaForModeration(
    @Param("uploadId") uploadId: string,
    @Res() response: Response,
    @Headers("authorization") authorizationHeader?: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    const resolvedToken = pickAdminToken(
      token,
      altToken,
      stagingSessionToken,
      authorizationHeader,
    );
    const media = await this.adminReview.previewReportedMedia(
      uploadId,
      resolvedToken,
    );
    response.setHeader("Content-Type", media.contentType);
    response.setHeader("Cache-Control", "private, no-store, max-age=0");
    response.setHeader("X-Content-Type-Options", "nosniff");
    return response.status(200).send(media.buffer);
  }

  @Get("wellness-resources")
  listWellnessResources(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.listWellnessResources(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("wellness-resources")
  @HttpCode(201)
  upsertWellnessResource(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.upsertWellnessResource(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Delete("wellness-resources/:resourceId")
  deleteWellnessResource(
    @Param("resourceId") resourceId: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.deleteWellnessResource(
      resourceId,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("moderation/posts/:postId/action")
  @HttpCode(200)
  moderatePost(
    @Param("postId") postId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.moderatePost(
      postId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("moderation/comments/:commentId/action")
  @HttpCode(200)
  moderateComment(
    @Param("commentId") commentId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.moderateComment(
      commentId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("operations")
  operationsOverview(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.operationsOverview(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Get("safety-console")
  safetyConsoleOverview(
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.safetyConsoleOverview(
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("police-stations")
  @HttpCode(201)
  upsertPoliceStation(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.upsertPoliceStation(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("police-stations/sync-osm")
  @HttpCode(200)
  syncPoliceStationsFromOsm(
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.syncPoliceStationsFromOsm(
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Delete("police-stations/:stationCode")
  deletePoliceStation(
    @Param("stationCode") stationCode: string,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.deletePoliceStation(
      stationCode,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }

  @Post("sos-events/:eventId/review")
  @HttpCode(200)
  reviewSosEvent(
    @Param("eventId") eventId: string,
    @Body() body: Record<string, unknown>,
    @Headers("x-sakhi-admin-token") token?: string,
    @Headers("x-sakhi-admin-review-token") altToken?: string,
    @Headers("x-sakhi-staging-admin-session") stagingSessionToken?: string,
  ) {
    return this.adminReview.reviewSosEvent(
      eventId,
      body,
      pickAdminToken(token, altToken, stagingSessionToken),
    );
  }
}
