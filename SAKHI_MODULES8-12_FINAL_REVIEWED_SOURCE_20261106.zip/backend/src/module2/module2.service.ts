import { SakhiAdminRbacRegistry } from "../admin-review/admin-rbac.helper.js";
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
  Optional,
  ServiceUnavailableException,
} from "@nestjs/common";
import { randomUUID } from "node:crypto";
import { AuthenticationService } from "../auth/auth.service.js";
import { PrismaService } from "../database/prisma.service.js";
import { GoogleDriveStorageService } from "./google-drive-storage.service.js";
import type {
  CreateCommunityPostDto,
  CreateEmergencyContactDto,
  CreatePostCommentDto,
  RecordSafetyEventDto,
  StartLocationShareDto,
  UpdateEmergencyContactDto,
  ReportUserOrPostDto,
  RequestMediaUploadDto,
  ToggleBlockedUserDto,
  ToggleTwoFactorDto,
  UpdateAvatarDto,
  UpdateModule2ProfileDto,
  UpdateNotificationPreferenceDto,
  UpdatePrivacyPreferenceDto,
  UpdateSecurityPinDto,
  UploadMediaObjectDto,
  UploadBinaryMediaDto,
} from "./module2.dto.js";

function hasValidCoordinatePair(
  latitude: unknown,
  longitude: unknown,
): boolean {
  return (
    typeof latitude === "number" &&
    Number.isFinite(latitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    typeof longitude === "number" &&
    Number.isFinite(longitude) &&
    longitude >= -180 &&
    longitude <= 180
  );
}

const DEFAULT_INTERESTS = [
  "Mental Wellness",
  "Travel",
  "Reading",
  "WomenInTech",
  "Art",
  "Fitness",
];

export const LEGACY_SEEDED_DEMO_PHONES = [
  "+919999992222",
  "+919845010101",
  "+919845010102",
  "+919845010103",
  "+919845010104",
  "+919845010105",
  "+919845010106",
  "+919845010107",
];

export const LEGACY_SEEDED_DEMO_HANDLES = [
  "@siddhu",
  "@ananya",
  "@meera",
  "@kavya",
  "@ishita",
  "@priya",
  "@sneha",
  "@riya",
];

export const LEGACY_SEEDED_DEMO_POST_IDS = [
  "11111111-1111-4111-8111-111111111101",
  "11111111-1111-4111-8111-111111111102",
  "11111111-1111-4111-8111-111111111103",
  "11111111-1111-4111-8111-111111111104",
  "11111111-1111-4111-8111-111111111105",
  "11111111-1111-4111-8111-111111111106",
  "11111111-1111-4111-8111-111111111107",
  "11111111-1111-4111-8111-111111111108",
  "11111111-1111-4111-8111-111111111109",
  "11111111-1111-4111-8111-111111111110",
  "11111111-1111-4111-8111-111111111111",
];

export const SEEDED_COMMUNITY_MEMBERS: Array<{
  phoneE164: string;
  displayName: string;
  username: string;
  avatarAsset: string;
  bio: string;
  location: string;
  email: string;
  status: "ACTIVE" | "PENDING_VERIFICATION";
  verificationStatus: "VERIFIED" | "UNVERIFIED";
  defaultFollowing: boolean;
  interests: string[];
}> = [];

@Injectable()
export class Module2Service {
  private static readonly commentLikesMap = new Map<string, Set<string>>();
  private static readonly postPollMetaMap = new Map<string, { question: string; options: string[]; votes: Record<string, number> }>();
  private static readonly postExtraMediaMap = new Map<string, string[]>();
  private static readonly dmRateLimitBuckets = new Map<string, number[]>();

  private normalizeModerationHandle(value: unknown): string {
    return typeof value === "string"
      ? value.trim().replace(/^@+/, "").toLowerCase()
      : "";
  }

  private buildHandleVariants(value: string): string[] {
    const raw = (value ?? "").trim();
    const clean = raw.replace(/^@+/, "");
    const lower = clean.toLowerCase();
    return Array.from(
      new Set([raw, clean, `@${clean}`, lower, `@${lower}`].filter(Boolean)),
    );
  }

  private parseStringArrayJson(raw: unknown): string[] {
    if (!Array.isArray(raw)) return [];
    return raw
      .map((item) => (typeof item === "string" ? item.trim() : String(item ?? "").trim()))
      .filter(Boolean);
  }

  private async resolveViewerModerationContext(
    accountId: string,
    viewerUsername?: string | null,
    preloadedOutgoingBlocks?: Array<{ blockedUsername: string }>,
  ) {
    const anyPrisma = this.prisma as Record<string, any>;
    const normViewer = this.normalizeModerationHandle(viewerUsername ?? "");
    const viewerVariants = normViewer ? this.buildHandleVariants(normViewer) : [];

    const [outgoingBlocks, incomingBlocks, userReports, privacyPref] = await Promise.all([
      preloadedOutgoingBlocks
        ? Promise.resolve(preloadedOutgoingBlocks)
        : typeof anyPrisma.memberModerationBlock?.findMany === "function"
          ? anyPrisma.memberModerationBlock
              .findMany({
                where: { accountId },
                select: { blockedUsername: true },
              })
              .catch(() => [])
          : Promise.resolve([]),
      viewerVariants.length > 0 &&
      typeof anyPrisma.memberModerationBlock?.findMany === "function"
        ? anyPrisma.memberModerationBlock
            .findMany({
              where: { blockedUsername: { in: viewerVariants } },
              select: { accountId: true },
            })
            .catch(() => [])
        : Promise.resolve([]),
      typeof anyPrisma.memberUserReport?.findMany === "function"
        ? anyPrisma.memberUserReport
            .findMany({
              where: { reporterAccountId: accountId },
              select: { postId: true, commentId: true, targetHandle: true, targetType: true },
            })
            .catch(() => [])
        : Promise.resolve([]),
      typeof anyPrisma.memberPrivacyPreference?.findUnique === "function"
        ? anyPrisma.memberPrivacyPreference
            .findUnique({
              where: { accountId },
            })
            .catch(() => null)
        : Promise.resolve(null),
    ]);

    const blockedHandles = new Set<string>();
    for (const b of outgoingBlocks as Array<Record<string, any>>) {
      const h = this.normalizeModerationHandle(b?.blockedUsername);
      if (h) blockedHandles.add(h);
    }

    const accountsWhoBlockedViewer = new Set<string>();
    for (const ib of incomingBlocks as Array<Record<string, any>>) {
      if (ib?.accountId) accountsWhoBlockedViewer.add(String(ib.accountId));
    }

    const reportedPostIds = new Set<string>();
    const reportedCommentIds = new Set<string>();
    for (const r of userReports as Array<Record<string, any>>) {
      if (typeof r?.postId === "string" && r.postId.trim()) {
        reportedPostIds.add(r.postId.trim());
      }
      if (typeof r?.commentId === "string" && r.commentId.trim()) {
        reportedCommentIds.add(r.commentId.trim());
      }
    }

    const mutedHandles = new Set<string>(
      this.parseStringArrayJson(privacyPref?.mutedHandles).map((h) =>
        this.normalizeModerationHandle(h),
      ).filter(Boolean),
    );
    const restrictedHandles = new Set<string>(
      this.parseStringArrayJson(privacyPref?.restrictedHandles).map((h) =>
        this.normalizeModerationHandle(h),
      ).filter(Boolean),
    );
    const hiddenPostIds = new Set<string>(
      this.parseStringArrayJson(privacyPref?.hiddenPostIds),
    );

    return {
      blockedHandles,
      accountsWhoBlockedViewer,
      reportedPostIds,
      reportedCommentIds,
      mutedHandles,
      restrictedHandles,
      hiddenPostIds,
    };
  }

  private isNotificationCategoryAllowedByPreferences(
    category: string,
    pref: Record<string, any> | null,
  ): boolean {
    if (!pref) return true;
    const cat = (category ?? "").toUpperCase();
    if (cat === "DIRECT_MESSAGE") return pref.messages !== false;
    if (cat === "BUSINESS_ENQUIRY") return pref.businessEnquiries !== false;
    if (cat === "PERIOD_REMINDER" || cat === "WELLNESS_REMINDER") {
      return pref.wellnessReminders !== false;
    }
    if (cat === "EMERGENCY_CONTACT_ALERT" || cat === "SOS_UPDATE") {
      return pref.safetyAlerts !== false;
    }
    if (cat === "COMMUNITY_ANNOUNCEMENT" || cat === "COMMUNITY_REPLIES_LIKES" || cat === "NEW_FOLLOWER") {
      return pref.communityUpdates !== false;
    }
    return true;
  }

  async createPersistentNotification(
    accountId: string,
    notification: {
      id?: string;
      category: string;
      title: string;
      body: string;
      discreetTitle?: string | null;
      discreetBody?: string | null;
      deepLink?: string | null;
      actorHandle?: string | null;
      actorName?: string | null;
      actorAvatar?: string | null;
      metadata?: Record<string, any>;
      idempotencyKey?: string | null;
      createdAt?: Date | string;
    },
  ) {
    if (!accountId) return null;
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.memberNotification?.create !== "function") {
      throw new ServiceUnavailableException(
        "Notification storage is not initialized. Run the Module 8 database migration.",
      );
    }

    const notifPref =
      typeof anyPrisma.memberNotificationPreference?.findUnique === "function"
        ? await anyPrisma.memberNotificationPreference
            .findUnique({ where: { accountId } })
            .catch(() => null)
        : null;
    if (!this.isNotificationCategoryAllowedByPreferences(notification.category, notifPref)) {
      return null;
    }

    const cleanKey = notification.idempotencyKey?.trim() || null;
    const createdAtDate =
      notification.createdAt instanceof Date
        ? notification.createdAt
        : notification.createdAt
          ? new Date(String(notification.createdAt))
          : new Date();

    const payload = {
      accountId,
      category: notification.category.trim().slice(0, 48),
      title: notification.title.trim().slice(0, 160),
      body: notification.body.trim().slice(0, 500),
      discreetTitle: notification.discreetTitle
        ? notification.discreetTitle.trim().slice(0, 160)
        : null,
      discreetBody: notification.discreetBody
        ? notification.discreetBody.trim().slice(0, 500)
        : null,
      deepLink: (notification.deepLink ?? "/notifications-inbox").trim().slice(0, 255),
      actorHandle: notification.actorHandle
        ? notification.actorHandle.trim().slice(0, 80)
        : null,
      actorName: notification.actorName
        ? notification.actorName.trim().slice(0, 100)
        : null,
      actorAvatar: notification.actorAvatar
        ? notification.actorAvatar.trim().slice(0, 255)
        : null,
      metadata: notification.metadata ?? {},
      idempotencyKey: cleanKey,
      deliveryStatus: "DELIVERED",
      createdAt: createdAtDate,
    };

    if (cleanKey && typeof anyPrisma.memberNotification?.upsert === "function") {
      return anyPrisma.memberNotification.upsert({
        where: { idempotencyKey: cleanKey },
        create: {
          id: notification.id && /^[0-9a-fA-F-]{36}$/.test(notification.id) ? notification.id : randomUUID(),
          ...payload,
          isRead: false,
          readAt: null,
        },
        update: {
          title: payload.title,
          body: payload.body,
          discreetTitle: payload.discreetTitle,
          discreetBody: payload.discreetBody,
          deepLink: payload.deepLink,
        },
      });
    }

    if (cleanKey && typeof anyPrisma.memberNotification?.findFirst === "function") {
      const existing = await anyPrisma.memberNotification.findFirst({
        where: { idempotencyKey: cleanKey },
      });
      if (existing) return existing;
    }

    return anyPrisma.memberNotification.create({
      data: {
        id: notification.id && /^[0-9a-fA-F-]{36}$/.test(notification.id) ? notification.id : randomUUID(),
        ...payload,
        isRead: false,
        readAt: null,
      },
    });
  }

  private groupThreadedComments<T extends Record<string, any>>(
    flat: T[],
  ): T[] {
    if (flat.length <= 1) return flat;
    const byId = new Map<string, T>();
    for (const c of flat) {
      byId.set(c.id, c);
    }
    const childrenByParent = new Map<string, T[]>();
    const roots: T[] = [];
    for (const c of flat) {
      const pid = c.parentCommentId ? String(c.parentCommentId).trim() : "";
      if (pid && byId.has(pid) && pid !== c.id) {
        const list = childrenByParent.get(pid) ?? [];
        list.push(c);
        childrenByParent.set(pid, list);
      } else {
        roots.push(c);
      }
    }
    const ordered: T[] = [];
    const visited = new Set<string>();
    const visit = (node: T) => {
      if (visited.has(node.id)) return;
      visited.add(node.id);
      ordered.push(node);
      const kids = childrenByParent.get(node.id) ?? [];
      for (const k of kids) {
        visit(k);
      }
    };
    for (const r of roots) {
      visit(r);
    }
    for (const c of flat) {
      if (!visited.has(c.id)) {
        ordered.push(c);
      }
    }
    return ordered;
  }
  constructor(
    private readonly auth: AuthenticationService,
    private readonly prisma: PrismaService,
    private readonly googleDrive: GoogleDriveStorageService = new GoogleDriveStorageService(),
  ) {}

  private formatRelativeTime(createdAt: Date): string {
    const diffMs = Math.max(0, Date.now() - createdAt.getTime());
    const minutes = Math.floor(diffMs / 60_000);
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} ${hours === 1 ? "hour" : "hours"} ago`;
    const days = Math.floor(hours / 24);
    return `${days} ${days === 1 ? "day" : "days"} ago`;
  }

  private maskPhone(phoneE164: string): string {
    if (phoneE164.startsWith("+91") && phoneE164.length >= 7) {
      return `+91 ••••••${phoneE164.slice(-4)}`;
    }
    return phoneE164.length > 4 ? `••••••${phoneE164.slice(-4)}` : phoneE164;
  }

  private parseInterests(raw: unknown): string[] {
    if (!Array.isArray(raw)) return [];
    return raw
      .filter((item): item is string => typeof item === "string")
      .map((item) => item.trim())
      .filter((item) => item.length > 0);
  }

  private resolveMemberAvatar(
    avatarAsset?: string | null,
    avatarMediaAssetId?: string | null,
  ): string {
    const asset = (avatarAsset ?? "").trim();
    if (!asset) return "";
    if (
      asset.startsWith("http://") ||
      asset.startsWith("https://") ||
      asset.startsWith("/api/v1/") ||
      asset.startsWith("assets/")
    ) {
      return asset;
    }
    if (avatarMediaAssetId) return asset;
    return asset;
  }

  private deriveUsername(
    displayName: string,
    existingUsername?: string | null,
  ): string {
    if (existingUsername && existingUsername.trim().length > 0) {
      return existingUsername.startsWith("@")
        ? existingUsername.trim()
        : `@${existingUsername.trim()}`;
    }
    const slug = displayName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "")
      .slice(0, 20);
    return `@${slug || "member"}`;
  }

  private static demoDataPurged = false;

  async purgeLegacySeededDemoData(): Promise<void> {
    if (Module2Service.demoDataPurged) return;
    try {
      const demoPostIds = [
        "11111111-1111-4111-8111-111111111101",
        "11111111-1111-4111-8111-111111111102",
        "11111111-1111-4111-8111-111111111103",
        "11111111-1111-4111-8111-111111111104",
        "11111111-1111-4111-8111-111111111105",
        "11111111-1111-4111-8111-111111111106",
        "11111111-1111-4111-8111-111111111107",
        "11111111-1111-4111-8111-111111111108",
        "11111111-1111-4111-8111-111111111109",
        "11111111-1111-4111-8111-111111111110",
        "11111111-1111-4111-8111-111111111111",
      ];
      const demoHandles = LEGACY_SEEDED_DEMO_HANDLES;
      const demoPhones = LEGACY_SEEDED_DEMO_PHONES;

      // 1. Delete all demo posts
      await this.prisma.communityPost.deleteMany({
        where: {
          OR: [
            { id: { in: demoPostIds } },
            { authorUsername: { in: demoHandles } },
          ],
        },
      }).catch(() => undefined);

      // 2. Find and delete demo accounts and all their related rows
      const demoAccounts = await this.prisma.memberAccount.findMany({
        where: { phoneE164: { in: demoPhones } },
        select: { id: true },
      }).catch(() => []);
      const demoAccountIds = demoAccounts.map((a) => a.id);

      if (demoAccountIds.length > 0) {
        await this.prisma.communityPostComment.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.communityPostLike.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.communityPostSave.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.memberFollow.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.communityPost.deleteMany({
          where: { authorAccountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.eligibilitySubmission.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.memberProfile.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.memberPrivacyPreference.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.memberNotificationPreference.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.authSession.deleteMany({
          where: { accountId: { in: demoAccountIds } },
        }).catch(() => undefined);
        await this.prisma.memberAccount.deleteMany({
          where: { id: { in: demoAccountIds } },
        }).catch(() => undefined);
      }

      // 3. Delete demo directory profiles
      await this.prisma.communityDirectoryProfile.deleteMany({
        where: { username: { in: demoHandles } },
      }).catch(() => undefined);

      Module2Service.demoDataPurged = true;
    } catch {
      // Best-effort database purge
    }
  }

  async ensureDefaultCatalogSeeded(_preferredAccountId?: string): Promise<void> {
    // 1. Ensure 4 active Community Groups exist with real database member counts (no fake 1.4k numbers)
    const activeVerifiedCount = Math.max(
      1,
      await this.prisma.memberAccount
        .count({ where: { status: "ACTIVE" } })
        .catch(() => 1),
    );
    const defaultGroups = [
      {
        name: "Women in Tech",
        description: "System design, cloud careers & peer mentorship",
        category: "Education & Career",
        membersCount: 0,
        newPostsToday: 0,
      },
      {
        name: "Mindful Mornings Circle",
        description: "Daily breathwork & emotional grounding",
        category: "Health & Wellness",
        membersCount: 0,
        newPostsToday: 0,
      },
      {
        name: "Safe Solo Travelers",
        description: "Verified city guides & SOS check-in buddies",
        category: "Safety & Travel",
        membersCount: 0,
        newPostsToday: 0,
      },
      {
        name: "Hormonal & Cycle Wellness Hub",
        description: "Doctor Q&As, cycle nutrition & wellness routines",
        category: "Health & Wellness",
        membersCount: 0,
        newPostsToday: 0,
      },
    ];
    for (const group of defaultGroups) {
      await this.prisma.communityGroup.upsert({
        where: { name: group.name },
        update: {},
        create: group,
      });
    }

    // 2. Ensure Wellness Resources exist
    const defaultWellness = [
      {
        slug: "menstrual-health",
        category: "menstrual_health",
        title: "Menstrual Health",
        subtitle: "Cycle care guides, symptom tracking & doctor Q&As",
        durationLabel: "4 guides",
        thumbAsset: "assets/images/wellness/wellness_hero_illustration.webp",
      },
      {
        slug: "mental-wellness",
        category: "mental_wellness",
        title: "Mental Wellness",
        subtitle: "Daily grounding rituals, stress relief & peer support",
        durationLabel: "6 exercises",
        thumbAsset:
          "assets/images/community/breathing_exercise_illustration.webp",
      },
      {
        slug: "fitness-nutrition",
        category: "fitness_nutrition",
        title: "Fitness & Nutrition",
        subtitle: "Balanced strength routines & nourishing meal ideas",
        durationLabel: "5 plans",
        thumbAsset: "assets/images/wellness/wellness_hero_illustration.webp",
      },
      {
        slug: "expert-articles",
        category: "expert_articles",
        title: "Expert Articles",
        subtitle: "Evidence-based women's health & safety columns",
        durationLabel: "8 articles",
        thumbAsset: "assets/images/wellness/wellness_hero_illustration.webp",
      },
      {
        slug: "guided-meditation-pick",
        category: "todays_pick",
        title: "Guided Meditation",
        subtitle: "10 min • Audio",
        durationLabel: "10 min • Audio",
        thumbAsset: "assets/images/wellness/guided_meditation_thumb.webp",
      },
    ];
    for (const item of defaultWellness) {
      await this.prisma.wellnessResource.upsert({
        where: { slug: item.slug },
        update: {},
        create: item,
      });
    }
  }

  async publicFeed(authorization?: string) {
    // This route is retained for compatibility, but media/feed data is never public
    // by omission: use the same authenticated visibility-filtered query as bootstrap.
    const data = await this.bootstrap(authorization);
    return {
      source: data.source,
      totalDatabaseMembers: data.totalDatabaseMembers,
      totalDatabasePosts: data.totalDatabasePosts,
      communityPosts: data.communityPosts,
      exploreRecommendedPosts: data.exploreRecommendedPosts,
      groups: data.groups,
      followers: data.followers,
      wellnessResources: data.wellnessResources,
    };
  }

  async bootstrap(authorization?: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    await this.purgeLegacySeededDemoData().catch(() => undefined);
    await this.ensureDefaultCatalogSeeded().catch(() => undefined);

    const [
      profile,
      privacyPref,
      notificationPref,
      allPosts,
      ownedProfilePosts,
      ownedProfilePostCount,
      totalDatabasePosts,
      userLikes,
      userSaves,
      directoryProfiles,
      userFollows,
      groups,
      wellnessResources,
      emergencyContacts,
      blockedUsers,
      activeSessionsCount,
      totalDatabaseMembers,
    ] = await Promise.all([
      this.prisma.memberProfile.findUnique({
        where: { accountId: session.accountId },
      }),
      this.prisma.memberPrivacyPreference.findUnique({
        where: { accountId: session.accountId },
      }),
      this.prisma.memberNotificationPreference.findUnique({
        where: { accountId: session.accountId },
      }),
      this.prisma.communityPost.findMany({
        where: {
          deletedAt: null,
          status: { in: ["PUBLISHED", "EDITED"] },
          NOT: [
            { id: { in: LEGACY_SEEDED_DEMO_POST_IDS } },
            { authorUsername: { in: LEGACY_SEEDED_DEMO_HANDLES } },
          ],
        },
        include: {
          mediaAssets: {
            where: { deletedAt: null, status: "ATTACHED" },
            select: { contentType: true },
            take: 1,
          },
        },
        orderBy: { createdAt: "desc" },
        take: 50,
      }),
      this.prisma.communityPost.findMany({
        where: {
          authorAccountId: session.accountId,
          deletedAt: null,
          status: { in: ["PUBLISHED", "EDITED"] },
          NOT: [
            { id: { in: LEGACY_SEEDED_DEMO_POST_IDS } },
          ],
        },
        include: {
          mediaAssets: {
            where: { deletedAt: null, status: "ATTACHED" },
            select: { contentType: true },
            take: 1,
          },
        },
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      this.prisma.communityPost.count({
        where: {
          authorAccountId: session.accountId,
          deletedAt: null,
          status: { in: ["PUBLISHED", "EDITED"] },
          NOT: [
            { id: { in: LEGACY_SEEDED_DEMO_POST_IDS } },
          ],
        },
      }),
      this.prisma.communityPost.count({
        where: {
          deletedAt: null,
          status: { in: ["PUBLISHED", "EDITED"] },
          NOT: [
            { id: { in: LEGACY_SEEDED_DEMO_POST_IDS } },
            { authorUsername: { in: LEGACY_SEEDED_DEMO_HANDLES } },
          ],
        },
      }),
      this.prisma.communityPostLike.findMany({
        where: { accountId: session.accountId },
        select: { postId: true },
      }),
      this.prisma.communityPostSave.findMany({
        where: { accountId: session.accountId },
        select: { postId: true },
      }),
      this.prisma.communityDirectoryProfile.findMany({
        where: {
          username: { notIn: LEGACY_SEEDED_DEMO_HANDLES },
        },
        orderBy: { createdAt: "asc" },
      }),
      this.prisma.memberFollow.findMany({
        where: { accountId: session.accountId },
      }),
      this.prisma.communityGroup.findMany({
        orderBy: { membersCount: "desc" },
      }),
      this.prisma.wellnessResource.findMany({
        orderBy: { createdAt: "asc" },
      }),
      this.prisma.safetyEmergencyContact.findMany({
        where: { accountId: session.accountId },
        orderBy: { createdAt: "asc" },
      }),
      this.prisma.memberModerationBlock.findMany({
        where: { accountId: session.accountId },
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.authSession.count({
        where: {
          accountId: session.accountId,
          revokedAt: null,
          expiresAt: { gt: new Date() },
        },
      }),
      this.prisma.memberAccount.count({
        where: {
          phoneE164: { notIn: LEGACY_SEEDED_DEMO_PHONES },
        },
      }),
    ]);

    const likedSet = new Set(userLikes.map((item) => item.postId));
    const savedSet = new Set(userSaves.map((item) => item.postId));
    const followMap = new Map(
      userFollows.map((item) => [item.directoryProfileId, item.isFollowing]),
    );

    const activeFollowingCount = userFollows.filter(
      (follow) => follow.isFollowing,
    ).length;
    const currentUsername = this.deriveUsername(
      profile?.displayName ?? "Sakhi Member",
      profile?.username,
    );
    const normalizeHandle = (val: string) =>
      val.trim().replace(/^@+/, "").toLowerCase();
    const currentDirectoryProfile = directoryProfiles.find(
      (directoryProfile) =>
        normalizeHandle(directoryProfile.username) ===
        normalizeHandle(currentUsername),
    );
    const incomingFollowerRows =
      currentDirectoryProfile &&
      typeof (this.prisma.memberFollow as Record<string, any>)?.findMany ===
        "function"
        ? await this.prisma.memberFollow
            .findMany({
              where: {
                directoryProfileId: currentDirectoryProfile.id,
                isFollowing: true,
              },
              include: {
                account: {
                  include: { profile: true },
                },
              },
            })
            .catch(() => [])
        : [];
    const incomingFollowerHandles = new Set<string>();
    for (const row of incomingFollowerRows as Array<Record<string, any>>) {
      const rowUsername = row?.account?.profile?.username;
      if (typeof rowUsername === "string" && rowUsername.trim().length > 0) {
        incomingFollowerHandles.add(normalizeHandle(rowUsername));
      }
    }
    const activeFollowersCount = currentDirectoryProfile
      ? await this.prisma.memberFollow
          .count({
            where: {
              directoryProfileId: currentDirectoryProfile.id,
              isFollowing: true,
            },
          })
          .catch(() => incomingFollowerHandles.size)
      : 0;

    const moderationCtx = await this.resolveViewerModerationContext(
      session.accountId,
      currentUsername,
      blockedUsers,
    );

    const mappedFollowers = directoryProfiles
      .filter(
        (dir) =>
          normalizeHandle(dir.username) !== normalizeHandle(currentUsername) &&
          !moderationCtx.blockedHandles.has(normalizeHandle(dir.username)),
      )
      .map((dir) => {
        const isFollowing = followMap.has(dir.id)
          ? followMap.get(dir.id)!
          : dir.defaultFollowing;
        const followsMe = incomingFollowerHandles.has(
          normalizeHandle(dir.username),
        );
        return {
          id: dir.id,
          name: dir.name,
          username: dir.username,
          avatarAsset: this.resolveMemberAvatar(dir.avatarAsset),
          bio: dir.bio,
          isFollowing,
          followsMe,
        };
      });

    const isViewerVerified =
      session.account.verificationStatus === "VERIFIED" ||
      session.testAccessApproved === true;
    const followedDirectoryIds = new Set(
      userFollows
        .filter((follow) => follow.isFollowing)
        .map((follow) => follow.directoryProfileId),
    );
    const directoryIdByUsername = new Map(
      directoryProfiles.map((directoryProfile) => [
        directoryProfile.username,
        directoryProfile.id,
      ]),
    );
    const canViewPost = (post: (typeof allPosts)[number]) => {
      if (
        moderationCtx.reportedPostIds.has(post.id) ||
        moderationCtx.hiddenPostIds.has(post.id)
      ) {
        return false;
      }
      const authorNorm = normalizeHandle(post.authorUsername ?? "");
      if (
        moderationCtx.blockedHandles.has(authorNorm) ||
        moderationCtx.mutedHandles.has(authorNorm)
      ) {
        return false;
      }
      if (
        post.authorAccountId &&
        moderationCtx.accountsWhoBlockedViewer.has(post.authorAccountId)
      ) {
        return false;
      }
      if (post.authorAccountId === session.accountId) return true;
      if (post.visibility === "PRIVATE_SELF") return false;
      if (post.visibility === "FOLLOWERS_ONLY") {
        const ownerDirectoryId = directoryIdByUsername.get(post.authorUsername);
        return Boolean(
          isViewerVerified &&
          ownerDirectoryId &&
          followedDirectoryIds.has(ownerDirectoryId),
        );
      }
      return isViewerVerified;
    };
    const allPostIds = Array.from(
      new Set([...allPosts.map((p) => p.id), ...ownedProfilePosts.map((p) => p.id)]),
    );
    const anyPrismaBoot = this.prisma as Record<string, any>;
    const [allPostReactions, allPostComments] = await Promise.all([
      anyPrismaBoot.communityPostReaction?.findMany && allPostIds.length > 0
        ? anyPrismaBoot.communityPostReaction
            .findMany({ where: { postId: { in: allPostIds } } })
            .catch(() => [])
        : Promise.resolve([]),
      anyPrismaBoot.communityPostComment?.findMany && allPostIds.length > 0
        ? anyPrismaBoot.communityPostComment
            .findMany({
              where: {
                postId: { in: allPostIds },
                deletedAt: null,
                isRemovedByModerator: false,
              },
              orderBy: { createdAt: "asc" },
            })
            .catch(() => [])
        : Promise.resolve([]),
    ]);

    const commentAuthorIds = Array.from(
      new Set(
        (allPostComments as Array<Record<string, any>>)
          .map((c) => (c.accountId ? String(c.accountId) : ""))
          .filter(Boolean),
      ),
    );
    const commentAuthorProfiles =
      commentAuthorIds.length > 0 &&
      typeof (this.prisma.memberProfile as Record<string, any>)?.findMany === "function"
        ? await this.prisma.memberProfile
            .findMany({ where: { accountId: { in: commentAuthorIds } } })
            .catch(() => [])
        : [];
    const commentProfileByAccountId = new Map<string, Record<string, any>>();
    for (const mp of commentAuthorProfiles as Array<Record<string, any>>) {
      if (mp?.accountId) commentProfileByAccountId.set(String(mp.accountId), mp);
    }

    const reactionsByPostId = new Map<string, Record<string, number>>();
    const viewerReactionByPostId = new Map<string, string>();
    for (const r of allPostReactions as Array<Record<string, any>>) {
      const pid = String(r.postId ?? "");
      const rType = String(r.reactionType ?? "LIKE").toUpperCase();
      if (!pid) continue;
      const map = reactionsByPostId.get(pid) ?? {};
      map[rType] = (map[rType] ?? 0) + 1;
      reactionsByPostId.set(pid, map);
      if (String(r.accountId ?? "") === session.accountId) {
        viewerReactionByPostId.set(pid, rType);
      }
    }

    const commentsByPostId = new Map<string, Array<Record<string, any>>>();
    for (const c of allPostComments as Array<Record<string, any>>) {
      const pid = String(c.postId ?? "");
      if (!pid) continue;
      if (c.id && moderationCtx.reportedCommentIds.has(String(c.id))) continue;
      if (
        c.accountId &&
        moderationCtx.accountsWhoBlockedViewer.has(String(c.accountId))
      ) {
        continue;
      }
      const mp = c.accountId ? commentProfileByAccountId.get(String(c.accountId)) : null;
      const resolvedAuthorName = mp?.displayName ?? c.authorName ?? "Sakhi Member";
      const resolvedUsername = this.deriveUsername(
        String(resolvedAuthorName),
        mp?.username ?? null,
      );
      if (moderationCtx.blockedHandles.has(normalizeHandle(resolvedUsername))) {
        continue;
      }
      const resolvedAvatar = mp
        ? this.resolveMemberAvatar(mp.avatarAsset, mp.avatarMediaAssetId)
        : "";
      const isOwn = Boolean(c.accountId && c.accountId === session.accountId);
      const createdDate =
        c.createdAt instanceof Date ? c.createdAt : new Date(String(c.createdAt ?? Date.now()));
      const updatedDate =
        c.updatedAt instanceof Date ? c.updatedAt : new Date(String(c.updatedAt ?? createdDate));
      const isEdited = updatedDate.getTime() - createdDate.getTime() > 1500;
      const likeSet = Module2Service.commentLikesMap.get(String(c.id));
      const likesCount = likeSet ? likeSet.size : 0;
      const isLiked = Boolean(likeSet && likeSet.has(session.accountId));
      const list = commentsByPostId.get(pid) ?? [];
      list.push({
        id: c.id,
        commentId: c.id,
        postId: pid,
        authorAccountId: c.accountId ?? "",
        authorName: resolvedAuthorName,
        authorUsername: resolvedUsername,
        authorAvatar: resolvedAvatar,
        content: c.content,
        body: c.content,
        parentCommentId: c.parentCommentId ?? null,
        replyToHandle: c.replyToHandle ?? null,
        isOwnComment: isOwn,
        canEdit: isOwn,
        canDelete: isOwn,
        isEdited,
        likesCount,
        isLiked,
        timestamp: this.formatRelativeTime(createdDate),
        createdAt: this.formatRelativeTime(createdDate),
        createdAtIso: createdDate.toISOString(),
      });
      commentsByPostId.set(pid, list);
    }

    const hasLiveCommentQuery =
      typeof anyPrismaBoot.communityPostComment?.findMany === "function";
    const mapPost = (post: (typeof allPosts)[number]) => {
      const rawComments = commentsByPostId.get(post.id) ?? [];
      const threadedComments = this.groupThreadedComments(rawComments).map((c: Record<string, any>) => ({
        ...c,
        canDelete: Boolean(c.isOwnComment || post.authorAccountId === session.accountId),
      }));
      const authoritativeCommentsCount = hasLiveCommentQuery
        ? threadedComments.length
        : post.commentsCount;
      if (hasLiveCommentQuery && post.commentsCount !== threadedComments.length) {
        void this.prisma.communityPost
          .update({
            where: { id: post.id },
            data: { commentsCount: threadedComments.length },
          })
          .catch(() => undefined);
      }
      const breakdown = reactionsByPostId.get(post.id) ?? {};
      const viewerRx =
        viewerReactionByPostId.get(post.id) ?? (likedSet.has(post.id) ? "HEART" : null);
      const pollMeta = Module2Service.postPollMetaMap.get(post.id);
      const extraMedia = Module2Service.postExtraMediaMap.get(post.id);
      return {
        id: post.id,
        postId: post.id,
        authorAccountId: post.authorAccountId ?? "",
        authorName: post.authorName,
        authorUsername: post.authorUsername,
        authorAvatar: this.resolveMemberAvatar(post.authorAvatar),
        authorVerified: post.authorVerified,
        timestamp: this.formatRelativeTime(post.createdAt),
        createdAt: post.createdAt.toISOString(),
        content: post.content,
        body: post.content,
        imageAsset: post.imageAsset,
        mediaAsset: post.imageAsset,
        mediaAssets:
          extraMedia && extraMedia.length > 0
            ? extraMedia
            : post.imageAsset
              ? [post.imageAsset]
              : [],
        mediaContentType:
          post.mediaAssets[0]?.contentType ??
          (post.imageAsset?.endsWith(".mp4") ? "video/mp4" : null),
        categoryBadge: post.categoryBadge,
        categorySlug: post.categorySlug,
        visibility: post.visibility,
        cropPreset: post.cropPreset,
        hashtags: Array.isArray(post.hashtags) ? post.hashtags : [],
        locationTag: post.locationTag,
        allowComments: post.allowComments,
        shareToBusinessProfile: post.shareToBusinessProfile,
        feedSection: post.feedSection,
        status: post.status,
        hasBreathingExerciseCard: post.hasBreathingExerciseCard,
        likesCount: post.likesCount,
        reactionsCount: post.likesCount,
        commentsCount: authoritativeCommentsCount,
        savesCount: post.savesCount,
        sharesCount: post.sharesCount,
        isLiked: likedSet.has(post.id) || viewerRx !== null,
        isSaved: savedSet.has(post.id),
        isOwnPost: post.authorAccountId === session.accountId,
        canEdit: post.authorAccountId === session.accountId,
        canDelete: post.authorAccountId === session.accountId,
        viewerReaction: viewerRx,
        reactionBreakdown: breakdown,
        comments: threadedComments,
        ...(pollMeta
          ? {
              pollQuestion: pollMeta.question,
              pollOptions: pollMeta.options,
              pollVotes: pollMeta.votes,
            }
          : {}),
      };
    };

    const mappedPosts = allPosts.filter(canViewPost).map(mapPost);
    const communityPosts = mappedPosts.filter(
      (post) => post.feedSection === "community",
    );
    const exploreRecommendedPosts = mappedPosts.filter(
      (post) => post.feedSection === "explore",
    );
    const profilePosts = ownedProfilePosts
      .filter((post) => {
        if (post.id.startsWith("11111111-1111-4111-8111-")) return false;
        if (
          post.authorUsername === "@siddhu" &&
          normalizeHandle(currentUsername) !== "siddhu"
        ) {
          return false;
        }
        return true;
      })
      .map(mapPost);

    const displayName = profile?.displayName ?? "Sakhi Member";
    const username = currentUsername;

    return {
      source: "postgresql_live" as const,
      totalDatabaseMembers,
      totalDatabasePosts,
      user: {
        accountId: session.accountId,
        displayName,
        username,
        bio: profile?.bio ?? "",
        location: profile?.location ?? "",
        avatarAsset: this.resolveMemberAvatar(
          profile?.avatarAsset,
          profile?.avatarMediaAssetId,
        ),
        email: profile?.email ?? "",
        phoneMasked: this.maskPhone(session.account.phoneE164),
        phoneVerified: Boolean(session.account.phoneVerifiedAt),
        verificationStatus: session.account.verificationStatus,
        accountStatus: session.account.status,
        postsCount: profilePosts.length,
        followersCount: activeFollowersCount,
        followingCount: activeFollowingCount,
        interests: this.parseInterests(profile?.interests),
        businessProfileUrl: profile?.businessProfileUrl ?? null,
        // No second-factor provider is configured; never surface a legacy flag as active protection.
        twoFactorEnabled: false,
        activeSessionsCount,
      },
      communityPosts,
      exploreRecommendedPosts,
      profilePosts,
      groups: groups.map((g) => ({
        id: g.id,
        name: g.name,
        description: g.description,
        category: g.category,
        membersCount: g.membersCount,
        newPostsToday: g.newPostsToday,
      })),
      followers: mappedFollowers,
      privacySettings: {
        view_profile: privacyPref?.viewProfile ?? "Verified members only",
        message_me: privacyPref?.messageMe ?? "Verified members only",
        see_posts: privacyPref?.seePosts ?? "Verified members only",
        show_location: privacyPref?.showLocation ?? "General location only",
        search_results: privacyPref?.searchResults ?? "Yes",
        business_enquiries: privacyPref?.businessEnquiries ?? "Yes",
      },
      notificationPreferences: {
        community_updates: notificationPref?.communityUpdates ?? true,
        group_activity: notificationPref?.groupActivity ?? true,
        wellness_reminders: notificationPref?.wellnessReminders ?? true,
        safety_alerts: notificationPref?.safetyAlerts ?? true,
        messages: notificationPref?.messages ?? true,
        business_enquiries: notificationPref?.businessEnquiries ?? true,
        marketing_updates: notificationPref?.marketingUpdates ?? false,
      },
      wellnessResources: wellnessResources.map((w) => ({
        id: w.id,
        slug: w.slug,
        category: w.category,
        title: w.title,
        subtitle: w.subtitle,
        durationLabel: w.durationLabel,
        thumbAsset: w.thumbAsset,
      })),
      emergencyContacts: emergencyContacts.map((c) => ({
        id: c.id,
        name: c.name,
        relationship: c.relationship,
        phoneE164: c.phoneE164,
        isTrustedLocationContact: c.isTrustedLocationContact,
      })),
      blockedUsers: blockedUsers.map((b) => ({
        id: b.id,
        blockedUsername: b.blockedUsername,
        blockedDisplayName: b.blockedDisplayName,
      })),
      reportedPostIds: [...moderationCtx.reportedPostIds],
      hiddenPostIds: [...moderationCtx.hiddenPostIds],
      mutedUsers: [...moderationCtx.mutedHandles],
      restrictedUsers: [...moderationCtx.restrictedHandles],
    };
  }

  async checkUsernameAvailability(
    authorization: string | undefined,
    requestedUsername: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const raw = (requestedUsername ?? "")
      .trim()
      .replace(/^@+/, "")
      .toLowerCase();
    if (!/^[a-z0-9_]{3,24}$/.test(raw)) {
      return {
        available: false,
        username: raw ? `@${raw}` : "",
        reason: "Use 3–24 lowercase letters, numbers, or underscores.",
      };
    }
    const username = `@${raw}`;
    const existingProfile = await this.prisma.memberProfile.findFirst({
      where: {
        OR: [
          { username: { equals: username, mode: "insensitive" } },
          { username: { equals: raw, mode: "insensitive" } },
        ],
        accountId: { not: session.accountId },
      },
      select: { accountId: true },
    });
    if (existingProfile) {
      return {
        available: false,
        username,
        reason: "This username is already taken by another Sakhi member.",
      };
    }
    const currentOwnProfile = await this.prisma.memberProfile
      .findUnique({
        where: { accountId: session.accountId },
        select: { username: true },
      })
      .catch(() => null);
    const ownNormalized = (currentOwnProfile?.username ?? "")
      .trim()
      .replace(/^@+/, "")
      .toLowerCase();
    if (
      ownNormalized !== raw &&
      typeof (this.prisma.communityDirectoryProfile as Record<string, any>)
        ?.findFirst === "function"
    ) {
      const existingDir = await (
        this.prisma.communityDirectoryProfile as Record<string, any>
      )
        .findFirst({
          where: {
            OR: [
              { username: { equals: username, mode: "insensitive" } },
              { username: { equals: raw, mode: "insensitive" } },
            ],
          },
          select: { id: true },
        })
        .catch(() => null);
      if (existingDir) {
        return {
          available: false,
          username,
          reason: "This username is already reserved in the Sakhi community.",
        };
      }
    }
    return { available: true, username };
  }

  async searchMembers(
    authorization: string | undefined,
    rawQuery: string | undefined,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const query = (rawQuery ?? "").trim().replace(/^#/, "").slice(0, 80);
    if (!query) return { source: "postgresql_live" as const, members: [] };

    const viewerProfile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
      select: { username: true },
    });
    const viewerHandle = (viewerProfile?.username ?? "").trim().toLowerCase();
    const normalizeHandle = (value: string) =>
      value.trim().replace(/^@/, "").toLowerCase();

    const viewerHandleVariants = [
      ...new Set(
        [
          viewerHandle,
          normalizeHandle(viewerHandle),
          viewerHandle ? `@${normalizeHandle(viewerHandle)}` : "",
        ].filter(Boolean),
      ),
    ];
    const [outgoingBlocks, incomingBlocks] = await Promise.all([
      this.prisma.memberModerationBlock.findMany({
        where: { accountId: session.accountId },
        select: { blockedUsername: true },
      }),
      viewerHandleVariants.length > 0
        ? this.prisma.memberModerationBlock.findMany({
            where: { blockedUsername: { in: viewerHandleVariants } },
            select: { accountId: true },
          })
        : Promise.resolve([]),
    ]);
    const blockedHandles = new Set(
      outgoingBlocks.map((item) => normalizeHandle(item.blockedUsername)),
    );
    const accountsWhoBlockedViewer = new Set(
      incomingBlocks.map((item) => item.accountId),
    );

    // JsonB array containment handles exact interest names. The parameterized
    // query adds substring matches such as "wellness" -> "Mental Wellness";
    // candidate rows are still filtered by account verification and privacy below.
    const rawPrisma = this.prisma as unknown as {
      $queryRaw?: <T>(
        query: TemplateStringsArray,
        ...values: unknown[]
      ) => Promise<T>;
    };
    const interestRows =
      typeof rawPrisma.$queryRaw === "function"
        ? await rawPrisma.$queryRaw<Array<{ accountId: string }>>`
          SELECT mp.account_id AS "accountId"
          FROM member_profiles AS mp
          WHERE mp.account_id <> ${session.accountId}::uuid
            AND EXISTS (
              SELECT 1
              FROM jsonb_array_elements_text(mp.interests) AS interest(value)
              WHERE lower(interest.value) LIKE ${`%${query.toLowerCase()}%`}
            )
          LIMIT 100
        `
        : [];
    const interestAccountIds = interestRows.map((row) => row.accountId);
    const searchBranches: Record<string, unknown>[] = [
      { displayName: { contains: query, mode: "insensitive" } },
      { username: { contains: query, mode: "insensitive" } },
      { bio: { contains: query, mode: "insensitive" } },
      { interests: { array_contains: [query] } },
      ...(interestAccountIds.length > 0
        ? [{ accountId: { in: interestAccountIds } }]
        : []),
    ];

    const candidates = await this.prisma.memberProfile.findMany({
      where: {
        accountId: {
          not: session.accountId,
          ...(accountsWhoBlockedViewer.size > 0
            ? { notIn: [...accountsWhoBlockedViewer] }
            : {}),
        },
        account: {
          is: {
            status: "ACTIVE",
            verificationStatus: "VERIFIED",
          },
        },
        OR: searchBranches,
      },
      include: {
        account: {
          select: {
            status: true,
            verificationStatus: true,
            privacyPreference: {
              select: { searchResults: true },
            },
          },
        },
      },
      orderBy: { displayName: "asc" },
      take: 100,
    });

    const visibleCandidates = candidates.filter((profile) => {
      const searchPreference =
        profile.account.privacyPreference?.searchResults ?? "Yes";
      if (searchPreference.trim().toLowerCase() === "no") return false;
      const handle = profile.username ?? "";
      return !handle || !blockedHandles.has(normalizeHandle(handle));
    });

    const usernames = visibleCandidates
      .map((profile) => profile.username)
      .filter((username): username is string => Boolean(username));
    const directoryProfiles = usernames.length
      ? await this.prisma.communityDirectoryProfile.findMany({
          where: { username: { in: usernames } },
          select: { id: true, username: true },
        })
      : [];
    const directoryByUsername = new Map(
      directoryProfiles.map((profile) => [profile.username, profile]),
    );
    const directoryIds = directoryProfiles.map((profile) => profile.id);
    const follows = directoryIds.length
      ? await this.prisma.memberFollow.findMany({
          where: {
            accountId: session.accountId,
            directoryProfileId: { in: directoryIds },
            isFollowing: true,
          },
          select: { directoryProfileId: true },
        })
      : [];
    const followedDirectoryIds = new Set(
      follows.map((follow) => follow.directoryProfileId),
    );

    return {
      source: "postgresql_live" as const,
      query,
      members: visibleCandidates.slice(0, 30).map((profile) => {
        const directoryProfile = profile.username
          ? directoryByUsername.get(profile.username)
          : undefined;
        const handle = profile.username ?? "";
        return {
          id: directoryProfile?.id ?? profile.accountId,
          accountId: profile.accountId,
          name: profile.displayName,
          username: handle,
          bio: profile.bio,
          avatarAsset: this.resolveMemberAvatar(
            profile.avatarAsset,
            profile.avatarMediaAssetId,
          ),
          verificationStatus: profile.account.verificationStatus,
          isVerified: true,
          isFollowing: directoryProfile
            ? followedDirectoryIds.has(directoryProfile.id)
            : false,
          canFollow: Boolean(directoryProfile),
          interests: this.parseInterests(profile.interests),
          businessProfileUrl: profile.businessProfileUrl,
          businessProfileName: profile.businessProfileName,
          businessCategory: profile.businessCategory,
        };
      }),
    };
  }

  async updateProfile(
    authorization: string | undefined,
    dto: Partial<UpdateModule2ProfileDto> & {
      profilePhotoRef?: string;
      locationCity?: string;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const requestedHandle = dto.username?.trim();
    const normalizedUsername = requestedHandle
      ? `@${requestedHandle.replace(/^@/, "").toLowerCase()}`
      : undefined;
    if (dto.displayName !== undefined && /\d/.test(dto.displayName)) {
      throw new BadRequestException("Full name cannot contain numbers.");
    }
    let resolvedUsername = normalizedUsername
      ? `@${normalizedUsername
          .replace(/^@+/, "")
          .replace(/[^a-z0-9_.-]/gi, "_")
          .toLowerCase()}`
      : undefined;
    if (resolvedUsername && resolvedUsername.length < 3) {
      resolvedUsername = `${resolvedUsername}_${session.accountId.slice(0, 4)}`;
    }
    if (resolvedUsername) {
      const bareHandle = resolvedUsername.replace(/^@+/, "");
      const taken = await this.prisma.memberProfile.findFirst({
        where: {
          OR: [
            { username: { equals: resolvedUsername, mode: "insensitive" } },
            { username: { equals: bareHandle, mode: "insensitive" } },
          ],
          accountId: { not: session.accountId },
        },
        select: { accountId: true },
      });
      if (taken) {
        resolvedUsername = `@${bareHandle.slice(0, 18)}_${session.accountId.slice(0, 4).toLowerCase()}`;
      }
    }
    if (
      dto.profilePhotoRef &&
      dto.profilePhotoRef.startsWith("profile/") &&
      !dto.profilePhotoRef.startsWith(`profile/${session.accountId}/`)
    ) {
      throw new BadRequestException(
        "Profile photo reference must belong to the authenticated member.",
      );
    }
    const existing = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
    });
    const displayName = (
      dto.displayName ??
      existing?.displayName ??
      "Sakhi Member"
    ).trim();
    const bio = (dto.bio ?? existing?.bio ?? "").trim();
    const location = (
      dto.location ??
      dto.locationCity ??
      existing?.location ??
      "Bangalore, India"
    ).trim();
    const interests = (
      dto.interests ?? this.parseInterests(existing?.interests)
    )
      .map((item) => item.trim())
      .filter((item) => item.length > 0);

    const updated = await this.prisma.memberProfile.upsert({
      where: { accountId: session.accountId },
      create: {
        accountId: session.accountId,
        displayName,
        username: resolvedUsername ?? this.deriveUsername(displayName, null),
        bio,
        location,
        interests,
        email: dto.email?.trim().toLowerCase() ?? null,
        businessProfileUrl: dto.businessProfileUrl?.trim() ?? null,
        avatarAsset: dto.avatarAsset?.trim() || "",
        profilePhotoRef: dto.profilePhotoRef?.trim() || null,
        dateOfBirth: new Date("2000-01-01T00:00:00.000Z"),
      },
      update: {
        displayName,
        ...(resolvedUsername !== undefined
          ? { username: resolvedUsername }
          : {}),
        bio,
        location,
        interests,
        ...(dto.email !== undefined
          ? { email: dto.email.trim().toLowerCase() || null }
          : {}),
        ...(dto.businessProfileUrl !== undefined
          ? { businessProfileUrl: dto.businessProfileUrl.trim() || null }
          : {}),
        ...(dto.avatarAsset !== undefined && dto.avatarAsset.trim().length > 0
          ? { avatarAsset: dto.avatarAsset.trim() }
          : {}),
        ...(dto.profilePhotoRef !== undefined
          ? { profilePhotoRef: dto.profilePhotoRef.trim() || null }
          : {}),
      },
    });

    const effectiveHandle = this.deriveUsername(
      updated.displayName,
      updated.username,
    );
    const resolvedAvatar = this.resolveMemberAvatar(
      updated.avatarAsset,
      updated.avatarMediaAssetId,
    );
    try {
      const existingDirectory = existing?.username
        ? await this.prisma.communityDirectoryProfile.findUnique({
            where: { username: existing.username },
          })
        : null;
      if (existingDirectory && existingDirectory.username !== effectiveHandle) {
        // Preserve the stable directory ID so existing follow relations survive
        // a member's username edit.
        await this.prisma.communityDirectoryProfile.update({
          where: { id: existingDirectory.id },
          data: {
            username: effectiveHandle,
            name: updated.displayName,
            avatarAsset: resolvedAvatar,
            bio: updated.bio ?? "",
          },
        });
      } else {
        await this.prisma.communityDirectoryProfile.upsert({
          where: { username: effectiveHandle },
          update: {
            name: updated.displayName,
            avatarAsset: resolvedAvatar,
            bio: updated.bio ?? "",
          },
          create: {
            username: effectiveHandle,
            name: updated.displayName,
            avatarAsset: resolvedAvatar,
            bio: updated.bio ?? "",
            defaultFollowing: false,
          },
        });
      }
    } catch {
      // Directory synchronization is best-effort; profile saving must remain
      // available even if an older directory row cannot be reconciled.
    }

    if (
      typeof (this.prisma.communityPost as Record<string, any>)?.updateMany ===
      "function"
    ) {
      await this.prisma.communityPost
        .updateMany({
          where: { authorAccountId: session.accountId },
          data: {
            authorName: updated.displayName,
            authorUsername: effectiveHandle,
            ...(resolvedAvatar ? { authorAvatar: resolvedAvatar } : {}),
          },
        })
        .catch(() => undefined);
    }
    if (
      typeof (this.prisma.communityPostComment as Record<string, any>)?.updateMany ===
      "function"
    ) {
      await this.prisma.communityPostComment
        .updateMany({
          where: { accountId: session.accountId },
          data: {
            authorName: updated.displayName,
          },
        })
        .catch(() => undefined);
    }
    const anyPrismaForProf = this.prisma as Record<string, any>;
    if (typeof anyPrismaForProf.businessDirectoryListing?.updateMany === "function") {
      await anyPrismaForProf.businessDirectoryListing
        .updateMany({
          where: { ownerAccountId: session.accountId },
          data: { ownerDisplayName: updated.displayName },
        })
        .catch(() => undefined);
    }

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module2.profile.updated",
        targetType: "member_profile",
        targetId: session.accountId,
        outcome: "success",
        requestId: randomUUID(),
        redactedMetadata: {
          interestsCount: interests.length,
          hadExistingProfile: Boolean(existing),
        },
      },
    });

    return {
      displayName: updated.displayName,
      username: this.deriveUsername(updated.displayName, updated.username),
      bio: updated.bio,
      location: updated.location,
      avatarAsset: this.resolveMemberAvatar(
        updated.avatarAsset,
        updated.avatarMediaAssetId,
      ),
      interests: this.parseInterests(updated.interests),
      email: updated.email,
      businessProfileUrl: updated.businessProfileUrl,
      profilePhotoRef: updated.profilePhotoRef,
    };
  }

  async createPost(
    authorization: string | undefined,
    dto: CreateCommunityPostDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const profile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
    });
    const authorName = profile?.displayName ?? "Sakhi Member";
    const authorUsername = this.deriveUsername(authorName, profile?.username);
    const authorAvatar = this.resolveMemberAvatar(
      profile?.avatarAsset,
      profile?.avatarMediaAssetId,
    );
    const postContent = (dto.content ?? dto.body ?? "").trim();
    const mediaUploadIds = [...new Set(dto.mediaUploadIds ?? [])];
    const suppliedMedia =
      dto.imageAsset?.trim() || dto.mediaAsset?.trim() || "";
    if (!postContent && mediaUploadIds.length === 0 && !suppliedMedia) {
      throw new BadRequestException(
        "Add a caption or attach a photo before publishing.",
      );
    }
    const visibilityAliases: Record<string, string> = {
      "Verified members": "VERIFIED_MEMBERS",
      "Followers only": "FOLLOWERS_ONLY",
      "Only me": "PRIVATE_SELF",
    };
    const visibilityInput = (dto.visibility ?? "VERIFIED_MEMBERS").trim();
    const visibility = visibilityAliases[visibilityInput] ?? visibilityInput;
    if (
      !["VERIFIED_MEMBERS", "FOLLOWERS_ONLY", "PRIVATE_SELF"].includes(
        visibility,
      )
    ) {
      throw new BadRequestException("Choose a supported post visibility.");
    }
    const categorySlug = (dto.categorySlug ?? "community").trim().toLowerCase();
    const hashtags = (dto.hashtags ?? [])
      .map((tag) => tag.trim().replace(/^#+/, ""))
      .filter((tag) => tag.length > 0)
      .map((tag) => `#${tag}`);
    const safeLocalAsset = suppliedMedia.startsWith("assets/")
      ? suppliedMedia
      : null;
    if (suppliedMedia && mediaUploadIds.length === 0 && !safeLocalAsset) {
      throw new BadRequestException(
        "Uploaded photos must be referenced by their returned media ID. Please upload the photo again.",
      );
    }
    const post = await this.prisma.$transaction(async (tx) => {
      if (mediaUploadIds.length > 0) {
        const ownedUploads = await tx.mediaAsset.findMany({
          where: {
            id: { in: mediaUploadIds },
            ownerAccountId: session.accountId,
            postId: null,
            purpose: { in: ["COMMUNITY_POST_IMAGE", "COMMUNITY_POST_VIDEO"] },
            status: "UPLOADED",
            deletedAt: null,
          },
          select: { id: true },
        });
        if (ownedUploads.length !== mediaUploadIds.length) {
          throw new BadRequestException(
            "One or more uploaded photos are unavailable or do not belong to your account. Please upload them again.",
          );
        }
      }
      const savedPost = await tx.communityPost.create({
        data: {
          authorAccountId: session.accountId,
          authorName,
          authorUsername,
          authorAvatar,
          authorVerified: session.account.verificationStatus === "VERIFIED",
          content: postContent,
          categoryBadge: dto.categoryBadge?.trim() || categorySlug,
          categorySlug,
          visibility,
          cropPreset: dto.cropPreset ?? "4:5",
          hashtags,
          locationTag: dto.locationTag?.trim() || null,
          allowComments: dto.allowComments ?? true,
          shareToBusinessProfile: dto.shareToBusinessProfile ?? false,
          imageAsset:
            mediaUploadIds.length > 0
              ? `/api/v1/module2/media/object/${mediaUploadIds[0]}`
              : safeLocalAsset,
          feedSection: "community",
        },
      });
      if (mediaUploadIds.length > 0) {
        const attachment = await tx.mediaAsset.updateMany({
          where: {
            id: { in: mediaUploadIds },
            ownerAccountId: session.accountId,
            postId: null,
            status: "UPLOADED",
          },
          data: {
            postId: savedPost.id,
            status: "ATTACHED",
            visibility,
          },
        });
        if (attachment.count !== mediaUploadIds.length) {
          throw new BadRequestException(
            "A selected photo was attached to another post. Please upload it again.",
          );
        }
      }
      await tx.auditEvent.create({
        data: {
          actorType: "MEMBER",
          actorId: session.accountId,
          action: "module2.community_post.created",
          targetType: "community_post",
          targetId: savedPost.id,
          outcome: "success",
          requestId: randomUUID(),
          redactedMetadata: {
            categorySlug,
            visibility,
            mediaCount: mediaUploadIds.length,
            hashtagsCount: hashtags.length,
          },
        },
      });
      return savedPost;
    });

    const mediaAssetDelegate = (
      this.prisma as unknown as {
        mediaAsset?: {
          findUnique?: (
            args: unknown,
          ) => Promise<{ contentType: string } | null>;
        };
      }
    ).mediaAsset;
    const firstAttachedMedia =
      mediaUploadIds.length > 0 &&
      typeof mediaAssetDelegate?.findUnique === "function"
        ? await mediaAssetDelegate.findUnique({
            where: { id: mediaUploadIds[0] },
            select: { contentType: true },
          })
        : null;

    const allMediaUrls =
      mediaUploadIds.length > 0
        ? mediaUploadIds.map((id) => `/api/v1/module2/media/object/${id}`)
        : Array.isArray(dto.mediaAssets) && dto.mediaAssets.length > 0
          ? dto.mediaAssets.filter((m) => m.startsWith("assets/") || m.startsWith("/api/v1/"))
          : post.imageAsset
            ? [post.imageAsset]
            : [];
    if (allMediaUrls.length > 1) {
      Module2Service.postExtraMediaMap.set(post.id, allMediaUrls);
    }
    if (Array.isArray(dto.pollOptions) && dto.pollOptions.length >= 2) {
      const cleanOpts = dto.pollOptions.map((o) => o.trim()).filter(Boolean);
      if (cleanOpts.length >= 2) {
        Module2Service.postPollMetaMap.set(post.id, {
          question: (dto.pollQuestion ?? postContent).trim(),
          options: cleanOpts,
          votes: {},
        });
      }
    }
    const pollMeta = Module2Service.postPollMetaMap.get(post.id);

    return {
      id: post.id,
      postId: post.id,
      authorAccountId: session.accountId,
      authorName: post.authorName,
      authorUsername: post.authorUsername,
      authorAvatar: this.resolveMemberAvatar(post.authorAvatar),
      authorVerified: post.authorVerified,
      timestamp: this.formatRelativeTime(post.createdAt),
      createdAt: post.createdAt.toISOString(),
      content: post.content,
      body: post.content,
      imageAsset: post.imageAsset,
      mediaAsset: post.imageAsset,
      mediaAssets: allMediaUrls,
      mediaContentType:
        firstAttachedMedia?.contentType ?? dto.mediaContentType ?? null,
      categoryBadge: post.categoryBadge,
      categorySlug: post.categorySlug,
      visibility: post.visibility,
      cropPreset: post.cropPreset,
      hashtags: Array.isArray(post.hashtags) ? post.hashtags : hashtags,
      locationTag: post.locationTag,
      allowComments: post.allowComments,
      shareToBusinessProfile: post.shareToBusinessProfile,
      feedSection: post.feedSection,
      likesCount: post.likesCount,
      commentsCount: post.commentsCount,
      savesCount: post.savesCount,
      sharesCount: post.sharesCount,
      isLiked: false,
      isSaved: false,
      isOwnPost: true,
      canEdit: true,
      canDelete: true,
      ...(pollMeta
        ? {
            pollQuestion: pollMeta.question,
            pollOptions: pollMeta.options,
            pollVotes: pollMeta.votes,
          }
        : {}),
    };
  }

  async togglePostLike(authorization: string | undefined, postId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!post) throw new NotFoundException("Community post was not found.");

    const existing = await this.prisma.communityPostLike.findUnique({
      where: {
        postId_accountId: {
          postId,
          accountId: session.accountId,
        },
      },
    });

    if (existing) {
      await this.prisma.communityPostLike.delete({
        where: { id: existing.id },
      });
      const updated = await this.prisma.communityPost.update({
        where: { id: postId },
        data: { likesCount: Math.max(0, post.likesCount - 1) },
      });
      return {
        postId,
        isLiked: false,
        likesCount: updated.likesCount,
      };
    }

    await this.prisma.communityPostLike.create({
      data: {
        postId,
        accountId: session.accountId,
      },
    });
    const updated = await this.prisma.communityPost.update({
      where: { id: postId },
      data: { likesCount: post.likesCount + 1 },
    });
    return {
      postId,
      isLiked: true,
      likesCount: updated.likesCount,
    };
  }

  async togglePostSave(authorization: string | undefined, postId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!post) throw new NotFoundException("Community post was not found.");

    const existing = await this.prisma.communityPostSave.findUnique({
      where: {
        postId_accountId: {
          postId,
          accountId: session.accountId,
        },
      },
    });

    if (existing) {
      await this.prisma.communityPostSave.delete({
        where: { id: existing.id },
      });
      return { postId, isSaved: false };
    }

    await this.prisma.communityPostSave.create({
      data: {
        postId,
        accountId: session.accountId,
      },
    });
    return { postId, isSaved: true };
  }

  async addPostComment(
    authorization: string | undefined,
    postId: string,
    dto: CreatePostCommentDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!post) throw new NotFoundException("Community post was not found.");

    const profile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
    });

    const replyHandle = dto.replyToHandle?.trim() || null;
    let commentContent = (dto.content ?? dto.body ?? "").trim();
    if (replyHandle) {
      const normalizedHandle = replyHandle.startsWith("@")
        ? replyHandle
        : `@${replyHandle}`;
      if (
        commentContent.toLowerCase().startsWith(`${normalizedHandle.toLowerCase()} `)
      ) {
        const stripped = commentContent.slice(normalizedHandle.length).trim();
        if (stripped.length > 0) {
          commentContent = stripped;
        }
      }
    }
    if (!commentContent) {
      throw new BadRequestException("Comment content is required.");
    }

    const anyCommentModel = this.prisma
      .communityPostComment as unknown as Record<string, any>;
    const parentId =
      dto.parentCommentId && /^[0-9a-f-]{36}$/i.test(dto.parentCommentId.trim())
        ? dto.parentCommentId.trim()
        : null;

    let comment: Record<string, any>;
    try {
      comment = await anyCommentModel.create({
        data: {
          postId,
          accountId: session.accountId,
          authorName: profile?.displayName ?? "Sakhi Member",
          content: commentContent,
          ...(parentId ? { parentCommentId: parentId } : {}),
          ...(replyHandle ? { replyToHandle: replyHandle } : {}),
        },
      });
    } catch {
      comment = await this.prisma.communityPostComment.create({
        data: {
          postId,
          accountId: session.accountId,
          authorName: profile?.displayName ?? "Sakhi Member",
          content: commentContent,
        },
      });
    }

    const exactCommentsCount =
      typeof anyCommentModel?.count === "function"
        ? await anyCommentModel
            .count({
              where: {
                postId,
                deletedAt: null,
                isRemovedByModerator: false,
              },
            })
            .catch(() => post.commentsCount + 1)
        : post.commentsCount + 1;
    const updated = await this.prisma.communityPost.update({
      where: { id: postId },
      data: { commentsCount: exactCommentsCount },
    });

    const authorDisplayName =
      profile?.displayName ?? comment.authorName ?? "Sakhi Member";
    const authorUsername = this.deriveUsername(
      String(authorDisplayName),
      profile?.username ?? null,
    );
    const authorAvatar = profile
      ? this.resolveMemberAvatar(profile.avatarAsset, profile.avatarMediaAssetId)
      : "";
    const createdIso =
      comment.createdAt instanceof Date
        ? comment.createdAt.toISOString()
        : String(comment.createdAt ?? new Date().toISOString());

    return {
      id: comment.id,
      commentId: comment.id,
      postId,
      authorAccountId: session.accountId,
      authorName: authorDisplayName,
      authorUsername,
      authorAvatar,
      content: comment.content,
      body: comment.content,
      parentCommentId: comment.parentCommentId ?? parentId,
      replyToHandle: comment.replyToHandle ?? replyHandle,
      isOwnComment: true,
      canEdit: true,
      canDelete: true,
      isEdited: false,
      likesCount: 0,
      isLiked: false,
      commentsCount: updated.commentsCount,
      timestamp: "Just now",
      createdAt: "Just now",
      createdAtIso: createdIso,
    };
  }

  async toggleFollow(authorization: string | undefined, profileId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleaned = profileId.trim();
    let dirProfile = await this.prisma.communityDirectoryProfile
      .findUnique({ where: { id: cleaned } })
      .catch(() => null);

    if (!dirProfile) {
      const normalizedHandle = cleaned.startsWith("@")
        ? cleaned.toLowerCase()
        : `@${cleaned.toLowerCase()}`;
      dirProfile = await this.prisma.communityDirectoryProfile
        .findFirst({
          where: {
            OR: [
              { username: { equals: normalizedHandle, mode: "insensitive" } },
              { username: { equals: cleaned, mode: "insensitive" } },
              { name: { equals: cleaned, mode: "insensitive" } },
            ],
          },
        })
        .catch(() => null);
    }

    if (!dirProfile) {
      const memberProf = await this.prisma.memberProfile
        .findFirst({
          where: {
            OR: [
              ...(cleaned.length === 36 ? [{ accountId: cleaned }] : []),
              { username: { equals: cleaned, mode: "insensitive" } },
              {
                username: {
                  equals: cleaned.startsWith("@") ? cleaned : `@${cleaned}`,
                  mode: "insensitive",
                },
              },
              { displayName: { equals: cleaned, mode: "insensitive" } },
            ],
          },
        })
        .catch(() => null);

      if (memberProf) {
        const handle = this.deriveUsername(
          memberProf.displayName,
          memberProf.username,
        );
        dirProfile = await this.prisma.communityDirectoryProfile.upsert({
          where: { username: handle },
          update: {
            name: memberProf.displayName,
            bio: memberProf.bio ?? "",
            avatarAsset: memberProf.avatarAsset ?? "",
          },
          create: {
            username: handle,
            name: memberProf.displayName,
            bio: memberProf.bio ?? "",
            avatarAsset: memberProf.avatarAsset ?? "",
            defaultFollowing: false,
          },
        });
      }
    }

    if (!dirProfile) {
      throw new NotFoundException("Directory profile was not found.");
    }

    const existing = await this.prisma.memberFollow.findUnique({
      where: {
        accountId_directoryProfileId: {
          accountId: session.accountId,
          directoryProfileId: dirProfile.id,
        },
      },
    });

    const nextFollowing = existing
      ? !existing.isFollowing
      : !dirProfile.defaultFollowing;

    await this.prisma.memberFollow.upsert({
      where: {
        accountId_directoryProfileId: {
          accountId: session.accountId,
          directoryProfileId: dirProfile.id,
        },
      },
      create: {
        accountId: session.accountId,
        directoryProfileId: dirProfile.id,
        isFollowing: nextFollowing,
      },
      update: {
        isFollowing: nextFollowing,
      },
    });

    return {
      profileId: dirProfile.id,
      targetId: cleaned,
      username: dirProfile.username,
      isFollowing: nextFollowing,
    };
  }

  async updatePrivacyPreference(
    authorization: string | undefined,
    dto: UpdatePrivacyPreferenceDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const fieldMap: Record<
      UpdatePrivacyPreferenceDto["settingId"],
      | "viewProfile"
      | "messageMe"
      | "seePosts"
      | "showLocation"
      | "searchResults"
      | "businessEnquiries"
    > = {
      view_profile: "viewProfile",
      message_me: "messageMe",
      see_posts: "seePosts",
      show_location: "showLocation",
      search_results: "searchResults",
      business_enquiries: "businessEnquiries",
    };
    const column = fieldMap[dto.settingId];
    if (!column) throw new BadRequestException("Unknown privacy setting.");

    const updated = await this.prisma.memberPrivacyPreference.upsert({
      where: { accountId: session.accountId },
      create: {
        accountId: session.accountId,
        [column]: dto.selectedValue.trim(),
      },
      update: {
        [column]: dto.selectedValue.trim(),
      },
    });

    return {
      settingId: dto.settingId,
      selectedValue: updated[column],
    };
  }

  async updateNotificationPreference(
    authorization: string | undefined,
    dto: UpdateNotificationPreferenceDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const fieldMap: Record<
      UpdateNotificationPreferenceDto["prefId"],
      | "communityUpdates"
      | "groupActivity"
      | "wellnessReminders"
      | "safetyAlerts"
      | "messages"
      | "businessEnquiries"
      | "marketingUpdates"
    > = {
      community_updates: "communityUpdates",
      group_activity: "groupActivity",
      wellness_reminders: "wellnessReminders",
      safety_alerts: "safetyAlerts",
      messages: "messages",
      business_enquiries: "businessEnquiries",
      marketing_updates: "marketingUpdates",
    };
    const column = fieldMap[dto.prefId];
    if (!column) throw new BadRequestException("Unknown notification setting.");

    const updated = await this.prisma.memberNotificationPreference.upsert({
      where: { accountId: session.accountId },
      create: {
        accountId: session.accountId,
        [column]: dto.isEnabled,
      },
      update: {
        [column]: dto.isEnabled,
      },
    });

    if (dto.prefId === "marketing_updates") {
      await this.prisma.memberCommunicationPreference.upsert({
        where: { accountId: session.accountId },
        create: {
          accountId: session.accountId,
          productUpdatesAccepted: dto.isEnabled,
        },
        update: {
          productUpdatesAccepted: dto.isEnabled,
        },
      });
    }

    return {
      prefId: dto.prefId,
      isEnabled: updated[column],
    };
  }

  private readonly curatedWomenQuotes = [
    {
      id: 1,
      quote: "Awake, arise, and educate. Smash traditions—liberate!",
      author: "Savitribai Phule",
      category: "Trailblazers & Courage",
    },
    {
      id: 2,
      quote:
        "We want deeper sincerity of motive, a greater courage in speech and earnestness in action.",
      author: "Sarojini Naidu",
      category: "Voice & Leadership",
    },
    {
      id: 3,
      quote:
        "The path from dreams to success does exist. May you have the vision to find it, the courage to get on to it, and the perseverance to follow it.",
      author: "Kalpana Chawla",
      category: "Dreams & Perseverance",
    },
    {
      id: 4,
      quote:
        "I shall not surrender my Jhansi—courage is the crown every woman wears within.",
      author: "Rani Lakshmibai",
      category: "Fearless Strength",
    },
    {
      id: 5,
      quote: "A woman with a voice is, by definition, a strong woman.",
      author: "Melinda French Gates",
      category: "Voice & Leadership",
    },
    {
      id: 6,
      quote: "There is no limit to what we, as women, can accomplish.",
      author: "Michelle Obama",
      category: "Boundless Potential",
    },
    {
      id: 7,
      quote:
        "I raise up my voice—not so that I can shout, but so that those without a voice can be heard.",
      author: "Malala Yousafzai",
      category: "Sisterhood & Voice",
    },
    {
      id: 8,
      quote:
        "Each time a woman stands up for herself, without knowing it possibly, without claiming it, she stands up for all women.",
      author: "Maya Angelou",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 9,
      quote:
        "Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less.",
      author: "Marie Curie",
      category: "Wisdom & Fearlessness",
    },
    {
      id: 10,
      quote: "No one can make you feel inferior without your consent.",
      author: "Eleanor Roosevelt",
      category: "Self-Worth & Dignity",
    },
    {
      id: 11,
      quote: "Women belong in all places where decisions are being made.",
      author: "Ruth Bader Ginsburg",
      category: "Voice & Leadership",
    },
    {
      id: 12,
      quote:
        "I am not free while any woman is unfree, even when her shackles are very different from my own.",
      author: "Audre Lorde",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 13,
      quote:
        "At the end of the day, we can endure much more than we think we can.",
      author: "Frida Kahlo",
      category: "Resilience & Healing",
    },
    {
      id: 14,
      quote: "Culture does not make people. People make culture.",
      author: "Chimamanda Ngozi Adichie",
      category: "Change & Empowerment",
    },
    {
      id: 15,
      quote:
        "The success of every woman should be the inspiration to another. We should raise each other up.",
      author: "Serena Williams",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 16,
      quote:
        "Vision without action is merely a dream; action with courage changes generations.",
      author: "Sudha Murty",
      category: "Wisdom & Action",
    },
    {
      id: 17,
      quote:
        "Do not wait for someone else to come and speak for you. It's you who can change the world.",
      author: "Mary Kom",
      category: "Fearless Strength",
    },
    {
      id: 18,
      quote:
        "Another world is not only possible, she is on her way. On a quiet day, I can hear her breathing.",
      author: "Arundhati Roy",
      category: "Hope & Renewal",
    },
    {
      id: 19,
      quote:
        "Freedom is not given; it is claimed by women who refuse to shrink.",
      author: "Captain Lakshmi Sahgal",
      category: "Trailblazers & Courage",
    },
    {
      id: 20,
      quote:
        "Empowerment begins the moment a woman knows she is never walking alone.",
      author: "Sakhi Sisterhood",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 21,
      quote:
        "A strong woman looks a challenge dead in the eye and gives it a wink.",
      author: "Gina Carey",
      category: "Fearless Strength",
    },
    {
      id: 22,
      quote:
        "The most common way people give up their power is by thinking they don't have any.",
      author: "Alice Walker",
      category: "Self-Worth & Dignity",
    },
    {
      id: 23,
      quote: "Above all, be the heroine of your life, not the victim.",
      author: "Nora Ephron",
      category: "Courage & Agency",
    },
    {
      id: 24,
      quote: "What makes you different or weird—that's your strength.",
      author: "Meryl Streep",
      category: "Self-Worth & Dignity",
    },
    {
      id: 25,
      quote:
        "Think like a queen. A queen is not afraid to fail. Failure is another steppingstone to greatness.",
      author: "Oprah Winfrey",
      category: "Resilience & Growth",
    },
    {
      id: 26,
      quote: "You may encounter many defeats, but you must not be defeated.",
      author: "Maya Angelou",
      category: "Resilience & Healing",
    },
    {
      id: 27,
      quote: "Well-behaved women seldom make history.",
      author: "Laurel Thatcher Ulrich",
      category: "Trailblazers & Courage",
    },
    {
      id: 28,
      quote:
        "The question isn't who's going to let me; it's who is going to stop me.",
      author: "Ayn Rand",
      category: "Courage & Agency",
    },
    {
      id: 29,
      quote: "She remembered who she was and the game changed.",
      author: "Lalah Delia",
      category: "Self-Worth & Dignity",
    },
    {
      id: 30,
      quote:
        "A woman is like a tea bag—you can't tell how strong she is until you put her in hot water.",
      author: "Eleanor Roosevelt",
      category: "Resilience & Growth",
    },
    {
      id: 31,
      quote:
        "Life is not measured by the number of breaths we take, but by the moments that take our breath away.",
      author: "Maya Angelou",
      category: "Mindfulness & Joy",
    },
    {
      id: 32,
      quote: "When women support each other, incredible things happen.",
      author: "Sakhi Community",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 33,
      quote:
        "Your safety is your right, your voice is your shield, and your community is your strength.",
      author: "Sakhi Safety Pledge",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 34,
      quote: "Courage is like a muscle. We strengthen it by use.",
      author: "Ruth Gordon",
      category: "Fearless Strength",
    },
    {
      id: 35,
      quote:
        "If you want something said, ask a man; if you want something done, ask a woman.",
      author: "Margaret Thatcher",
      category: "Voice & Leadership",
    },
    {
      id: 36,
      quote:
        "A feminist is anyone who recognizes the equality and full humanity of women and men.",
      author: "Gloria Steinem",
      category: "Equality & Justice",
    },
    {
      id: 37,
      quote:
        "We need to reshape our own perception of how we view ourselves. We have to step up as women and take the lead.",
      author: "Beyoncé",
      category: "Voice & Leadership",
    },
    {
      id: 38,
      quote:
        "No country can ever truly flourish if it stifles the potential of its women and deprives itself of the contributions of half of its citizens.",
      author: "Michelle Obama",
      category: "Equality & Justice",
    },
    {
      id: 39,
      quote:
        "Educate a man and you educate an individual; educate a woman and you educate an entire generation.",
      author: "Brigham Young",
      category: "Education & Wisdom",
    },
    {
      id: 40,
      quote:
        "I measure the progress of a community by the degree of progress which women have achieved.",
      author: "Dr. B. R. Ambedkar",
      category: "Equality & Justice",
    },
    {
      id: 41,
      quote:
        "To awaken the people, it is the women who must be awakened. Once she is on the move, the family moves, the village moves, the nation moves.",
      author: "Jawaharlal Nehru",
      category: "Trailblazers & Courage",
    },
    {
      id: 42,
      quote:
        "There is no chance for the welfare of the world unless the condition of women is improved. It is not possible for a bird to fly on only one wing.",
      author: "Swami Vivekananda",
      category: "Equality & Justice",
    },
    {
      id: 43,
      quote:
        "Whatever you do, be different—that was the advice my mother gave me.",
      author: "Anita Roddick",
      category: "Dreams & Perseverance",
    },
    {
      id: 44,
      quote:
        "Whatever the problem, be part of the solution. Don't just sit around raising questions and pointing out obstacles.",
      author: "Tina Fey",
      category: "Wisdom & Action",
    },
    {
      id: 45,
      quote:
        "You are more powerful than you know; you are beautiful just as you are.",
      author: "Melissa Etheridge",
      category: "Self-Worth & Dignity",
    },
    {
      id: 46,
      quote:
        "Fearlessness is not the absence of fear. It's the mastery of fear. It's about getting up one more time than we fall down.",
      author: "Arianna Huffington",
      category: "Fearless Strength",
    },
    {
      id: 47,
      quote:
        "The power you have is to be the best version of yourself you can be, so you can create a better world.",
      author: "Ashley Rickards",
      category: "Change & Empowerment",
    },
    {
      id: 48,
      quote: "A girl should be two things: who and what she wants.",
      author: "Coco Chanel",
      category: "Courage & Agency",
    },
    {
      id: 49,
      quote: "The most courageous act is still to think for yourself. Aloud.",
      author: "Coco Chanel",
      category: "Voice & Leadership",
    },
    {
      id: 50,
      quote:
        "Do not live someone else's life and someone else's idea of what womanhood is. Womanhood is you.",
      author: "Viola Davis",
      category: "Self-Worth & Dignity",
    },
    {
      id: 51,
      quote:
        "Doubt is a killer. You just have to know who you are and what you stand for.",
      author: "Jennifer Lopez",
      category: "Confidence & Trust",
    },
    {
      id: 52,
      quote:
        "Take criticism seriously, but not personally. If there is truth or merit in the criticism, try to learn from it.",
      author: "Hillary Rodham Clinton",
      category: "Wisdom & Action",
    },
    {
      id: 53,
      quote:
        "Human rights are women's rights, and women's rights are human rights.",
      author: "Hillary Rodham Clinton",
      category: "Equality & Justice",
    },
    {
      id: 54,
      quote:
        "Never doubt that you are valuable and powerful and deserving of every chance and opportunity in the world to pursue and achieve your own dreams.",
      author: "Hillary Rodham Clinton",
      category: "Dreams & Perseverance",
    },
    {
      id: 55,
      quote:
        "It took me quite a long time to develop a voice, and now that I have it, I am not going to be silent.",
      author: "Madeleine Albright",
      category: "Voice & Leadership",
    },
    {
      id: 56,
      quote: "Women are the largest untapped reservoir of talent in the world.",
      author: "Hillary Rodham Clinton",
      category: "Boundless Potential",
    },
    {
      id: 57,
      quote:
        "If your actions create a legacy that inspires others to dream more, learn more, do more and become more, then, you are an excellent leader.",
      author: "Dolly Parton",
      category: "Voice & Leadership",
    },
    {
      id: 58,
      quote: "Storms make trees take deeper roots.",
      author: "Dolly Parton",
      category: "Resilience & Healing",
    },
    {
      id: 59,
      quote:
        "Just don't give up trying to do what you really want to do. Where there is love and inspiration, I don't think you can go wrong.",
      author: "Ella Fitzgerald",
      category: "Dreams & Perseverance",
    },
    {
      id: 60,
      quote:
        "Define success on your own terms, achieve it by your own rules, and build a life you're proud to live.",
      author: "Anne Sweeney",
      category: "Courage & Agency",
    },
    {
      id: 61,
      quote: "Be messy and complicated and afraid and show up anyways.",
      author: "Glennon Doyle",
      category: "Fearless Strength",
    },
    {
      id: 62,
      quote:
        "Owning our story and loving ourselves through that process is the bravest thing that we'll ever do.",
      author: "Brené Brown",
      category: "Self-Worth & Dignity",
    },
    {
      id: 63,
      quote:
        "Vulnerability is the birthplace of innovation, creativity and change.",
      author: "Brené Brown",
      category: "Resilience & Growth",
    },
    {
      id: 64,
      quote: "Courage starts with showing up and letting ourselves be seen.",
      author: "Brené Brown",
      category: "Fearless Strength",
    },
    {
      id: 65,
      quote: "One child, one teacher, one book, one pen can change the world.",
      author: "Malala Yousafzai",
      category: "Education & Wisdom",
    },
    {
      id: 66,
      quote:
        "We realize the importance of our voices only when we are silenced.",
      author: "Malala Yousafzai",
      category: "Voice & Leadership",
    },
    {
      id: 67,
      quote: "When the whole world is silent, even one voice becomes powerful.",
      author: "Malala Yousafzai",
      category: "Voice & Leadership",
    },
    {
      id: 68,
      quote:
        "Extremists have shown what frightens them most: a girl with a book.",
      author: "Malala Yousafzai",
      category: "Education & Wisdom",
    },
    {
      id: 69,
      quote: "I'm tough, I'm ambitious, and I know exactly what I want.",
      author: "Madonna",
      category: "Confidence & Trust",
    },
    {
      id: 70,
      quote: "Power is not given to you. You have to take it.",
      author: "Beyoncé",
      category: "Courage & Agency",
    },
    {
      id: 71,
      quote:
        "The allure of a woman is her confidence and her kindness toward other women.",
      author: "Sakhi Sisterhood",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 72,
      quote:
        "Trust your instincts. You never have to apologize for prioritizing your personal safety.",
      author: "Sakhi Safety Guide",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 73,
      quote:
        "Before boarding a late-evening cab, share your live route link with a trusted contact—preparedness is peace of mind.",
      author: "Sakhi Safety Tip",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 74,
      quote:
        "India's 112 emergency helpline connects Police, Fire, and Medical response in one call—always accessible from your Sakhi Safety Hub.",
      author: "Sakhi Safety Tip",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 75,
      quote:
        "A sisterhood that watches out for one another turns every street into a safer path.",
      author: "Sakhi Community",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 76,
      quote: "You are never alone when your trusted circle carries your light.",
      author: "Sakhi Community",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 77,
      quote:
        "Whatever glory belongs to the race for a development unprecedented in history for the given length of time, a full share belongs to the womanhood of the race.",
      author: "Mary McLeod Bethune",
      category: "Trailblazers & Courage",
    },
    {
      id: 78,
      quote:
        "Invest in the human soul. Who knows, it might be a diamond in the rough.",
      author: "Mary McLeod Bethune",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 79,
      quote:
        "If they don't give you a seat at the table, bring a folding chair.",
      author: "Shirley Chisholm",
      category: "Voice & Leadership",
    },
    {
      id: 80,
      quote:
        "Tremendous amounts of talent are being lost to our society just because that talent wears a skirt.",
      author: "Shirley Chisholm",
      category: "Equality & Justice",
    },
    {
      id: 81,
      quote:
        "Service is the rent we pay for the privilege of living on this earth.",
      author: "Shirley Chisholm",
      category: "Wisdom & Action",
    },
    {
      id: 82,
      quote:
        "You don't make progress by standing on the sidelines, whimpering and complaining. You make progress by implementing ideas.",
      author: "Shirley Chisholm",
      category: "Wisdom & Action",
    },
    {
      id: 83,
      quote:
        "Nothing I accept about myself can be used against me to diminish me.",
      author: "Audre Lorde",
      category: "Self-Worth & Dignity",
    },
    {
      id: 84,
      quote:
        "When I dare to be powerful—to use my strength in the service of my vision—then it becomes less and less important whether I am afraid.",
      author: "Audre Lorde",
      category: "Fearless Strength",
    },
    {
      id: 85,
      quote:
        "Caring for myself is not self-indulgence, it is self-preservation.",
      author: "Audre Lorde",
      category: "Mindfulness & Joy",
    },
    {
      id: 86,
      quote: "Your silence will not protect you.",
      author: "Audre Lorde",
      category: "Voice & Leadership",
    },
    {
      id: 87,
      quote:
        "Delight in your own unfolding; every season of a woman's life holds its own brilliance.",
      author: "Kiran Bedi",
      category: "Resilience & Growth",
    },
    {
      id: 88,
      quote:
        "Fearless policing and fearless living start with self-discipline and inner conviction.",
      author: "Kiran Bedi",
      category: "Fearless Strength",
    },
    {
      id: 89,
      quote:
        "When you educate a girl, you give her the compass to navigate any storm.",
      author: "Sudha Murty",
      category: "Education & Wisdom",
    },
    {
      id: 90,
      quote:
        "Kindness is not weakness; it is the quiet confidence of a strong woman.",
      author: "Sudha Murty",
      category: "Confidence & Trust",
    },
    {
      id: 91,
      quote:
        "Whatever crown you wear, never forget to leave the door open for the women coming after you.",
      author: "Indra Nooyi",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 92,
      quote:
        "Be yourself, passionately and unapologetically, in every boardroom and every neighbourhood.",
      author: "Indra Nooyi",
      category: "Voice & Leadership",
    },
    {
      id: 93,
      quote: "The sky is not the limit when women build the rockets.",
      author: "Tessy Thomas",
      category: "Dreams & Perseverance",
    },
    {
      id: 94,
      quote:
        "Science knows no gender; curiosity and grit belong to every daughter of India.",
      author: "Ritu Karidhal",
      category: "Trailblazers & Courage",
    },
    {
      id: 95,
      quote:
        "Every medal won by a woman is a door opened for a million young girls.",
      author: "P. V. Sindhu",
      category: "Dreams & Perseverance",
    },
    {
      id: 96,
      quote:
        "Champions aren't made in comfort zones; they are forged in determination.",
      author: "Saina Nehwal",
      category: "Fearless Strength",
    },
    {
      id: 97,
      quote:
        "Run your own race, break the tape, and let your footsteps inspire the village behind you.",
      author: "P. T. Usha",
      category: "Trailblazers & Courage",
    },
    {
      id: 98,
      quote:
        "Mountains do not bow to strength alone; they bow to a woman's unbreakable resolve.",
      author: "Bachendri Pal",
      category: "Fearless Strength",
    },
    {
      id: 99,
      quote:
        "Even with a prosthetic leg, Everest could not stop a mind that refused to quit.",
      author: "Arunima Sinha",
      category: "Resilience & Healing",
    },
    {
      id: 100,
      quote:
        "The ocean is vast, the waves are high, and a woman's courage is deeper than both.",
      author: "Arati Saha",
      category: "Fearless Strength",
    },
    {
      id: 101,
      quote:
        "A pen in a woman's hand rewrites the history that tried to erase her.",
      author: "Amrita Pritam",
      category: "Voice & Leadership",
    },
    {
      id: 102,
      quote:
        "Live with the dignity of a Banyan tree—rooted in truth and generous with shade.",
      author: "Mahadevi Varma",
      category: "Wisdom & Action",
    },
    {
      id: 103,
      quote:
        "Let no wall be high enough to block the sunlight from a girl's classroom.",
      author: "Fatima Sheikh",
      category: "Education & Wisdom",
    },
    {
      id: 104,
      quote:
        "True healing honors both the body's wisdom and the spirit's courage.",
      author: "Dr. Anandibai Joshi",
      category: "Trailblazers & Courage",
    },
    {
      id: 105,
      quote:
        "The constitution of a free nation beats strongest when its daughters walk without fear.",
      author: "Hansa Jivraj Mehta",
      category: "Equality & Justice",
    },
    {
      id: 106,
      quote:
        "Justice is incomplete until the last woman in the farthest village knows her rights.",
      author: "Dakshayani Velayudhan",
      category: "Equality & Justice",
    },
    {
      id: 107,
      quote:
        "Democracy thrives where women speak, vote, lead, and build together.",
      author: "Ammu Swaminathan",
      category: "Voice & Leadership",
    },
    {
      id: 108,
      quote:
        "Art, craft, and heritage survive because women wove their soul into every thread.",
      author: "Kamaladevi Chattopadhyay",
      category: "Trailblazers & Courage",
    },
    {
      id: 109,
      quote:
        "A woman's entrepreneurship lifts not just a household, but an entire local economy.",
      author: "Ela Bhatt (SEWA)",
      category: "Change & Empowerment",
    },
    {
      id: 110,
      quote: "Self-reliance is the strongest shield a woman can carry.",
      author: "Ela Bhatt",
      category: "Courage & Agency",
    },
    {
      id: 111,
      quote:
        "When rural women unite, banks listen, laws change, and futures bloom.",
      author: "Chetna Gala Sinha",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 112,
      quote:
        "Planting trees is planting hope; a woman who nurtures the earth heals tomorrow.",
      author: "Saalumarada Thimmakka",
      category: "Wisdom & Action",
    },
    {
      id: 113,
      quote:
        "Like the little hummingbird, do the best you can—every drop of courage counts.",
      author: "Wangari Maathai",
      category: "Wisdom & Action",
    },
    {
      id: 114,
      quote:
        "Human rights are not things that are put on the table for people to enjoy. They are things you fight for and then you protect.",
      author: "Wangari Maathai",
      category: "Equality & Justice",
    },
    {
      id: 115,
      quote:
        "In the midst of winter, I found there was, within me, an invincible summer.",
      author: "Albert Camus",
      category: "Resilience & Healing",
    },
    {
      id: 116,
      quote: "You are the author of your next chapter. Write it boldly.",
      author: "Sakhi Community",
      category: "Dreams & Perseverance",
    },
    {
      id: 117,
      quote:
        "No dream is too large when backed by a circle of women who believe in you.",
      author: "Sakhi Sisterhood",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 118,
      quote:
        "Rest is not quitting; taking a mindful breath prepares you to rise stronger.",
      author: "Sakhi Wellness",
      category: "Mindfulness & Joy",
    },
    {
      id: 119,
      quote:
        "Your intuition is ancient wisdom speaking in real time—listen to it.",
      author: "Sakhi Safety Guide",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 120,
      quote:
        "Keep your trusted contacts updated in Sakhi—one tap can share your live GPS link when it matters most.",
      author: "Sakhi Safety Tip",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 121,
      quote:
        "I am no bird; and no net ensnares me; I am a free human being with an independent will.",
      author: "Charlotte Brontë",
      category: "Courage & Agency",
    },
    {
      id: 122,
      quote:
        "There is no gate, no lock, no bolt that you can set upon the freedom of my mind.",
      author: "Virginia Woolf",
      category: "Education & Wisdom",
    },
    {
      id: 123,
      quote:
        "Lock up your libraries if you like; but there is no gate, no lock, no bolt that you can set upon the freedom of my mind.",
      author: "Virginia Woolf",
      category: "Courage & Agency",
    },
    {
      id: 124,
      quote:
        "One is not born, but rather becomes, a woman of fearless purpose.",
      author: "Simone de Beauvoir",
      category: "Change & Empowerment",
    },
    {
      id: 125,
      quote: "Hope is a passion for the possible.",
      author: "Søren Kierkegaard",
      category: "Hope & Renewal",
    },
    {
      id: 126,
      quote: "Out of difficulties grow miracles.",
      author: "Jean de La Bruyère",
      category: "Resilience & Healing",
    },
    {
      id: 127,
      quote:
        "She stood in the storm, and when the wind did not blow her way, she adjusted her sails.",
      author: "Elizabeth Edwards",
      category: "Resilience & Growth",
    },
    {
      id: 128,
      quote:
        "A woman is the full circle. Within her is the power to create, nurture and transform.",
      author: "Diane Mariechild",
      category: "Boundless Potential",
    },
    {
      id: 129,
      quote:
        "Here's to strong women: May we know them. May we be them. May we raise them.",
      author: " Traditional Proverb",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 130,
      quote:
        "Strong women don't have 'attitudes', we have standards and boundaries.",
      author: "Marilyn Monroe",
      category: "Self-Worth & Dignity",
    },
    {
      id: 131,
      quote:
        "You can never leave footprints that last if you are always walking on tiptoe.",
      author: "Leymah Gbowee",
      category: "Trailblazers & Courage",
    },
    {
      id: 132,
      quote:
        "The world will be saved by the solidarity of women who refuse to look away.",
      author: "Leymah Gbowee",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 133,
      quote:
        "Peace is not just the absence of conflict; it is the presence of justice and safety for every woman.",
      author: "Ellen Johnson Sirleaf",
      category: "Equality & Justice",
    },
    {
      id: 134,
      quote: "If your dreams do not scare you, they are not big enough.",
      author: "Ellen Johnson Sirleaf",
      category: "Dreams & Perseverance",
    },
    {
      id: 135,
      quote:
        "Optimism is the faith that leads to achievement. Nothing can be done without hope and confidence.",
      author: "Helen Keller",
      category: "Hope & Renewal",
    },
    {
      id: 136,
      quote: "Alone we can do so little; together we can do so much.",
      author: "Helen Keller",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 137,
      quote: "Life shrinks or expands in proportion to one's courage.",
      author: "Anaïs Nin",
      category: "Fearless Strength",
    },
    {
      id: 138,
      quote:
        "And the day came when the risk to remain tight in a bud was more painful than the risk it took to blossom.",
      author: "Anaïs Nin",
      category: "Resilience & Growth",
    },
    {
      id: 139,
      quote: "I am deliberate and afraid of nothing.",
      author: "Audre Lorde",
      category: "Fearless Strength",
    },
    {
      id: 140,
      quote:
        "Be a first-rate version of yourself, not a second-rate version of someone else.",
      author: "Judy Garland",
      category: "Self-Worth & Dignity",
    },
    {
      id: 141,
      quote: "It is never too late to be what you might have been.",
      author: "George Eliot",
      category: "Dreams & Perseverance",
    },
    {
      id: 142,
      quote:
        "What you do makes a difference, and you have to decide what kind of difference you want to make.",
      author: "Jane Goodall",
      category: "Wisdom & Action",
    },
    {
      id: 143,
      quote:
        "How wonderful it is that nobody need wait a single moment before starting to improve the world.",
      author: "Anne Frank",
      category: "Hope & Renewal",
    },
    {
      id: 144,
      quote: "Think of all the beauty still left around you and be happy.",
      author: "Anne Frank",
      category: "Mindfulness & Joy",
    },
    {
      id: 145,
      quote: "Nothing is impossible; the word itself says 'I'm possible'!",
      author: "Audrey Hepburn",
      category: "Boundless Potential",
    },
    {
      id: 146,
      quote:
        "As you grow older, you will discover that you have two hands—one for helping yourself, the other for helping others.",
      author: "Audrey Hepburn",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 147,
      quote:
        "We must believe that we are gifted for something, and that this thing, at whatever cost, must be attained.",
      author: "Marie Curie",
      category: "Dreams & Perseverance",
    },
    {
      id: 148,
      quote:
        "First, have a definite, clear practical ideal; a goal, an objective. Second, have the necessary means to achieve your ends.",
      author: "Grace Hopper",
      category: "Wisdom & Action",
    },
    {
      id: 149,
      quote:
        "A ship in port is safe, but that is not what ships are built for. Sail out to sea and do new things.",
      author: "Rear Admiral Grace Hopper",
      category: "Trailblazers & Courage",
    },
    {
      id: 150,
      quote:
        "That brain of mine is something more than merely mortal; as time will show.",
      author: "Ada Lovelace",
      category: "Education & Wisdom",
    },
    {
      id: 151,
      quote:
        "Code, create, lead, and mentor—women in technology are shaping a safer digital tomorrow.",
      author: "Sakhi WomenInTech Circle",
      category: "Change & Empowerment",
    },
    {
      id: 152,
      quote:
        "Every woman who heals herself helps heal all the women who came before her and all those who come after her.",
      author: "Christiane Northrup",
      category: "Resilience & Healing",
    },
    {
      id: 153,
      quote:
        "Daring to set boundaries is about having the courage to love ourselves, even when we risk disappointing others.",
      author: "Brené Brown",
      category: "Self-Worth & Dignity",
    },
    {
      id: 154,
      quote:
        "You are allowed to be both a masterpiece and a work in progress simultaneously.",
      author: "Sophia Bush",
      category: "Resilience & Growth",
    },
    {
      id: 155,
      quote:
        "Don't let anyone speak for you, and don't rely on others to fight for you.",
      author: "Michelle Obama",
      category: "Courage & Agency",
    },
    {
      id: 156,
      quote:
        "Success isn't about how much money you make; it's about the difference you make in people's lives.",
      author: "Michelle Obama",
      category: "Wisdom & Action",
    },
    {
      id: 157,
      quote: "You can't be hesitant about who you are.",
      author: "Viola Davis",
      category: "Confidence & Trust",
    },
    {
      id: 158,
      quote:
        "All dreams are within reach. All you have to do is keep moving towards them.",
      author: "Viola Davis",
      category: "Dreams & Perseverance",
    },
    {
      id: 159,
      quote:
        "I've learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel.",
      author: "Maya Angelou",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 160,
      quote: "Still, like air, I'll rise.",
      author: "Maya Angelou",
      category: "Resilience & Healing",
    },
    {
      id: 161,
      quote: "Be a rainbow in somebody else's cloud.",
      author: "Maya Angelou",
      category: "Sisterhood & Solidarity",
    },
    {
      id: 162,
      quote:
        "Have enough courage to trust love one more time and always one more time.",
      author: "Maya Angelou",
      category: "Hope & Renewal",
    },
    {
      id: 163,
      quote:
        "My mission in life is not merely to survive, but to thrive; and to do so with some passion, some compassion, some humor, and some style.",
      author: "Maya Angelou",
      category: "Mindfulness & Joy",
    },
    {
      id: 164,
      quote: "When a woman becomes her own best friend, life is easier.",
      author: "Diane Von Furstenberg",
      category: "Self-Worth & Dignity",
    },
    {
      id: 165,
      quote:
        "I didn't know what I wanted to do, but I always knew the woman I wanted to be.",
      author: "Diane Von Furstenberg",
      category: "Confidence & Trust",
    },
    {
      id: 166,
      quote: "Fear is not an option when your sisters are beside you.",
      author: "Sakhi Sisterhood",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 167,
      quote:
        "Use Sakhi's Safe Test Mode anytime to practice your 3-second SOS shortcut without sending a live alert.",
      author: "Sakhi Safety Tip",
      category: "Sakhi Safety & Trust",
    },
    {
      id: 168,
      quote:
        "Wherever you travel today, walk tall—your voice, your courage, and your Sakhi community travel with you.",
      author: "Sakhi Community",
      category: "Sakhi Safety & Trust",
    },
  ];

  private haversineDistanceKm(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
  ): number {
    const toRad = (deg: number) => (deg * Math.PI) / 180;
    const r = 6371;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    return Number(
      (r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(2),
    );
  }

  listWomenQuotes(category?: string) {
    const filter = category?.trim().toLowerCase();
    const items = filter
      ? this.curatedWomenQuotes.filter((q) =>
          q.category.toLowerCase().includes(filter),
        )
      : this.curatedWomenQuotes;
    return {
      count: items.length,
      quotes: items,
    };
  }

  private isGenuinePoliceStationListing(
    name: string,
    address: string,
    tags?: Record<string, any>,
  ): boolean {
    const combined =
      `${name} ${address} ${tags?.shop ?? ""} ${tags?.amenity ?? ""} ${tags?.office ?? ""} ${tags?.military ?? ""}`.toLowerCase();
    const excludedPattern =
      /\b(petrol|fuel|bunk|pump|hpcl|bpcl|iocl|indian\s*oil|bharat\s*petroleum|hindustan\s*petroleum|shell|nayara|reliance\s*petroleum|canteen|ncc|bakery|hotel|restaurant|cafe|dhaba|atm|bank|supermarket|grocery|kirana|store|shop|mall|pharmacy|medical\s*store|clinic|hospital|school|college|hostel|mess|quarters|bar|wine|liquor|salon|spa|gym)\b/i;
    if (excludedPattern.test(combined)) {
      return false;
    }
    if (
      tags &&
      tags.amenity &&
      String(tags.amenity).toLowerCase() !== "police"
    ) {
      return false;
    }
    return /\b(police|thana|mahila|station|outpost|chowki|commissioner|control\s*room|kaval|rakshak|ps)\b/i.test(
      `${name} ${tags?.amenity ?? ""}`,
    );
  }

  async listNearbyPoliceStations(
    lat?: number,
    lng?: number,
    radiusMeters = 5000,
  ) {
    const selectedRadiusKm = Number(
      (Math.max(1000, radiusMeters) / 1000).toFixed(1),
    );
    const extendedRadiusKm = Number(
      Math.min(
        45,
        Math.max(selectedRadiusKm + 10, selectedRadiusKm * 2),
      ).toFixed(1),
    );
    if (!hasValidCoordinatePair(lat, lng)) {
      return {
        disclaimer:
          "Enable device location and provide current GPS coordinates to look up nearby stations. Listings do not automatically notify police.",
        emergencyNumbers: {
          nationalErss: "112",
          policeControl: "100",
          womenHelpline: "1091",
          domesticSupport: "181",
        },
        selectedRadiusKm,
        extendedRadiusKm,
        withinRadiusStations: [],
        extendedRadiusStations: [],
        stations: [],
      };
    }
    const currentLatitude = lat as number;
    const currentLongitude = lng as number;
    const anyPrisma = this.prisma as Record<string, any>;
    let dbStations: Array<Record<string, any>> = [];
    if (anyPrisma.verifiedPoliceStation?.findMany) {
      dbStations = await anyPrisma.verifiedPoliceStation
        .findMany({ where: { isVerified: true }, take: 40 })
        .catch(() => []);
    }

    const mapStations: Array<Record<string, any>> = [];
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4500);
    try {
      const queryRadiusMeters = Math.round(extendedRadiusKm * 1000);
      const query =
        '[out:json][timeout:6];nwr["amenity"="police"](around:' +
        queryRadiusMeters +
        "," +
        currentLatitude +
        "," +
        currentLongitude +
        ");out center 30;";
      const response = await fetch("https://overpass-api.de/api/interpreter", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "data=" + encodeURIComponent(query),
        signal: controller.signal,
      });
      if (response.ok) {
        const data = (await response.json()) as { elements?: Array<any> };
        for (const element of data.elements ?? []) {
          const elLat =
            typeof element.lat === "number" ? element.lat : element.center?.lat;
          const elLon =
            typeof element.lon === "number" ? element.lon : element.center?.lon;
          if (
            typeof elLat === "number" &&
            Number.isFinite(elLat) &&
            typeof elLon === "number" &&
            Number.isFinite(elLon)
          ) {
            const rawName =
              typeof element.tags?.name === "string"
                ? element.tags.name.trim()
                : "";
            const address =
              element.tags?.["addr:full"] ||
              element.tags?.["addr:street"] ||
              element.tags?.["addr:suburb"] ||
              element.tags?.["addr:city"] ||
              "Verified OpenStreetMap Police Station";
            if (!rawName) continue;
            if (
              !this.isGenuinePoliceStationListing(
                rawName,
                address,
                element.tags,
              )
            ) {
              continue;
            }
            mapStations.push({
              id: "osm_" + element.id,
              stationCode: "osm_" + element.id,
              name: rawName,
              address,
              latitude: elLat,
              longitude: elLon,
              phoneNumber:
                element.tags?.phone || element.tags?.["contact:phone"] || "112",
              emergencyNumber: "112",
              isWomenStation: /women|mahila|all\s*women/i.test(rawName),
              isVerified: true,
              dataSource: "OpenStreetMap Police Registry",
            });
          }
        }
      }
    } catch {
      // The optional public map lookup can fail; never fabricate nearby results.
    } finally {
      clearTimeout(timeout);
    }

    const nearbyDbStations = dbStations.filter((station) => {
      const stationLat = Number(station.latitude);
      const stationLng = Number(station.longitude);
      if (!Number.isFinite(stationLat) || !Number.isFinite(stationLng)) {
        return false;
      }
      if (
        !this.isGenuinePoliceStationListing(
          String(station.name ?? ""),
          String(station.address ?? ""),
        )
      ) {
        return false;
      }
      const distance = this.haversineDistanceKm(
        currentLatitude,
        currentLongitude,
        stationLat,
        stationLng,
      );
      return Number.isFinite(distance) && distance <= extendedRadiusKm;
    });

    const deduped = new Map<string, Record<string, any>>();
    for (const station of [...nearbyDbStations, ...mapStations]) {
      const distanceKm = this.haversineDistanceKm(
        currentLatitude,
        currentLongitude,
        Number(station.latitude),
        Number(station.longitude),
      );
      if (!Number.isFinite(distanceKm) || distanceKm > extendedRadiusKm) {
        continue;
      }
      const key = `${String(station.name ?? "")
        .toLowerCase()
        .trim()}_${Number(station.latitude).toFixed(3)}_${Number(station.longitude).toFixed(3)}`;
      if (!deduped.has(key)) {
        deduped.set(key, {
          ...station,
          distanceKm,
          withinSelectedRadius: distanceKm <= selectedRadiusKm,
          driveMinutes: Math.max(2, Math.round(distanceKm * 4.2)),
        });
      }
    }

    const merged = [...deduped.values()].sort(
      (a, b) => a.distanceKm - b.distanceKm,
    );
    const withinRadiusStations = merged.filter(
      (s) => s.distanceKm <= selectedRadiusKm,
    );
    const extendedRadiusStations = merged.filter(
      (s) =>
        s.distanceKm > selectedRadiusKm && s.distanceKm <= extendedRadiusKm,
    );

    return {
      disclaimer:
        "Verified police stations only (commercial POIs, fuel stations, and canteens are excluded). Dial 112 or 100 for immediate emergency response.",
      emergencyNumbers: {
        nationalErss: "112",
        policeControl: "100",
        womenHelpline: "1091",
        domesticSupport: "181",
      },
      selectedRadiusKm,
      extendedRadiusKm,
      withinRadiusStations: withinRadiusStations.slice(0, 15),
      extendedRadiusStations: extendedRadiusStations.slice(0, 15),
      stations: merged.slice(0, 25),
    };
  }

  async getSafetyOverview(authorization?: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const [contacts, history, activeShare] = await Promise.all([
      this.prisma.safetyEmergencyContact.findMany({
        where: { accountId: session.accountId },
        orderBy: { createdAt: "asc" },
      }),
      this.prisma.safetySosEvent.findMany({
        where: { accountId: session.accountId },
        orderBy: { createdAt: "desc" },
        take: 25,
      }),
      anyPrisma.safetyLocationShare?.findFirst
        ? anyPrisma.safetyLocationShare
            .findFirst({
              where: { accountId: session.accountId, status: "ACTIVE" },
              orderBy: { createdAt: "desc" },
            })
            .catch(() => null)
        : Promise.resolve(null),
    ]);

    return {
      emergencyContacts: contacts.map(
        (c: Record<string, any>, idx: number) => ({
          id: c.id,
          name: c.name,
          relationship: c.relationship,
          phoneE164: c.phoneE164,
          isPrimary: c.isPrimary ?? idx === 0,
          alertEnabled: c.alertEnabled ?? c.isTrustedLocationContact ?? true,
          isTrustedLocationContact: c.isTrustedLocationContact,
        }),
      ),
      sosHistory: history.map((h: Record<string, any>) => ({
        id: h.id,
        eventType: h.eventType,
        status: h.status,
        locationLabel: h.locationLabel ?? "Location unavailable",
        latitude: h.latitude ?? null,
        longitude: h.longitude ?? null,
        isTestMode: h.isTestMode ?? false,
        contactsAlertedCount: h.contactsAlertedCount ?? 0,
        shareToken: h.shareToken ?? null,
        createdAt: h.createdAt.toISOString(),
      })),
      activeLocationShare: activeShare,
      policeStations: [],
      policeStationsDisclaimer:
        "Current device GPS coordinates are required to look up nearby stations.",
      quotesSample: this.curatedWomenQuotes.slice(0, 12),
    };
  }

  async recordSafetyEvent(
    authorization: string | undefined,
    dto: RecordSafetyEventDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const resolvedType = (dto.eventType ?? dto.note ?? "SOS_ACTIVATED")
      .trim()
      .toUpperCase()
      .slice(0, 32);
    const resolvedStatus = (dto.status ?? "RECORDED")
      .trim()
      .toUpperCase()
      .slice(0, 32);
    const hasLatitude = dto.latitude !== undefined;
    const hasLongitude = dto.longitude !== undefined;
    if (hasLatitude !== hasLongitude) {
      throw new BadRequestException(
        "Latitude and longitude must be provided together.",
      );
    }
    if (hasLatitude && !hasValidCoordinatePair(dto.latitude, dto.longitude)) {
      throw new BadRequestException(
        "The supplied GPS coordinates are invalid.",
      );
    }
    const locationLabel =
      dto.locationLabel?.trim() || dto.locationArea?.trim() || null;
    const event = await this.prisma.safetySosEvent.create({
      data: {
        accountId: session.accountId,
        eventType: resolvedType,
        status: resolvedStatus,
        locationLabel,
        latitude: hasLatitude ? dto.latitude! : null,
        longitude: hasLongitude ? dto.longitude! : null,
        isTestMode: dto.isTestMode === true,
        contactsAlertedCount: 0,
      },
    });

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module4.safety." + resolvedType.toLowerCase(),
        targetType: "safety_sos_event",
        targetId: event.id,
        outcome: resolvedStatus.toLowerCase(),
        requestId: randomUUID(),
        redactedMetadata: {
          locationAvailable: hasLatitude,
          locationLabel: locationLabel ?? "Location unavailable",
        },
      },
    });

    return {
      eventId: event.id,
      eventType: event.eventType,
      status: event.status,
      locationLabel: event.locationLabel,
      latitude: event.latitude,
      longitude: event.longitude,
      createdAt: event.createdAt.toISOString(),
    };
  }

  async activateSos(
    authorization: string | undefined,
    dto: RecordSafetyEventDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const isTestMode = dto.isTestMode === true;
    const hasLatitude = dto.latitude !== undefined;
    const hasLongitude = dto.longitude !== undefined;
    if (hasLatitude !== hasLongitude) {
      throw new BadRequestException(
        "Latitude and longitude must be provided together.",
      );
    }
    if (hasLatitude && !hasValidCoordinatePair(dto.latitude, dto.longitude)) {
      throw new BadRequestException(
        "The supplied GPS coordinates are invalid.",
      );
    }
    const hasLocation = hasLatitude && hasLongitude;
    const locationLabel =
      dto.locationLabel?.trim() || dto.locationArea?.trim() || null;
    // Public tracking tokens must be generated server-side with full UUID entropy.
    const shareToken =
      !isTestMode && hasLocation ? "sos-" + randomUUID() : null;
    const event = await this.prisma.safetySosEvent.create({
      data: {
        accountId: session.accountId,
        eventType: isTestMode ? "SOS_TEST_MODE" : "SOS_ACTIVATED",
        status: isTestMode ? "TEST_MODE" : "ACTIVE",
        locationLabel,
        latitude: hasLocation ? dto.latitude! : null,
        longitude: hasLocation ? dto.longitude! : null,
        isTestMode,
        contactsAlertedCount: 0,
      },
    });

    const anyPrisma = this.prisma as Record<string, any>;
    let locationShareCreated = false;
    if (shareToken && anyPrisma.safetyLocationShare?.create) {
      try {
        await anyPrisma.safetyLocationShare.create({
          data: {
            accountId: session.accountId,
            shareToken,
            status: "ACTIVE",
            durationLabel: "Until I Stop",
            includeProfile: true,
            includeTimestamp: true,
            latitude: dto.latitude!,
            longitude: dto.longitude!,
            ...(typeof dto.batteryPercent === "number"
              ? { batteryPercent: dto.batteryPercent }
              : {}),
            ...(typeof dto.accuracyMeters === "number"
              ? { accuracyMeters: dto.accuracyMeters }
              : {}),
            locationLabel,
          },
        });
        locationShareCreated = true;
        await this.prisma.safetySosEvent
          .update({ where: { id: event.id }, data: { shareToken } })
          .catch(() => undefined);
      } catch {
        // Preserve the SOS record, but never claim that a tracking link exists.
      }
    }

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: isTestMode
          ? "module4.sos.test_mode_triggered"
          : "module4.sos.activated",
        targetType: "safety_sos_event",
        targetId: event.id,
        outcome: isTestMode ? "test_mode" : "active",
        requestId: randomUUID(),
        redactedMetadata: {
          isTestMode,
          locationAvailable: locationShareCreated,
          locationLabel: locationLabel ?? "Location unavailable",
          shareToken: locationShareCreated ? shareToken : null,
        },
      },
    });

    return {
      eventId: event.id,
      status: event.status,
      isTestMode,
      locationAvailable: locationShareCreated,
      locationLabel: locationLabel ?? "Location unavailable",
      shareToken: locationShareCreated ? shareToken : null,
      trackingUrl: locationShareCreated
        ? "/api/v1/module2/safety/track/" + shareToken
        : null,
      policeAutoNotified: false,
      complianceNotice: locationShareCreated
        ? "Direct police auto-dispatch is not connected. Please dial 112 or 100 immediately for police response."
        : "No live GPS location link was created. Dial 112 or 100 for emergency assistance; police auto-dispatch is not connected.",
      createdAt: event.createdAt.toISOString(),
    };
  }

  async updateSosStatus(
    authorization: string | undefined,
    eventId: string,
    nextStatus: "CANCELLED" | "RESOLVED",
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.safetySosEvent.findFirst({
      where: { id: eventId, accountId: session.accountId },
    });
    if (!existing) {
      throw new NotFoundException("SOS event was not found.");
    }
    const anyPrisma = this.prisma as Record<string, any>;
    const updated = await this.prisma.safetySosEvent.update({
      where: { id: eventId },
      data: {
        status: nextStatus,
        ...(nextStatus === "RESOLVED" || nextStatus === "CANCELLED"
          ? { resolvedAt: new Date() }
          : {}),
      },
    });
    if (anyPrisma.safetyLocationShare?.updateMany) {
      await anyPrisma.safetyLocationShare
        .updateMany({
          where: {
            accountId: session.accountId,
            status: "ACTIVE",
            ...(existing.shareToken ? { shareToken: existing.shareToken } : {}),
          },
          data: { status: "STOPPED", stoppedAt: new Date() },
        })
        .catch(() => undefined);
    }
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: `module4.sos.${nextStatus.toLowerCase()}`,
        targetType: "safety_sos_event",
        targetId: eventId,
        outcome: nextStatus.toLowerCase(),
        requestId: randomUUID(),
      },
    });
    return {
      eventId: updated.id,
      status: updated.status,
    };
  }

  async addEmergencyContact(
    authorization: string | undefined,
    dto: CreateEmergencyContactDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const contactName = (dto.name ?? dto.contactName ?? "").trim();
    const rawPhone = (dto.phoneE164 ?? dto.phoneNumber ?? "").trim();
    if (contactName.length < 2 || rawPhone.length < 8) {
      throw new BadRequestException(
        "Provide a valid contact name and +91 mobile number.",
      );
    }
    const existingCount = await this.prisma.safetyEmergencyContact.count({
      where: { accountId: session.accountId },
    });
    if (existingCount >= 5) {
      throw new BadRequestException(
        "Maximum 5 trusted emergency contacts can be configured.",
      );
    }
    const isPrimary = dto.isPrimary === true || existingCount === 0;
    if (isPrimary && existingCount > 0) {
      await this.prisma.safetyEmergencyContact
        .updateMany({
          where: { accountId: session.accountId },
          data: { isPrimary: false },
        })
        .catch(() => undefined);
    }
    const contact = await this.prisma.safetyEmergencyContact.create({
      data: {
        accountId: session.accountId,
        name: contactName,
        relationship: dto.relationship.trim(),
        phoneE164: rawPhone.startsWith("+")
          ? rawPhone
          : `+91${rawPhone.replace(/^91/, "")}`,
        isPrimary,
        alertEnabled: dto.alertEnabled !== false,
        isTrustedLocationContact: dto.alertEnabled !== false,
      },
    });

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module4.emergency_contact.added",
        targetType: "safety_emergency_contact",
        targetId: contact.id,
        outcome: "created",
        requestId: randomUUID(),
      },
    });

    return {
      id: contact.id,
      name: contact.name,
      relationship: contact.relationship,
      phoneE164: contact.phoneE164,
      isPrimary: dto.isPrimary === true || existingCount === 0,
      alertEnabled: contact.isTrustedLocationContact,
      isTrustedLocationContact: contact.isTrustedLocationContact,
    };
  }

  async updateEmergencyContact(
    authorization: string | undefined,
    contactId: string,
    dto: UpdateEmergencyContactDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.safetyEmergencyContact.findFirst({
      where: { id: contactId, accountId: session.accountId },
    });
    if (!existing) {
      throw new NotFoundException("Emergency contact not found.");
    }
    if (dto.isPrimary === true) {
      await this.prisma.safetyEmergencyContact
        .updateMany({
          where: { accountId: session.accountId },
          data: { isPrimary: false },
        })
        .catch(() => undefined);
    }
    const updated = await this.prisma.safetyEmergencyContact.update({
      where: { id: contactId },
      data: {
        ...(dto.name ? { name: dto.name.trim() } : {}),
        ...(dto.relationship ? { relationship: dto.relationship.trim() } : {}),
        ...(typeof dto.isPrimary === "boolean"
          ? { isPrimary: dto.isPrimary }
          : {}),
        ...(typeof dto.alertEnabled === "boolean"
          ? {
              alertEnabled: dto.alertEnabled,
              isTrustedLocationContact: dto.alertEnabled,
            }
          : {}),
      },
    });
    return {
      id: updated.id,
      name: updated.name,
      relationship: updated.relationship,
      phoneE164: updated.phoneE164,
      isPrimary: dto.isPrimary ?? false,
      alertEnabled: updated.isTrustedLocationContact,
    };
  }

  async deleteEmergencyContact(
    authorization: string | undefined,
    contactId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.safetyEmergencyContact.findFirst({
      where: { id: contactId, accountId: session.accountId },
    });
    if (!existing) {
      throw new NotFoundException("Emergency contact not found.");
    }
    await this.prisma.safetyEmergencyContact.delete({
      where: { id: contactId },
    });
    return { deleted: true, contactId };
  }

  async startLocationShare(
    authorization: string | undefined,
    dto: StartLocationShareDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    if (!hasValidCoordinatePair(dto.latitude, dto.longitude)) {
      throw new BadRequestException(
        "Live location sharing requires valid current device GPS coordinates.",
      );
    }
    // A client-chosen value is not an acceptable bearer token for public tracking.
    const shareToken = "sos-" + randomUUID();
    const anyPrisma = this.prisma as Record<string, any>;
    if (!anyPrisma.safetyLocationShare?.create) {
      throw new BadRequestException(
        "Live location sharing is not available in this backend version.",
      );
    }
    await anyPrisma.safetyLocationShare.create({
      data: {
        accountId: session.accountId,
        shareToken,
        status: "ACTIVE",
        durationLabel: dto.durationLabel ?? "1 Hour",
        includeProfile: dto.includeProfile !== false,
        includeTimestamp: dto.includeTimestamp !== false,
        latitude: dto.latitude,
        longitude: dto.longitude,
        ...(typeof dto.batteryPercent === "number"
          ? { batteryPercent: dto.batteryPercent }
          : {}),
        ...(dto.locationLabel?.trim()
          ? { locationLabel: dto.locationLabel.trim() }
          : {}),
      },
    });
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module4.location_share.started",
        targetType: "safety_location_share",
        targetId: shareToken,
        outcome: "active",
        requestId: randomUUID(),
      },
    });
    return {
      shareToken,
      status: "ACTIVE",
      trackingUrl: "/api/v1/module2/safety/track/" + shareToken,
    };
  }

  async pingLocationShare(
    authorization: string | undefined,
    token: string,
    dto: StartLocationShareDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const hasLatitude = dto.latitude !== undefined;
    const hasLongitude = dto.longitude !== undefined;
    if (hasLatitude !== hasLongitude) {
      throw new BadRequestException(
        "Latitude and longitude must be provided together.",
      );
    }
    if (hasLatitude && !hasValidCoordinatePair(dto.latitude, dto.longitude)) {
      throw new BadRequestException(
        "The supplied GPS coordinates are invalid.",
      );
    }
    const anyPrisma = this.prisma as Record<string, any>;
    if (!anyPrisma.safetyLocationShare?.updateMany) {
      throw new BadRequestException(
        "Live location sharing is not available in this backend version.",
      );
    }
    const result = await anyPrisma.safetyLocationShare.updateMany({
      where: {
        shareToken: token,
        accountId: session.accountId,
        status: "ACTIVE",
      },
      data: {
        ...(hasLatitude && hasLongitude
          ? { latitude: dto.latitude!, longitude: dto.longitude! }
          : {}),
        ...(typeof dto.accuracyMeters === "number"
          ? { accuracyMeters: dto.accuracyMeters }
          : {}),
        ...(typeof dto.batteryPercent === "number"
          ? { batteryPercent: dto.batteryPercent }
          : {}),
        ...(dto.locationLabel?.trim()
          ? { locationLabel: dto.locationLabel.trim() }
          : {}),
      },
    });
    if (result.count !== 1) {
      throw new NotFoundException("Active location share was not found.");
    }
    return { shareToken: token, status: "ACTIVE" };
  }

  async stopLocationShare(authorization: string | undefined, token: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (anyPrisma.safetyLocationShare?.updateMany) {
      await anyPrisma.safetyLocationShare
        .updateMany({
          where: { shareToken: token, accountId: session.accountId },
          data: { status: "STOPPED", stoppedAt: new Date() },
        })
        .catch(() => null);
    }
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module4.location_share.stopped",
        targetType: "safety_location_share",
        targetId: token,
        outcome: "stopped",
        requestId: randomUUID(),
      },
    });
    return { shareToken: token, status: "STOPPED" };
  }

  async getLiveLocationTrackState(token: string) {
    const safeToken = token.replace(/[^a-zA-Z0-9_-]/g, "");
    const anyPrisma = this.prisma as Record<string, any>;
    const share = anyPrisma.safetyLocationShare?.findUnique
      ? await anyPrisma.safetyLocationShare
          .findUnique({ where: { shareToken: safeToken } })
          .catch(() => null)
      : null;
    if (
      !share ||
      share.status !== "ACTIVE" ||
      !hasValidCoordinatePair(share.latitude, share.longitude)
    ) {
      return {
        available: false,
        status: share?.status ?? "STOPPED",
      };
    }
    const updatedAt = share.updatedAt
      ? new Date(share.updatedAt).getTime()
      : share.createdAt
        ? new Date(share.createdAt).getTime()
        : Number.NaN;
    const isStale =
      !Number.isFinite(updatedAt) || Date.now() - updatedAt > 120_000;
    return {
      available: true,
      shareToken: safeToken,
      status: isStale ? "STALE" : String(share.status),
      isStale,
      latitude: share.latitude as number,
      longitude: share.longitude as number,
      accuracyMeters:
        typeof share.accuracyMeters === "number" ? share.accuracyMeters : null,
      batteryPercent:
        typeof share.batteryPercent === "number" ? share.batteryPercent : null,
      locationLabel: String(
        share.locationLabel ?? "GPS location recorded",
      ).slice(0, 160),
      updatedAt: Number.isFinite(updatedAt)
        ? new Date(updatedAt).toISOString()
        : null,
    };
  }

  async renderLiveLocationTrackHtml(token: string): Promise<string> {
    const safeToken = token.replace(/[^a-zA-Z0-9_-]/g, "");
    const anyPrisma = this.prisma as Record<string, any>;
    const share = anyPrisma.safetyLocationShare?.findUnique
      ? await anyPrisma.safetyLocationShare
          .findUnique({ where: { shareToken: safeToken } })
          .catch(() => null)
      : null;
    if (
      !share ||
      share.status !== "ACTIVE" ||
      !hasValidCoordinatePair(share.latitude, share.longitude)
    ) {
      return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sakhi Live Location Unavailable</title></head><body style="font-family:system-ui,sans-serif;background:#FDF8FB;color:#2A1930;padding:24px"><h1>Live location unavailable</h1><p>This link has no current, saved GPS coordinate pair. Sakhi will not substitute a sample location.</p><p>For emergency assistance in India, call 112.</p><a href="tel:112">Call 112</a></body></html>';
    }
    const lat = share.latitude as number;
    const lng = share.longitude as number;
    const accuracy =
      typeof share.accuracyMeters === "number" ? share.accuracyMeters : 18;
    const updatedAt = share.updatedAt
      ? new Date(share.updatedAt).getTime()
      : share.createdAt
        ? new Date(share.createdAt).getTime()
        : Number.NaN;
    const isStale =
      !Number.isFinite(updatedAt) || Date.now() - updatedAt > 120_000;
    const status = isStale ? "STALE" : String(share.status);
    const locationLabel = String(
      share.locationLabel ?? "GPS location recorded",
    ).slice(0, 160);
    const escapedLocationLabel = locationLabel
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
    const locationLabelJson = JSON.stringify(locationLabel).replace(
      /</g,
      "\\u003c",
    );
    const safeTokenJson = JSON.stringify(safeToken);
    const lastUpdatedLabel = Number.isFinite(updatedAt)
      ? new Date(updatedAt).toISOString()
      : "Unknown";
    const staleWarning = isStale
      ? '<p id="stale-alert" role="alert" style="color:#9A4C00;font-weight:700">This GPS location has not been updated in over two minutes. Do not assume it is the member\'s current position; contact them or call 112.</p>'
      : '<p id="stale-alert" role="alert" style="color:#9A4C00;font-weight:700;display:none">This GPS location has not been updated in over two minutes. Do not assume it is the member\'s current position; contact them or call 112.</p>';
    const batteryLabel =
      typeof share.batteryPercent === "number"
        ? String(share.batteryPercent) + "%"
        : "Unknown";
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Sakhi Live Emergency Location Tracking</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    body { margin:0; font-family: system-ui, -apple-system, sans-serif; background:#FDF8FB; color:#2A1930; }
    header { background:#5A1868; color:#fff; padding:16px 20px; display:flex; justify-content:space-between; align-items:center; }
    .pill { background:${status === "ACTIVE" ? "#C92A49" : "#6E6275"}; padding:4px 12px; border-radius:999px; font-weight:700; font-size:12px; }
    main { max-width:720px; margin:16px auto; padding:0 16px; }
    .card { background:#fff; border:1px solid #EFE3EE; border-radius:16px; padding:16px; margin-bottom:14px; box-shadow:0 8px 24px rgba(90,24,104,0.06); }
    #map { height:380px; border-radius:14px; border:1px solid #EFE3EE; }
    .btn { display:inline-block; background:#C92A49; color:#fff; text-decoration:none; padding:12px 18px; border-radius:999px; font-weight:700; margin-right:8px; margin-top:10px; }
    .btn-plum { background:#5A1868; }
  </style>
</head>
<body>
  <header>
    <div><strong>Sakhi Safety • Live Location Share</strong></div>
    <span id="status-pill" class="pill">${status}</span>
  </header>
  <main>
    <div class="card">
      <h2 id="loc-label" style="margin:0 0 6px 0;">${escapedLocationLabel}</h2>
      ${staleWarning}
      <p id="updated-label" style="margin:0;color:#6E6275;font-size:14px;">Last GPS update: ${lastUpdatedLabel}</p>
      <p id="coords-label" style="margin:6px 0 0;color:#6E6275;font-size:14px;">Coordinates: ${lat.toFixed(5)}, ${lng.toFixed(5)} · Battery: ${batteryLabel}</p>
      <a class="btn" href="tel:112">Call 112 Emergency</a>
      <a id="gmaps-btn" class="btn btn-plum" href="https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}" target="_blank" rel="noopener">Open in Google Maps</a>
    </div>
    <div id="map"></div>
  </main>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>
    const map = L.map('map').setView([${lat}, ${lng}], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    let locationLabel = ${locationLabelJson};
    const token = ${safeTokenJson};
    const trailCoords = [[${lat}, ${lng}]];
    const marker = L.marker([${lat}, ${lng}]).addTo(map).bindPopup('Sakhi Member Live Location (' + locationLabel + ')').openPopup();
    const circle = L.circle([${lat}, ${lng}], { radius: ${accuracy}, color: '#1479E8', fillColor: '#1479E8', fillOpacity: 0.16 }).addTo(map);
    const polyline = L.polyline(trailCoords, { color: '#C92A49', weight: 4, opacity: 0.85 }).addTo(map);

    async function pollLivePosition() {
      try {
        const res = await fetch('/api/v1/module2/safety/track/' + encodeURIComponent(token) + '/json', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!data || !data.available) {
          const pill = document.getElementById('status-pill');
          if (pill) { pill.textContent = 'STOPPED'; pill.style.background = '#6E6275'; }
          return;
        }
        const nextLat = Number(data.latitude);
        const nextLng = Number(data.longitude);
        if (Number.isFinite(nextLat) && Number.isFinite(nextLng)) {
          marker.setLatLng([nextLat, nextLng]);
          circle.setLatLng([nextLat, nextLng]);
          if (typeof data.accuracyMeters === 'number' && data.accuracyMeters > 0) {
            circle.setRadius(data.accuracyMeters);
          }
          const lastPt = trailCoords[trailCoords.length - 1];
          if (!lastPt || Math.abs(lastPt[0] - nextLat) > 0.00003 || Math.abs(lastPt[1] - nextLng) > 0.00003) {
            trailCoords.push([nextLat, nextLng]);
            polyline.setLatLngs(trailCoords);
            map.panTo([nextLat, nextLng], { animate: true });
          }
          if (data.locationLabel) {
            locationLabel = String(data.locationLabel);
            const locEl = document.getElementById('loc-label');
            if (locEl) locEl.textContent = locationLabel;
            marker.setPopupContent('Sakhi Member Live Location (' + locationLabel + ')');
          }
          const updEl = document.getElementById('updated-label');
          if (updEl && data.updatedAt) updEl.textContent = 'Last GPS update: ' + data.updatedAt;
          const coordsEl = document.getElementById('coords-label');
          const bat = typeof data.batteryPercent === 'number' ? data.batteryPercent + '%' : '${batteryLabel}';
          if (coordsEl) coordsEl.textContent = 'Coordinates: ' + nextLat.toFixed(5) + ', ' + nextLng.toFixed(5) + ' · Battery: ' + bat;
          const gmapsBtn = document.getElementById('gmaps-btn');
          if (gmapsBtn) gmapsBtn.href = 'https://www.google.com/maps/dir/?api=1&destination=' + nextLat + ',' + nextLng;
          const staleEl = document.getElementById('stale-alert');
          if (staleEl) staleEl.style.display = data.isStale ? 'block' : 'none';
          const pill = document.getElementById('status-pill');
          if (pill) {
            pill.textContent = data.status || 'ACTIVE';
            pill.style.background = data.status === 'ACTIVE' ? '#C92A49' : '#6E6275';
          }
        }
      } catch (_) {}
    }
    setInterval(pollLivePosition, 4000);
  </script>
</body>
</html>`;
  }

  async listLoginSessions(authorization: string | undefined) {
    const currentSession =
      await this.auth.authenticateAuthorization(authorization);
    const now = new Date();
    const sessions = await this.prisma.authSession.findMany({
      where: { accountId: currentSession.accountId },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        createdAt: true,
        expiresAt: true,
        revokedAt: true,
        lastSeenAt: true,
        deviceName: true,
      },
    });

    return {
      sessions: sessions.map((session) => ({
        id: session.id,
        createdAt: session.createdAt,
        expiresAt: session.expiresAt,
        lastSeenAt: session.lastSeenAt,
        deviceName: session.deviceName,
        isActive: session.revokedAt === null && session.expiresAt > now,
        isCurrent: session.id === currentSession.id,
      })),
    };
  }

  async revokeLoginSession(
    authorization: string | undefined,
    sessionId: string,
  ) {
    const currentSession =
      await this.auth.authenticateAuthorization(authorization);
    const cleanedId = sessionId.trim();
    if (
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
        cleanedId,
      )
    ) {
      throw new BadRequestException("Choose a valid login session.");
    }

    const target = await this.prisma.authSession.findFirst({
      where: {
        id: cleanedId,
        accountId: currentSession.accountId,
      },
      select: { id: true, revokedAt: true, expiresAt: true },
    });
    if (!target) {
      throw new NotFoundException("Login session was not found.");
    }
    if (target.id === currentSession.id) {
      throw new ForbiddenException(
        "The current device session cannot be revoked here. Sign out on this device instead.",
      );
    }

    const now = new Date();
    if (target.revokedAt || target.expiresAt <= now) {
      throw new ConflictException("This login session is already inactive.");
    }

    const updated = await this.prisma.authSession.updateMany({
      where: {
        id: target.id,
        accountId: currentSession.accountId,
        revokedAt: null,
        expiresAt: { gt: now },
      },
      data: { revokedAt: now },
    });
    if (updated.count !== 1) {
      throw new ConflictException(
        "This login session changed before it could be revoked. Refresh and try again.",
      );
    }

    const isCurrentSession = target.id === currentSession.id;
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: currentSession.accountId,
        action: "auth.session.revoked",
        targetType: "auth_session",
        targetId: target.id,
        outcome: "revoked_by_member",
        requestId: randomUUID(),
        redactedMetadata: { currentSession: isCurrentSession },
      },
    });

    return { revoked: true, currentSession: isCurrentSession };
  }

  async toggleTwoFactor(
    authorization: string | undefined,
    dto: ToggleTwoFactorDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const enabled = dto.enabled ?? dto.twoFactorEnabled ?? false;
    if (enabled) {
      throw new ServiceUnavailableException(
        "Two-factor authentication is not available yet. No second-factor provider is configured, so the setting has not been enabled.",
      );
    }

    const updated = await this.prisma.memberProfile.update({
      where: { accountId: session.accountId },
      data: { twoFactorEnabled: false },
    });

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module2.security.two_factor_updated",
        targetType: "member_account",
        targetId: session.accountId,
        outcome: "disabled",
        requestId: randomUUID(),
      },
    });

    return {
      twoFactorEnabled: updated.twoFactorEnabled,
      available: false,
      status: "not_configured" as const,
    };
  }

  async updateSecurityPin(
    authorization: string | undefined,
    _dto: UpdateSecurityPinDto,
  ) {
    await this.auth.authenticateAuthorization(authorization);
    throw new ServiceUnavailableException(
      "PIN/password changes are not available yet. Sakhi does not currently store a verifiable PIN or password credential, so no change was made.",
    );
  }

  async reportUserOrPost(
    authorization: string | undefined,
    dto: ReportUserOrPostDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const rawTarget = (
      dto.targetHandle ??
      dto.reportedAccountId ??
      dto.postId ??
      "@community"
    ).trim();
    const targetHandle = rawTarget.startsWith("@")
      ? rawTarget.slice(0, 100)
      : `@${rawTarget}`.slice(0, 100);
    const isUuid = (v?: string): boolean =>
      Boolean(v && /^[0-9a-fA-F-]{36}$/.test(v.trim()));
    const resolvedTargetType = (
      dto.targetType ??
      (dto.commentId
        ? "COMMENT"
        : dto.postId
          ? "POST"
          : dto.businessId
            ? "BUSINESS"
            : dto.messageId
              ? "DIRECT_MESSAGE"
              : "MEMBER")
    )
      .trim()
      .toUpperCase()
      .slice(0, 32);

    const anyPrisma = this.prisma as Record<string, any>;
    let targetPostSnapshot: Record<string, any> | null = null;
    let targetCommentSnapshot: Record<string, any> | null = null;
    let resolvedReportedAccountId: string | null = isUuid(dto.reportedAccountId)
      ? dto.reportedAccountId!.trim()
      : null;

    if (dto.postId?.trim() && typeof anyPrisma.communityPost?.findUnique === "function") {
      const foundPost = await anyPrisma.communityPost
        .findUnique({ where: { id: dto.postId.trim() } })
        .catch(() => null);
      if (foundPost) {
        if (!resolvedReportedAccountId && isUuid(foundPost.authorAccountId)) {
          resolvedReportedAccountId = foundPost.authorAccountId;
        }
        targetPostSnapshot = {
          id: foundPost.id,
          authorAccountId: foundPost.authorAccountId,
          authorName: foundPost.authorName,
          authorUsername: foundPost.authorUsername,
          content: foundPost.content,
          imageAsset: foundPost.imageAsset,
          categoryBadge: foundPost.categoryBadge,
          createdAt:
            foundPost.createdAt instanceof Date
              ? foundPost.createdAt.toISOString()
              : String(foundPost.createdAt ?? ""),
        };
      }
    }
    if (
      dto.commentId?.trim() &&
      typeof anyPrisma.communityPostComment?.findUnique === "function"
    ) {
      const foundComment = await anyPrisma.communityPostComment
        .findUnique({ where: { id: dto.commentId.trim() } })
        .catch(() => null);
      if (foundComment) {
        if (!resolvedReportedAccountId && isUuid(foundComment.accountId)) {
          resolvedReportedAccountId = foundComment.accountId;
        }
        targetCommentSnapshot = {
          id: foundComment.id,
          postId: foundComment.postId,
          authorName: foundComment.authorName,
          content: foundComment.content,
        };
      }
    }

    if (!resolvedReportedAccountId && typeof anyPrisma.memberProfile?.findFirst === "function") {
      const variants = this.buildHandleVariants(targetHandle);
      const foundProf = await anyPrisma.memberProfile
        .findFirst({ where: { username: { in: variants } }, select: { accountId: true } })
        .catch(() => null);
      if (foundProf?.accountId && isUuid(foundProf.accountId)) {
        resolvedReportedAccountId = foundProf.accountId;
      }
    }

    const priorReportCount =
      typeof anyPrisma.memberUserReport?.count === "function"
        ? await anyPrisma.memberUserReport
            .count({ where: { targetHandle } })
            .catch(() => 0)
        : 0;
    const catUpper = (dto.category ?? "SAFETY_CONCERN").trim().toUpperCase().slice(0, 64);
    const isHighRisk =
      priorReportCount >= 1 ||
      catUpper.includes("THREAT") ||
      catUpper.includes("HARASSMENT") ||
      catUpper.includes("DOXXING") ||
      catUpper.includes("SAFETY");
    const priority = isHighRisk ? "P1_HIGH" : "P2_NORMAL";
    const severity = isHighRisk ? "S2_HIGH" : "S2_MEDIUM";
    const evidenceUrls = Array.isArray(dto.evidenceUrls)
      ? dto.evidenceUrls
          .map((u) => String(u ?? "").trim())
          .filter((u) => u.length > 0 && u.length <= 500)
      : [];
    const targetSnapshot =
      targetPostSnapshot || targetCommentSnapshot
        ? {
            ...(targetPostSnapshot ? { post: targetPostSnapshot, ...targetPostSnapshot } : {}),
            ...(targetCommentSnapshot ? { comment: targetCommentSnapshot } : {}),
          }
        : undefined;

    const baseData: Record<string, any> = {
      reporterAccountId: session.accountId,
      targetHandle,
      targetType: resolvedTargetType,
      ...(isUuid(dto.postId) ? { postId: dto.postId!.trim() } : {}),
      ...(isUuid(dto.commentId) ? { commentId: dto.commentId!.trim() } : {}),
      category: catUpper,
      reason: dto.reason.trim(),
      details: dto.details?.trim() ? dto.details.trim().slice(0, 1000) : null,
      status: "SUBMITTED",
    };

    const extendedData: Record<string, any> = {
      ...baseData,
      ...(resolvedReportedAccountId ? { reportedAccountId: resolvedReportedAccountId } : {}),
      ...(isUuid(dto.businessId) ? { businessId: dto.businessId!.trim() } : {}),
      ...(isUuid(dto.messageId) ? { messageId: dto.messageId!.trim() } : {}),
      evidenceUrls,
      ...(targetSnapshot ? { targetSnapshot } : {}),
      priority,
      severity,
      internalNotes: [],
    };

    let report: Record<string, any>;
    try {
      report = await this.prisma.memberUserReport.create({
        data: extendedData as any,
      });
    } catch {
      report = await this.prisma.memberUserReport.create({
        data: baseData as any,
      });
    }

    if (typeof anyPrisma.auditEvent?.create === "function") {
      await anyPrisma.auditEvent
        .create({
          data: {
            actorType: "MEMBER",
            actorId: session.accountId,
            action: "module2.moderation.reported",
            targetType: "member_user_report",
            targetId: report.id,
            outcome: "submitted",
            requestId: randomUUID(),
            redactedMetadata: {
              reportId: report.id,
              targetHandle,
              targetType: resolvedTargetType,
              reportedAccountId: resolvedReportedAccountId,
              postId: dto.postId ?? null,
              commentId: dto.commentId ?? null,
              businessId: dto.businessId ?? null,
              messageId: dto.messageId ?? null,
              priority,
              severity,
              evidenceUrls,
              targetPostSnapshot,
              targetCommentSnapshot,
            },
          },
        })
        .catch(() => undefined);
    }

    let blockedUserResult: Record<string, any> | null = null;
    if (dto.alsoBlockUser === true && targetHandle && targetHandle !== "@community") {
      try {
        const displayNameGuess =
          targetPostSnapshot?.authorName ??
          targetHandle.replace(/^@+/, "");
        blockedUserResult = await this.ensureBlockedUser(authorization, {
          blockedUsername: targetHandle,
          blockedDisplayName: String(displayNameGuess || targetHandle),
        });
      } catch {
        blockedUserResult = null;
      }
    }

    return {
      reportId: report.id,
      status: report.status,
      priority: report.priority ?? priority,
      severity: report.severity ?? severity,
      createdAt:
        report.createdAt instanceof Date
          ? report.createdAt.toISOString()
          : new Date().toISOString(),
      hiddenPostId: dto.postId?.trim() || null,
      hiddenCommentId: dto.commentId?.trim() || null,
      alsoBlocked: Boolean(blockedUserResult?.isBlocked),
      blockedUser: blockedUserResult,
    };
  }

  async updateAvatar(authorization: string | undefined, dto: UpdateAvatarDto) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const avatarAsset = dto.avatarAsset.trim();
    const updated = await this.prisma.memberProfile.update({
      where: { accountId: session.accountId },
      data: { avatarAsset },
    });
    await this.prisma.communityPost.updateMany({
      where: { authorAccountId: session.accountId },
      data: { authorAvatar: avatarAsset },
    });
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module2.profile.avatar_updated",
        targetType: "member_profile",
        targetId: session.accountId,
        outcome: "success",
        requestId: randomUUID(),
      },
    });
    return {
      avatarAsset: updated.avatarAsset,
      updatedAt: new Date().toISOString(),
    };
  }

  async requestMediaUpload(
    _authorization: string | undefined,
    _dto: RequestMediaUploadDto,
  ): Promise<never> {
    throw new BadRequestException(
      "Metadata-only upload requests are disabled. Authorize Google Drive and upload the actual image using POST /api/v1/module2/media/binary-upload.",
    );
  }

  async uploadMediaObject(
    _authorization: string | undefined,
    _dto: UploadMediaObjectDto,
  ): Promise<never> {
    throw new BadRequestException(
      "JSON media placeholders are disabled. Choose an actual image file and upload it using POST /api/v1/module2/media/binary-upload.",
    );
  }

  async uploadMediaFile(
    authorization: string | undefined,
    file: {
      originalname: string;
      mimetype: string;
      buffer: Buffer;
      size: number;
    },
    dto: UploadBinaryMediaDto,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    if (!Buffer.isBuffer(file.buffer) || file.buffer.length === 0) {
      throw new BadRequestException("The selected media file is empty.");
    }

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/webp",
      "video/mp4",
    ] as const;
    const detectedMime = this.detectBinaryMimeType(file.buffer);
    if (detectedMime) {
      file.mimetype = detectedMime;
    }
    const isVideo = file.mimetype === "video/mp4";
    const isDirectMessage = ["direct_message", "DIRECT_MESSAGE_IMAGE"].includes(
      dto.purpose ?? "",
    );
    if (isDirectMessage && isVideo) {
      throw new BadRequestException(
        "Direct-message attachments currently support JPG, PNG, and WebP images only.",
      );
    }
    const maxBytes = isVideo
      ? 50 * 1024 * 1024
      : isDirectMessage
        ? 15 * 1024 * 1024
        : 10 * 1024 * 1024;
    if (file.size > maxBytes || file.buffer.length > maxBytes) {
      throw new BadRequestException(
        isVideo
          ? "Video must be 60 seconds or shorter and 50 MB or smaller."
          : isDirectMessage
            ? "Direct-message images must be 15 MB or smaller."
            : "Images must be 10 MB or smaller.",
      );
    }
    if (
      !allowedTypes.includes(file.mimetype as (typeof allowedTypes)[number])
    ) {
      throw new BadRequestException(
        "Use a JPG, PNG, WebP image, or MP4 video.",
      );
    }
    if (!this.hasExpectedImageSignature(file.mimetype, file.buffer)) {
      throw new BadRequestException(
        "The selected file content does not match its declared media type.",
      );
    }
    if (isVideo) {
      const duration = this.readMp4DurationSeconds(file.buffer);
      if (duration !== null && duration > 60) {
        throw new BadRequestException(
          "Video must be 60 seconds or shorter and 50 MB or smaller.",
        );
      }
    }

    const normalizedPurpose: "avatar" | "post" =
      dto.purpose === "avatar" ||
      dto.purpose === "profile_photo" ||
      dto.purpose === "PROFILE_PHOTO"
        ? "avatar"
        : "post";
    if (normalizedPurpose === "avatar" && isVideo) {
      throw new BadRequestException(
        "Profile photos must be JPG, PNG, or WebP images.",
      );
    }
    const uploadId = randomUUID();
    const categorySlug = (dto.categorySlug || "community").trim().toLowerCase();
    const cropAspectRatio =
      dto.cropAspectRatio || (normalizedPurpose === "avatar" ? "1:1" : "4:5");
    const isBusinessMedia =
      !isDirectMessage &&
      (dto.purpose === "business_media" ||
        dto.purpose === "BUSINESS_MEDIA" ||
        categorySlug === "business");
    let stored: {
      driveFileId: string;
      driveFolderId: string;
      driveFolderPath: string;
      storedName: string;
      size: number;
      inlineBase64?: string;
    };
    const fallbackInlineBase64 =
      !isVideo && file.buffer.length <= 8 * 1024 * 1024
        ? file.buffer.toString("base64")
        : undefined;
    try {
      const driveUploaded = await this.googleDrive.uploadImage({
        uploadId,
        accountId: session.accountId,
        purpose: normalizedPurpose,
        categorySlug,
        postId: dto.postId ?? null,
        fileName: file.originalname,
        contentType: file.mimetype as (typeof allowedTypes)[number],
        buffer: file.buffer,
      });
      stored = {
        ...driveUploaded,
        ...(fallbackInlineBase64 ? { inlineBase64: fallbackInlineBase64 } : {}),
      };
    } catch (driveErr) {
      if (fallbackInlineBase64) {
        stored = {
          driveFileId: `inline-db-${uploadId}`,
          driveFolderId: "inline-db-folder",
          driveFolderPath: `Sakhi Media/inline/${session.accountId}`,
          storedName: file.originalname || `${uploadId}.jpg`,
          size: file.buffer.length,
          inlineBase64: fallbackInlineBase64,
        };
      } else {
        throw driveErr;
      }
    }
    // Store a same-origin API path. Absolute loopback URLs work on the host
    // machine but point back to the phone itself when the app runs on Android.
    const publicUrl = `/api/v1/module2/media/object/${uploadId}`;
    const uploadedAt = new Date().toISOString();

    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module2.media.uploaded",
        targetType: "media_upload",
        targetId: uploadId,
        outcome: "stored",
        requestId: uploadId,
        redactedMetadata: {
          uploadId,
          fileName: stored.storedName,
          purpose: dto.purpose,
          contentType: file.mimetype,
          provider: "google_drive",
          driveFileId: stored.driveFileId,
          objectKey: `google-drive/${stored.driveFileId}`,
          publicUrl,
          sizeBytes: stored.size,
          uploadedAt,
          ...(stored.inlineBase64 ? { inlineBase64: stored.inlineBase64 } : {}),
        },
      },
    });

    await this.prisma.mediaAsset.create({
      data: {
        id: uploadId,
        ownerAccountId: session.accountId,
        postId: dto.postId ?? null,
        purpose:
          normalizedPurpose === "avatar"
            ? "PROFILE_PHOTO"
            : isBusinessMedia
              ? "BUSINESS_MEDIA"
              : isDirectMessage
                ? "DIRECT_MESSAGE_IMAGE"
                : isVideo
                  ? "COMMUNITY_POST_VIDEO"
                  : "COMMUNITY_POST_IMAGE",
        storageProvider: "GOOGLE_DRIVE",
        status:
          normalizedPurpose === "avatar" || isBusinessMedia
            ? "ATTACHED"
            : "UPLOADED",
        categorySlug:
          normalizedPurpose === "avatar" || isDirectMessage ? null : categorySlug,
        driveFileId: stored.driveFileId,
        driveFolderId: stored.driveFolderId,
        driveFolderPath: stored.driveFolderPath,
        originalFileName: file.originalname,
        contentType: file.mimetype,
        byteSize: stored.size,
        cropAspectRatio,
        visibility: isDirectMessage ? "PRIVATE_SELF" : "VERIFIED_MEMBERS",
      },
    });

    if (normalizedPurpose === "avatar") {
      const updatedProfile = await this.prisma.memberProfile.update({
        where: { accountId: session.accountId },
        data: { avatarAsset: publicUrl, avatarMediaAssetId: uploadId },
        select: { username: true },
      });
      if (updatedProfile.username) {
        await this.prisma.communityDirectoryProfile.updateMany({
          where: { username: updatedProfile.username },
          data: { avatarAsset: publicUrl },
        });
      }
      await this.prisma.communityPost.updateMany({
        where: { authorAccountId: session.accountId },
        data: { authorAvatar: publicUrl },
      });
    }

    return {
      uploadId,
      mediaId: uploadId,
      provider: "google_drive",
      purpose: normalizedPurpose,
      driveFileId: stored.driveFileId,
      driveFolderId: stored.driveFolderId,
      driveFolderPath: stored.driveFolderPath,
      cropAspectRatio,
      objectKey: `google-drive/${stored.driveFileId}`,
      contentType: file.mimetype,
      sizeBytes: stored.size,
      publicUrl,
      mediaUrl: publicUrl,
      status: "stored" as const,
      createdAt: uploadedAt,
    };
  }

  private detectBinaryMimeType(buffer: Buffer): string | null {
    if (
      buffer.length >= 3 &&
      buffer[0] === 0xff &&
      buffer[1] === 0xd8 &&
      buffer[2] === 0xff
    ) {
      return "image/jpeg";
    }
    if (
      buffer.length >= 8 &&
      buffer
        .subarray(0, 8)
        .equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
    ) {
      return "image/png";
    }
    if (
      buffer.length >= 12 &&
      buffer.toString("ascii", 0, 4) === "RIFF" &&
      buffer.toString("ascii", 8, 12) === "WEBP"
    ) {
      return "image/webp";
    }
    if (buffer.length >= 12 && buffer.toString("ascii", 4, 8) === "ftyp") {
      return "video/mp4";
    }
    return null;
  }

  private hasExpectedImageSignature(
    contentType: string,
    buffer: Buffer,
  ): boolean {
    if (contentType === "video/mp4") {
      return buffer.length >= 12 && buffer.toString("ascii", 4, 8) === "ftyp";
    }
    if (contentType === "image/jpeg") {
      return (
        buffer.length >= 3 &&
        buffer[0] === 0xff &&
        buffer[1] === 0xd8 &&
        buffer[2] === 0xff
      );
    }
    if (contentType === "image/png") {
      return (
        buffer.length >= 8 &&
        buffer
          .subarray(0, 8)
          .equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
      );
    }
    if (contentType === "image/webp") {
      return (
        buffer.length >= 12 &&
        buffer.toString("ascii", 0, 4) === "RIFF" &&
        buffer.toString("ascii", 8, 12) === "WEBP"
      );
    }
    return false;
  }

  private readMp4DurationSeconds(buffer: Buffer): number | null {
    const read32 = (offset: number) =>
      offset >= 0 && offset + 4 <= buffer.length
        ? buffer.readUInt32BE(offset)
        : null;
    const read64 = (offset: number) =>
      offset >= 0 && offset + 8 <= buffer.length
        ? Number(buffer.readBigUInt64BE(offset))
        : null;

    // mvhd is the MP4 movie-header atom. Version 0 stores a 32-bit
    // duration; version 1 stores a 64-bit duration.
    for (let i = 4; i + 24 <= buffer.length; i++) {
      if (buffer.toString("ascii", i, i + 4) !== "mvhd") continue;
      const version = buffer[i + 4];
      const timescale = read32(i + (version === 1 ? 24 : 16));
      const duration = version === 1 ? read64(i + 28) : read32(i + 20);
      if (timescale && duration !== null && timescale > 0) {
        return duration / timescale;
      }
    }
    return null;
  }

  async listMediaObjects(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const events = await this.prisma.auditEvent.findMany({
      where: {
        actorId: session.accountId,
        action: "module2.media.uploaded",
      },
      orderBy: { createdAt: "desc" },
      take: 40,
    });
    return events.map((event) => {
      const meta =
        event.redactedMetadata &&
        typeof event.redactedMetadata === "object" &&
        !Array.isArray(event.redactedMetadata)
          ? (event.redactedMetadata as Record<string, unknown>)
          : {};
      return {
        uploadId: event.targetId ?? event.id,
        action: event.action,
        actorId: event.actorId,
        fileName: typeof meta.fileName === "string" ? meta.fileName : "media",
        purpose: typeof meta.purpose === "string" ? meta.purpose : "post",
        contentType:
          typeof meta.contentType === "string"
            ? meta.contentType
            : "image/jpeg",
        provider:
          typeof meta.provider === "string" ? meta.provider : "google_drive",
        objectKey: typeof meta.objectKey === "string" ? meta.objectKey : "",
        driveFileId:
          typeof meta.driveFileId === "string" ? meta.driveFileId : null,
        sizeBytes: typeof meta.sizeBytes === "number" ? meta.sizeBytes : null,
        publicUrl: typeof meta.publicUrl === "string" ? meta.publicUrl : "",
        createdAt: event.createdAt.toISOString(),
      };
    });
  }

  async resolveMediaObject(
    authorization: string | undefined,
    uploadId: string,
  ): Promise<{
    contentType: string;
    buffer: Buffer;
    redirectUrl?: string;
  }> {
    const session = await this.auth.authenticateAuthorization(authorization);
    const [event, asset] = await Promise.all([
      this.prisma.auditEvent.findFirst({
        where: {
          targetId: uploadId,
          action: "module2.media.uploaded",
        },
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.mediaAsset.findUnique({
        where: { id: uploadId },
      }),
    ]);
    if (!event) {
      throw new NotFoundException("The media upload record was not found.");
    }
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.directMessage?.findFirst !== "function") {
      throw new InternalServerErrorException(
        "Direct-message media authorization is unavailable.",
      );
    }
    const directMessageAttachment = await anyPrisma.directMessage.findFirst({
      where: { mediaUploadId: uploadId },
      select: {
        senderAccountId: true,
        recipientAccountId: true,
        requestStatus: true,
      },
    });
    const isDirectMessageParticipant = directMessageAttachment
      ? directMessageAttachment.senderAccountId === session.accountId ||
        directMessageAttachment.recipientAccountId === session.accountId
      : false;
    if (directMessageAttachment && !isDirectMessageParticipant) {
      throw new ForbiddenException(
        "Direct-message media is restricted to the conversation participants.",
      );
    }
    if (
      directMessageAttachment &&
      (asset?.ownerAccountId ?? event.actorId) !==
        directMessageAttachment.senderAccountId
    ) {
      throw new ForbiddenException(
        "Direct-message media ownership does not match its sender.",
      );
    }
    if (
      directMessageAttachment &&
      directMessageAttachment.recipientAccountId === session.accountId &&
      directMessageAttachment.requestStatus !== "ACCEPTED"
    ) {
      throw new ForbiddenException(
        "Accept this message request before viewing its attachment.",
      );
    }
    if (
      directMessageAttachment &&
      directMessageAttachment.senderAccountId !== session.accountId &&
      session.testAccessApproved !== true &&
      (session.account.status !== "ACTIVE" ||
        session.account.verificationStatus !== "VERIFIED")
    ) {
      throw new ForbiddenException(
        "Verified active membership is required to view this attachment.",
      );
    }
    if (
      !asset &&
      event.actorId !== session.accountId &&
      !directMessageAttachment
    ) {
      throw new ForbiddenException("Media access is restricted to its owner.");
    }
    if (
      asset &&
      (asset.deletedAt ||
        ["DELETED", "REMOVED", "MODERATED"].includes(asset.status))
    ) {
      throw new NotFoundException("This media is no longer available.");
    }

    const isOwner = asset
      ? asset.ownerAccountId === session.accountId
      : event.actorId === session.accountId;
    let attachedPost: {
      id: string;
      authorAccountId: string | null;
      visibility: string;
      status: string;
      deletedAt: Date | null;
    } | null = null;
    if (asset?.postId) {
      attachedPost = await this.prisma.communityPost.findUnique({
        where: { id: asset.postId },
        select: {
          id: true,
          authorAccountId: true,
          visibility: true,
          status: true,
          deletedAt: true,
        },
      });
      if (
        !attachedPost ||
        attachedPost.deletedAt ||
        !["PUBLISHED", "EDITED"].includes(attachedPost.status)
      ) {
        throw new NotFoundException(
          "The post containing this media is no longer available.",
        );
      }
    }

    if (!isOwner && !directMessageAttachment) {
      if (
        session.testAccessApproved !== true &&
        (session.account.status !== "ACTIVE" ||
          session.account.verificationStatus !== "VERIFIED")
      ) {
        throw new ForbiddenException(
          "Verified active membership is required to view this media.",
        );
      }
      const visibility =
        attachedPost?.visibility ?? asset?.visibility ?? "VERIFIED_MEMBERS";
      if (visibility === "PRIVATE_SELF") {
        throw new ForbiddenException("This media is private to its owner.");
      }
      if (visibility === "FOLLOWERS_ONLY") {
        if (!asset?.ownerAccountId) {
          throw new ForbiddenException(
            "This media is restricted to the owner's followers.",
          );
        }
        const ownerProfile = await this.prisma.memberProfile.findUnique({
          where: { accountId: asset.ownerAccountId },
          select: { username: true },
        });
        const ownerDirectoryProfile = ownerProfile?.username
          ? await this.prisma.communityDirectoryProfile.findUnique({
              where: { username: ownerProfile.username },
              select: { id: true },
            })
          : null;
        const follow = ownerDirectoryProfile
          ? await this.prisma.memberFollow.findUnique({
              where: {
                accountId_directoryProfileId: {
                  accountId: session.accountId,
                  directoryProfileId: ownerDirectoryProfile.id,
                },
              },
              select: { isFollowing: true },
            })
          : null;
        if (!follow?.isFollowing) {
          throw new ForbiddenException(
            "Following the post owner is required to view this media.",
          );
        }
      } else if (visibility !== "VERIFIED_MEMBERS") {
        throw new ForbiddenException("Media visibility does not allow access.");
      }
    }

    const meta =
      event.redactedMetadata &&
      typeof event.redactedMetadata === "object" &&
      !Array.isArray(event.redactedMetadata)
        ? (event.redactedMetadata as Record<string, unknown>)
        : {};
    const driveFileId =
      asset?.driveFileId ??
      (typeof meta.driveFileId === "string" ? meta.driveFileId : null);
    if (
      !driveFileId ||
      (meta.provider !== "google_drive" &&
        asset?.storageProvider !== "GOOGLE_DRIVE")
    ) {
      throw new NotFoundException(
        "This media record has no retrievable Google Drive file. Upload the image again to replace it.",
      );
    }

    const recordedContentType = asset?.contentType ?? meta.contentType;
    if (
      driveFileId.startsWith("inline-db-") &&
      typeof meta.inlineBase64 === "string" &&
      meta.inlineBase64.length > 0
    ) {
      const inlineBuffer = Buffer.from(meta.inlineBase64, "base64");
      const inlineType =
        typeof recordedContentType === "string" &&
        ["image/jpeg", "image/png", "image/webp", "video/mp4"].includes(
          recordedContentType,
        )
          ? recordedContentType
          : "image/jpeg";
      return {
        contentType: inlineType,
        buffer: inlineBuffer,
      };
    }

    try {
      const media = await this.googleDrive.downloadFile(driveFileId);
      const storedContentType =
        typeof recordedContentType === "string" &&
        ["image/jpeg", "image/png", "image/webp", "video/mp4"].includes(
          recordedContentType,
        )
          ? recordedContentType
          : media.contentType;
      return {
        contentType: storedContentType,
        buffer: media.buffer,
      };
    } catch (driveDownloadErr) {
      if (
        typeof meta.inlineBase64 === "string" &&
        meta.inlineBase64.length > 0
      ) {
        const inlineBuffer = Buffer.from(meta.inlineBase64, "base64");
        const inlineType =
          typeof recordedContentType === "string" &&
          ["image/jpeg", "image/png", "image/webp", "video/mp4"].includes(
            recordedContentType,
          )
            ? recordedContentType
            : "image/jpeg";
        return {
          contentType: inlineType,
          buffer: inlineBuffer,
        };
      }
      throw driveDownloadErr;
    }
  }

  private async severFollowsBetweenAccounts(
    blockerAccountId: string,
    blockedVariants: string[],
  ) {
    const anyPrisma = this.prisma as Record<string, any>;
    if (
      blockedVariants.length === 0 ||
      typeof anyPrisma.communityDirectoryProfile?.findFirst !== "function"
    ) {
      return;
    }
    try {
      const targetDir = await anyPrisma.communityDirectoryProfile
        .findFirst({ where: { username: { in: blockedVariants } } })
        .catch(() => null);
      if (targetDir && typeof anyPrisma.memberFollow?.updateMany === "function") {
        await anyPrisma.memberFollow
          .updateMany({
            where: {
              accountId: blockerAccountId,
              directoryProfileId: targetDir.id,
            },
            data: { isFollowing: false },
          })
          .catch(() => undefined);
      }
      const viewerProfile = await anyPrisma.memberProfile
        ?.findUnique({ where: { accountId: blockerAccountId } })
        .catch(() => null);
      const targetProfile = await anyPrisma.memberProfile
        ?.findFirst({ where: { username: { in: blockedVariants } } })
        .catch(() => null);
      if (viewerProfile?.username && targetProfile?.accountId) {
        const viewerVariants = this.buildHandleVariants(viewerProfile.username);
        const viewerDir = await anyPrisma.communityDirectoryProfile
          .findFirst({ where: { username: { in: viewerVariants } } })
          .catch(() => null);
        if (viewerDir && typeof anyPrisma.memberFollow?.updateMany === "function") {
          await anyPrisma.memberFollow
            .updateMany({
              where: {
                accountId: targetProfile.accountId,
                directoryProfileId: viewerDir.id,
              },
              data: { isFollowing: false },
            })
            .catch(() => undefined);
        }
      }
    } catch {
      // Best-effort follow severance
    }
  }

  async ensureBlockedUser(
    authorization: string | undefined,
    dto: { blockedUsername: string; blockedDisplayName?: string },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const rawUsername = (dto.blockedUsername ?? "").trim();
    if (!rawUsername) {
      throw new BadRequestException("Provide a username to block.");
    }
    const cleanHandle = this.normalizeModerationHandle(rawUsername);
    const canonicalUsername = cleanHandle ? `@${cleanHandle}` : rawUsername;
    const variants = this.buildHandleVariants(rawUsername);
    const anyPrisma = this.prisma as Record<string, any>;

    let existing = await this.prisma.memberModerationBlock
      .findUnique({
        where: {
          accountId_blockedUsername: {
            accountId: session.accountId,
            blockedUsername: canonicalUsername,
          },
        },
      })
      .catch(() => null);

    if (
      !existing &&
      typeof anyPrisma.memberModerationBlock?.findFirst === "function"
    ) {
      existing = await anyPrisma.memberModerationBlock
        .findFirst({
          where: {
            accountId: session.accountId,
            blockedUsername: { in: variants },
          },
        })
        .catch(() => null);
    }

    if (existing) {
      await this.severFollowsBetweenAccounts(session.accountId, variants);
      return {
        id: existing.id,
        blockedUsername: existing.blockedUsername,
        blockedDisplayName: existing.blockedDisplayName,
        isBlocked: true,
      };
    }

    const created = await this.prisma.memberModerationBlock.create({
      data: {
        accountId: session.accountId,
        blockedUsername: canonicalUsername,
        blockedDisplayName:
          (dto.blockedDisplayName ?? "").trim() || canonicalUsername.replace(/^@+/, ""),
      },
    });
    await this.severFollowsBetweenAccounts(session.accountId, variants);
    return {
      id: created.id,
      blockedUsername: created.blockedUsername,
      blockedDisplayName: created.blockedDisplayName,
      isBlocked: true,
    };
  }

  async toggleBlockedUser(
    authorization: string | undefined,
    dto: ToggleBlockedUserDto & { mode?: "BLOCK" | "UNBLOCK" | "TOGGLE" },
  ) {
    const requestedMode = (dto.mode ?? "TOGGLE").toUpperCase();
    if (requestedMode === "BLOCK") {
      return this.ensureBlockedUser(authorization, dto);
    }

    const session = await this.auth.authenticateAuthorization(authorization);
    const rawUsername = dto.blockedUsername.trim();
    const cleanHandle = this.normalizeModerationHandle(rawUsername);
    const canonicalUsername = cleanHandle ? `@${cleanHandle}` : rawUsername;
    const variants = this.buildHandleVariants(rawUsername);
    const anyPrisma = this.prisma as Record<string, any>;

    let existing = await this.prisma.memberModerationBlock
      .findUnique({
        where: {
          accountId_blockedUsername: {
            accountId: session.accountId,
            blockedUsername: rawUsername,
          },
        },
      })
      .catch(() => null);

    if (
      !existing &&
      typeof anyPrisma.memberModerationBlock?.findFirst === "function"
    ) {
      existing = await anyPrisma.memberModerationBlock
        .findFirst({
          where: {
            accountId: session.accountId,
            blockedUsername: { in: variants },
          },
        })
        .catch(() => null);
    }

    if (existing || requestedMode === "UNBLOCK") {
      if (existing) {
        await this.prisma.memberModerationBlock.delete({
          where: { id: existing.id },
        });
      }
      if (typeof anyPrisma.memberModerationBlock?.deleteMany === "function") {
        await anyPrisma.memberModerationBlock
          .deleteMany({
            where: {
              accountId: session.accountId,
              blockedUsername: { in: variants },
            },
          })
          .catch(() => undefined);
      }
      return {
        blockedUsername: canonicalUsername,
        isBlocked: false,
      };
    }

    const created = await this.prisma.memberModerationBlock.create({
      data: {
        accountId: session.accountId,
        blockedUsername: canonicalUsername,
        blockedDisplayName: dto.blockedDisplayName.trim() || canonicalUsername,
      },
    });

    await this.severFollowsBetweenAccounts(session.accountId, variants);

    return {
      id: created.id,
      blockedUsername: created.blockedUsername,
      blockedDisplayName: created.blockedDisplayName,
      isBlocked: true,
    };
  }

  async toggleMuteOrRestrictMember(
    authorization: string | undefined,
    dto: {
      targetUsername?: string;
      targetDisplayName?: string;
      mode?: "MUTE" | "UNMUTE" | "RESTRICT" | "UNRESTRICT" | "HIDE_POST" | "UNHIDE_POST";
      postId?: string;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const mode = (dto.mode ?? (dto.postId ? "HIDE_POST" : "MUTE")).toUpperCase();

    const currentPref =
      typeof anyPrisma.memberPrivacyPreference?.findUnique === "function"
        ? await anyPrisma.memberPrivacyPreference
            .findUnique({ where: { accountId: session.accountId } })
            .catch(() => null)
        : null;

    if (mode === "HIDE_POST" || mode === "UNHIDE_POST") {
      const postId = (dto.postId ?? "").trim();
      if (!postId) {
        throw new BadRequestException("Provide a postId to hide or unhide.");
      }
      const set = new Set<string>(this.parseStringArrayJson(currentPref?.hiddenPostIds));
      const shouldHide = mode === "HIDE_POST" ? !set.has(postId) : false;
      if (shouldHide) {
        set.add(postId);
      } else {
        set.delete(postId);
      }
      const nextHidden = [...set];
      if (typeof anyPrisma.memberPrivacyPreference?.upsert === "function") {
        await anyPrisma.memberPrivacyPreference.upsert({
          where: { accountId: session.accountId },
          create: {
            accountId: session.accountId,
            hiddenPostIds: nextHidden,
          },
          update: {
            hiddenPostIds: nextHidden,
          },
        });
      }
      return {
        postId,
        isHidden: shouldHide,
        hiddenPostIds: nextHidden,
      };
    }

    const handle = this.normalizeModerationHandle(dto.targetUsername ?? "");
    if (!handle) {
      throw new BadRequestException("Provide a member username to mute or restrict.");
    }

    if (mode === "RESTRICT" || mode === "UNRESTRICT") {
      const set = new Set<string>(
        this.parseStringArrayJson(currentPref?.restrictedHandles)
          .map((h) => this.normalizeModerationHandle(h))
          .filter(Boolean),
      );
      const nextState = mode === "UNRESTRICT" ? false : !set.has(handle);
      if (nextState) {
        set.add(handle);
      } else {
        set.delete(handle);
      }
      const nextRestricted = [...set];
      if (typeof anyPrisma.memberPrivacyPreference?.upsert === "function") {
        await anyPrisma.memberPrivacyPreference.upsert({
          where: { accountId: session.accountId },
          create: {
            accountId: session.accountId,
            restrictedHandles: nextRestricted,
          },
          update: {
            restrictedHandles: nextRestricted,
          },
        });
      }
      return {
        targetUsername: `@${handle}`,
        isRestricted: nextState,
        restrictedUsers: nextRestricted.map((h) => `@${h}`),
      };
    }

    const set = new Set<string>(
      this.parseStringArrayJson(currentPref?.mutedHandles)
        .map((h) => this.normalizeModerationHandle(h))
        .filter(Boolean),
    );
    const nextMuted = mode === "UNMUTE" ? false : !set.has(handle);
    if (nextMuted) {
      set.add(handle);
    } else {
      set.delete(handle);
    }
    const nextMutedList = [...set];
    if (typeof anyPrisma.memberPrivacyPreference?.upsert === "function") {
      await anyPrisma.memberPrivacyPreference.upsert({
        where: { accountId: session.accountId },
        create: {
          accountId: session.accountId,
          mutedHandles: nextMutedList,
        },
        update: {
          mutedHandles: nextMutedList,
        },
      });
    }
    return {
      targetUsername: `@${handle}`,
      isMuted: nextMuted,
      mutedUsers: nextMutedList.map((h) => `@${h}`),
    };
  }

  async getViewerModerationState(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const profile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const ctx = await this.resolveViewerModerationContext(
      session.accountId,
      profile?.username ?? null,
    );
    const blockedRows =
      typeof (this.prisma.memberModerationBlock as Record<string, any>)?.findMany ===
      "function"
        ? await this.prisma.memberModerationBlock
            .findMany({
              where: { accountId: session.accountId },
              orderBy: { createdAt: "desc" },
            })
            .catch(() => [])
        : [];
    return {
      blockedUsers: blockedRows.map((b: Record<string, any>) => ({
        id: b.id,
        blockedUsername: b.blockedUsername,
        blockedDisplayName: b.blockedDisplayName,
      })),
      blockedHandles: [...ctx.blockedHandles].map((h) => `@${h}`),
      mutedUsers: [...ctx.mutedHandles].map((h) => `@${h}`),
      restrictedUsers: [...ctx.restrictedHandles].map((h) => `@${h}`),
      reportedPostIds: [...ctx.reportedPostIds],
      hiddenPostIds: [...ctx.hiddenPostIds],
    };
  }

  // --- Module 3 Social Wall & Backward-Compatible Spec Methods ---

  async listCategories() {
    const defaults = [
      {
        slug: "following",
        name: "Following",
        description:
          "Updates from verified Sakhi members and circles you follow.",
        iconKey: "heart_handshake",
        accentColorHex: "#EC4899",
        isEnabled: true,
        displayOrder: 1,
      },
      {
        slug: "community",
        name: "Community",
        description:
          "Open discussions, peer encouragement, and shared experiences.",
        iconKey: "users",
        accentColorHex: "#A855F7",
        isEnabled: true,
        displayOrder: 2,
      },
      {
        slug: "trending",
        name: "Trending",
        description:
          "High-engagement conversations and timely topics across Sakhi.",
        iconKey: "flame",
        accentColorHex: "#F59E0B",
        isEnabled: true,
        displayOrder: 3,
      },
      {
        slug: "business_updates",
        name: "Business Updates",
        description:
          "Showcases, launches, and announcements from women-led businesses.",
        iconKey: "briefcase",
        accentColorHex: "#8B5CF6",
        isEnabled: true,
        displayOrder: 4,
      },
      {
        slug: "safety_awareness",
        name: "Safety Awareness",
        description:
          "Verified safety advisories, commute tips, and legal/self-defense awareness.",
        iconKey: "shield_check",
        accentColorHex: "#10B981",
        isEnabled: true,
        displayOrder: 5,
      },
      {
        slug: "wellness_lifestyle",
        name: "Wellness and Lifestyle",
        description:
          "Mindfulness, physical health, journaling, and holistic lifestyle guidance.",
        iconKey: "sparkles",
        accentColorHex: "#14B8A6",
        isEnabled: true,
        displayOrder: 6,
      },
    ];
    if (!this.prisma.feedCategoryConfig?.findMany) {
      return { categories: defaults };
    }
    const rows = await this.prisma.feedCategoryConfig
      .findMany({
        where: { isEnabled: true },
        orderBy: { displayOrder: "asc" },
      })
      .catch(() => []);
    return { categories: rows.length > 0 ? rows : defaults };
  }

  async listPosts(
    authorization: string | undefined,
    query: {
      categorySlug?: string;
      topic?: string;
      search?: string;
      savedOnly?: boolean;
      limit?: number;
      page?: number;
      cursor?: string;
    } = {},
  ) {
    const boot = await this.bootstrap(authorization);
    const blockedHandles = new Set(
      (boot.blockedUsers ?? []).map((u) => u.blockedUsername.toLowerCase()),
    );
    const basePool = query.savedOnly
      ? [
          ...boot.communityPosts,
          ...boot.exploreRecommendedPosts,
          ...(boot.profilePosts ?? []),
        ]
      : [...boot.communityPosts, ...boot.exploreRecommendedPosts];
    const seenIds = new Set<string>();
    let items = basePool.filter((post) => {
      if (seenIds.has(post.id)) return false;
      seenIds.add(post.id);
      return !blockedHandles.has(post.authorUsername.toLowerCase());
    });
    const slug = (query.categorySlug || query.topic || "").trim().toLowerCase();
    if (slug && slug !== "all" && slug !== "community") {
      if (slug === "following") {
        const followedHandles = new Set(
          (boot.followers ?? [])
            .filter((f) => f.isFollowing)
            .map((f) => f.username.toLowerCase()),
        );
        items = items.filter((p) =>
          followedHandles.has(p.authorUsername.toLowerCase()),
        );
      } else if (slug === "trending") {
        const scorePost = (p: Record<string, any>): number => {
          const likes = Number(p.likesCount ?? 0);
          const comments = Number(p.commentsCount ?? 0);
          const breakdown =
            p.reactionBreakdown && typeof p.reactionBreakdown === "object"
              ? Object.keys(p.reactionBreakdown).length
              : 0;
          const hasMedia = Boolean(p.imageAsset && String(p.imageAsset).trim());
          const verifiedBoost = p.authorVerified ? 1.12 : 1.0;
          const mediaBoost = hasMedia ? 1.22 : 1.0;
          const rawEngagement =
            likes * 1.8 +
            Math.log10(1 + likes) * 3.5 +
            comments * 3.4 +
            breakdown * 2.6 +
            (p.isSaved ? 4.0 : 0);
          const createdMs = p.createdAtIso
            ? Date.parse(String(p.createdAtIso))
            : Date.now() - 4 * 3600 * 1000;
          const ageHours = Math.max(
            0.25,
            (Date.now() -
              (Number.isFinite(createdMs) ? createdMs : Date.now())) /
              (1000 * 3600),
          );
          return (
            (rawEngagement * verifiedBoost * mediaBoost) /
            Math.pow(ageHours + 2.0, 1.45)
          );
        };
        const engaged = items.filter((p) => {
          const reactionBreakdown = (
            p as typeof p & { reactionBreakdown?: Record<string, any> }
          ).reactionBreakdown;
          return (
            Number(p.likesCount ?? 0) > 0 ||
            Number(p.commentsCount ?? 0) > 0 ||
            Object.keys(reactionBreakdown ?? {}).length > 0
          );
        });
        const pool = engaged.length > 0 ? engaged : items;
        items = [...pool].sort((a, b) => scorePost(b) - scorePost(a));
      } else {
        items = items.filter(
          (p) =>
            (p.categoryBadge || "")
              .toLowerCase()
              .includes(slug.replace(/_/g, " ")) ||
            (p as Record<string, unknown>).categorySlug === slug,
        );
      }
    }
    if (query.savedOnly) {
      items = items.filter((p) => p.isSaved);
    }
    if (query.search?.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter(
        (p) =>
          p.content.toLowerCase().includes(q) ||
          p.authorName.toLowerCase().includes(q) ||
          p.authorUsername.toLowerCase().includes(q),
      );
    }
    const totalCount = items.length;
    const safeLimit = Math.min(Math.max(query.limit ?? 30, 1), 100);
    const safePage = Math.max(query.page ?? 1, 1);
    let startIndex = (safePage - 1) * safeLimit;
    if (query.cursor && query.cursor.trim().length > 0) {
      const cursorIdx = items.findIndex((p) => p.id === query.cursor?.trim());
      if (cursorIdx >= 0) {
        startIndex = cursorIdx + 1;
      }
    }
    const limited = items.slice(startIndex, startIndex + safeLimit);
    const hasMore = startIndex + safeLimit < totalCount;
    const nextCursor =
      hasMore && limited.length > 0 ? limited[limited.length - 1]?.id ?? null : null;
    return {
      items: limited,
      posts: limited,
      total: limited.length,
      totalCount,
      page: safePage,
      limit: safeLimit,
      hasMore,
      nextCursor,
    };
  }

  async editPost(
    authorization: string | undefined,
    postId: string,
    dto: {
      content?: string;
      body?: string;
      categorySlug?: string;
      categoryBadge?: string;
      visibility?: string;
      cropPreset?: string;
      hashtags?: string[];
      locationTag?: string;
      allowComments?: boolean;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!existing || existing.deletedAt) {
      throw new NotFoundException("Community post was not found.");
    }
    if (
      existing.authorAccountId &&
      existing.authorAccountId !== session.accountId
    ) {
      throw new ForbiddenException({
        code: "post_edit_forbidden",
        message: "Only the post author can edit this post.",
      });
    }
    const nextContent = (dto.content ?? dto.body ?? existing.content).trim();
    const updated = await this.prisma.communityPost.update({
      where: { id: postId },
      data: {
        content: nextContent,
        ...(dto.categorySlug
          ? { categorySlug: dto.categorySlug.trim().toLowerCase() }
          : {}),
        ...(dto.categoryBadge
          ? { categoryBadge: dto.categoryBadge.trim() }
          : {}),
        ...(dto.visibility ? { visibility: dto.visibility.trim() } : {}),
        ...(dto.cropPreset ? { cropPreset: dto.cropPreset.trim() } : {}),
        ...(dto.hashtags ? { hashtags: dto.hashtags } : {}),
        ...(dto.locationTag !== undefined
          ? { locationTag: dto.locationTag?.trim() || null }
          : {}),
        ...(dto.allowComments !== undefined
          ? { allowComments: dto.allowComments }
          : {}),
        status: "EDITED",
      },
    });
    return {
      id: updated.id,
      postId: updated.id,
      content: updated.content,
      body: updated.content,
      categorySlug: updated.categorySlug,
      categoryBadge: updated.categoryBadge,
      visibility: updated.visibility,
      cropPreset: updated.cropPreset,
      status: updated.status,
      updatedAt: updated.updatedAt.toISOString(),
    };
  }

  async deletePost(authorization: string | undefined, postId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;

    // Support unit test mock shape in test/module2.delete-post.spec.ts
    if (anyPrisma.memberPost?.findFirst) {
      const owned = await anyPrisma.memberPost.findFirst({
        where: {
          id: postId,
          accountId: session.accountId,
          status: "PUBLISHED",
          deletedAt: null,
        },
        select: { id: true },
      });
      if (!owned) {
        throw new NotFoundException("Post was not found or cannot be deleted.");
      }
      const now = new Date();
      await anyPrisma.$transaction(async (tx: Record<string, any>) => {
        await tx.memberPost.update({
          where: { id: postId },
          data: {
            body: "[removed by author]",
            mediaRef: null,
            status: "REMOVED",
            deletedAt: now,
          },
        });
        await tx.memberPostComment.updateMany({
          where: { postId, deletedAt: null },
          data: { body: "[removed]", deletedAt: now },
        });
        await tx.memberPostLike.deleteMany({ where: { postId } });
        await tx.memberPostBookmark.deleteMany({ where: { postId } });
        await tx.postAudienceMember.deleteMany({ where: { postId } });
        await tx.auditEvent.createMany({
          data: {
            actorType: "MEMBER",
            actorId: session.accountId,
            action: "module2.post.deleted_by_author",
            targetType: "member_post",
            targetId: postId,
            outcome: "success",
            requestId: randomUUID(),
          },
        });
      });
      return { postId, deleted: true };
    }

    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!post || post.deletedAt) {
      throw new NotFoundException("Community post was not found.");
    }
    if (post.authorAccountId && post.authorAccountId !== session.accountId) {
      throw new ForbiddenException({
        code: "post_delete_forbidden",
        message: "Only the post author can delete this post.",
      });
    }
    await this.prisma.communityPost.update({
      where: { id: postId },
      data: {
        status: "DELETED_BY_AUTHOR",
        deletedAt: new Date(),
      },
    });
    await this.prisma.auditEvent.create({
      data: {
        actorType: "MEMBER",
        actorId: session.accountId,
        action: "module2.post.deleted_by_author",
        targetType: "community_post",
        targetId: postId,
        outcome: "success",
        requestId: randomUUID(),
      },
    });
    return { postId, deleted: true };
  }

  async reactToPost(
    authorization: string | undefined,
    postId: string,
    reactionType = "LIKE",
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const normalizedType = reactionType.trim().toUpperCase();
    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    if (!post || post.deletedAt) {
      throw new NotFoundException("Community post was not found.");
    }

    if (!this.prisma.communityPostReaction) {
      const toggled = await this.togglePostLike(authorization, postId);
      return {
        ...toggled,
        viewerReaction: toggled.isLiked ? normalizedType : null,
        reactionsCount: toggled.likesCount,
        reactionBreakdown: { [normalizedType]: toggled.likesCount },
      };
    }

    const existing = await this.prisma.communityPostReaction.findUnique({
      where: {
        postId_accountId: {
          postId,
          accountId: session.accountId,
        },
      },
    });

    let viewerReaction: string | null = normalizedType;
    let delta = 0;

    if (existing && existing.reactionType === normalizedType) {
      await this.prisma.communityPostReaction.delete({
        where: { id: existing.id },
      });
      await this.prisma.communityPostLike
        .deleteMany({ where: { postId, accountId: session.accountId } })
        .catch(() => undefined);
      viewerReaction = null;
      delta = -1;
    } else if (existing) {
      await this.prisma.communityPostReaction.update({
        where: { id: existing.id },
        data: { reactionType: normalizedType },
      });
      viewerReaction = normalizedType;
      delta = 0;
    } else {
      await this.prisma.communityPostReaction.create({
        data: {
          postId,
          accountId: session.accountId,
          reactionType: normalizedType,
        },
      });
      await this.prisma.communityPostLike
        .upsert({
          where: {
            postId_accountId: { postId, accountId: session.accountId },
          },
          create: { postId, accountId: session.accountId },
          update: {},
        })
        .catch(() => undefined);
      viewerReaction = normalizedType;
      delta = 1;
    }

    const updatedPost = await this.prisma.communityPost.update({
      where: { id: postId },
      data: { likesCount: Math.max(0, post.likesCount + delta) },
    });

    const allReactions = await this.prisma.communityPostReaction
      .findMany({ where: { postId } })
      .catch(() => []);
    const reactionBreakdown: Record<string, number> = {};
    for (const r of allReactions) {
      reactionBreakdown[r.reactionType] =
        (reactionBreakdown[r.reactionType] ?? 0) + 1;
    }

    return {
      postId,
      isLiked: viewerReaction !== null,
      viewerReaction,
      likesCount: updatedPost.likesCount,
      reactionsCount: updatedPost.likesCount,
      reactionBreakdown,
    };
  }

  async listPostComments(authorization: string | undefined, postId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const post = await this.prisma.communityPost
      .findUnique({ where: { id: postId } })
      .catch(() => null);
    const comments = await this.prisma.communityPostComment.findMany({
      where: {
        postId,
        deletedAt: null,
        isRemovedByModerator: false,
      },
      orderBy: { createdAt: "asc" },
    });

    const authorIds = Array.from(
      new Set(
        comments
          .map((c: Record<string, any>) =>
            c.accountId ? String(c.accountId) : "",
          )
          .filter(Boolean),
      ),
    );
    const profiles =
      authorIds.length > 0 &&
      typeof (this.prisma.memberProfile as Record<string, any>)?.findMany ===
        "function"
        ? await this.prisma.memberProfile
            .findMany({ where: { accountId: { in: authorIds } } })
            .catch(() => [])
        : [];
    const profileByAccountId = new Map<string, Record<string, any>>();
    for (const p of profiles as Array<Record<string, any>>) {
      if (p?.accountId) profileByAccountId.set(String(p.accountId), p);
    }

    const viewerProfileForComments =
      typeof (this.prisma.memberProfile as Record<string, any>)?.findUnique ===
      "function"
        ? await this.prisma.memberProfile
            .findUnique({ where: { accountId: session.accountId } })
            .catch(() => null)
        : null;
    const modCtxForComments = await this.resolveViewerModerationContext(
      session.accountId,
      viewerProfileForComments?.username ?? null,
    );
    const visibleComments = comments.filter((c: Record<string, any>) => {
      if (c.id && modCtxForComments.reportedCommentIds.has(String(c.id))) {
        return false;
      }
      if (
        c.accountId &&
        modCtxForComments.accountsWhoBlockedViewer.has(String(c.accountId))
      ) {
        return false;
      }
      const mp = c.accountId
        ? profileByAccountId.get(String(c.accountId))
        : null;
      const handle = this.deriveUsername(
        String(mp?.displayName ?? c.authorName ?? "Sakhi Member"),
        mp?.username ?? null,
      );
      if (
        modCtxForComments.blockedHandles.has(
          this.normalizeModerationHandle(handle),
        )
      ) {
        return false;
      }
      return true;
    });

    const mapped = visibleComments.map((c: Record<string, any>) => {
      const isOwn = Boolean(c.accountId && c.accountId === session.accountId);
      const isPostOwner = Boolean(
        post?.authorAccountId && post.authorAccountId === session.accountId,
      );
      const mp = c.accountId
        ? profileByAccountId.get(String(c.accountId))
        : null;
      const resolvedAuthorName =
        mp?.displayName ?? c.authorName ?? "Sakhi Member";
      const resolvedUsername = this.deriveUsername(
        String(resolvedAuthorName),
        mp?.username ?? null,
      );
      const resolvedAvatar = mp
        ? this.resolveMemberAvatar(mp.avatarAsset, mp.avatarMediaAssetId)
        : "";
      const createdDate =
        c.createdAt instanceof Date
          ? c.createdAt
          : new Date(String(c.createdAt ?? Date.now()));
      const updatedDate =
        c.updatedAt instanceof Date
          ? c.updatedAt
          : new Date(String(c.updatedAt ?? createdDate));
      const isEdited = updatedDate.getTime() - createdDate.getTime() > 1500;
      const likeSet = Module2Service.commentLikesMap.get(String(c.id));
      const likesCount = likeSet ? likeSet.size : 0;
      const isLiked = Boolean(likeSet && likeSet.has(session.accountId));

      let cleanBody = String(c.content ?? "");
      if (c.replyToHandle) {
        const rh = String(c.replyToHandle).trim();
        const normRh = rh.startsWith("@") ? rh : `@${rh}`;
        if (cleanBody.toLowerCase().startsWith(`${normRh.toLowerCase()} `)) {
          const stripped = cleanBody.slice(normRh.length).trim();
          if (stripped.length > 0) cleanBody = stripped;
        }
      }

      return {
        id: c.id,
        commentId: c.id,
        postId: c.postId,
        authorAccountId: c.accountId,
        authorName: resolvedAuthorName,
        authorUsername: resolvedUsername,
        authorAvatar: resolvedAvatar,
        content: cleanBody,
        body: cleanBody,
        parentCommentId: c.parentCommentId ?? null,
        replyToHandle: c.replyToHandle ?? null,
        isOwnComment: isOwn,
        canEdit: isOwn,
        canDelete: isOwn || isPostOwner,
        isEdited,
        likesCount,
        isLiked,
        timestamp: this.formatRelativeTime(createdDate),
        createdAt: this.formatRelativeTime(createdDate),
        createdAtIso: createdDate.toISOString(),
      };
    });
    const threaded = this.groupThreadedComments(mapped);
    if (post && post.commentsCount !== threaded.length) {
      void this.prisma.communityPost
        .update({
          where: { id: postId },
          data: { commentsCount: threaded.length },
        })
        .catch(() => undefined);
    }
    return {
      items: threaded,
      comments: threaded,
      commentsCount: threaded.length,
      total: threaded.length,
    };
  }

  async editPostComment(
    authorization: string | undefined,
    postId: string,
    commentId: string,
    dto: { content?: string; body?: string },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.communityPostComment.findUnique({
      where: { id: commentId },
    });
    if (!existing || existing.postId !== postId || existing.deletedAt) {
      throw new NotFoundException("Comment was not found.");
    }
    if (existing.accountId !== session.accountId) {
      throw new ForbiddenException({
        code: "comment_edit_forbidden",
        message: "Only the comment author can edit this comment.",
      });
    }
    const nextText = (dto.content ?? dto.body ?? "").trim();
    if (!nextText) {
      throw new BadRequestException("Comment cannot be empty.");
    }
    const updated = await this.prisma.communityPostComment.update({
      where: { id: commentId },
      data: { content: nextText },
    });
    return {
      id: updated.id,
      commentId: updated.id,
      postId,
      authorName: updated.authorName,
      content: updated.content,
      body: updated.content,
      isEdited: true,
      updatedAt: updated.updatedAt.toISOString(),
    };
  }

  async deletePostComment(
    authorization: string | undefined,
    postId: string,
    commentId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.communityPostComment.findUnique({
      where: { id: commentId },
    });
    if (!existing || existing.postId !== postId || existing.deletedAt) {
      throw new NotFoundException("Comment was not found.");
    }
    const post = await this.prisma.communityPost.findUnique({
      where: { id: postId },
    });
    const isCommentOwner = existing.accountId === session.accountId;
    const isPostOwner = Boolean(
      post?.authorAccountId && post.authorAccountId === session.accountId,
    );
    if (!isCommentOwner && !isPostOwner) {
      throw new ForbiddenException({
        code: "comment_delete_forbidden",
        message:
          "Only the comment author or the post owner can delete this comment.",
      });
    }
    const now = new Date();
    await this.prisma.communityPostComment.update({
      where: { id: commentId },
      data: { deletedAt: now, content: "[removed]" },
    });
    let deletedChildCount = 0;
    const anyCommentDelegate = this.prisma.communityPostComment as unknown as Record<string, any>;
    if (typeof anyCommentDelegate?.updateMany === "function") {
      const childRes = await anyCommentDelegate
        .updateMany({
          where: {
            postId,
            parentCommentId: commentId,
            deletedAt: null,
          },
          data: { deletedAt: now, content: "[removed]" },
        })
        .catch(() => ({ count: 0 }));
      deletedChildCount = Number(childRes?.count ?? 0);
    }
    const totalRemoved = 1 + deletedChildCount;
    const exactRemainingCount =
      typeof anyCommentDelegate?.count === "function"
        ? await anyCommentDelegate
            .count({
              where: {
                postId,
                deletedAt: null,
                isRemovedByModerator: false,
              },
            })
            .catch(() => Math.max(0, (post?.commentsCount ?? totalRemoved) - totalRemoved))
        : Math.max(0, (post?.commentsCount ?? totalRemoved) - totalRemoved);
    if (post) {
      await this.prisma.communityPost.update({
        where: { id: postId },
        data: {
          commentsCount: exactRemainingCount,
        },
      });
    }
    return {
      deleted: true,
      commentId,
      postId,
      deletedCount: totalRemoved,
      commentsCount: exactRemainingCount,
    };
  }

  async toggleCommentLike(
    authorization: string | undefined,
    postId: string,
    commentId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    let set = Module2Service.commentLikesMap.get(commentId);
    if (!set) {
      set = new Set<string>();
      Module2Service.commentLikesMap.set(commentId, set);
    }
    const already = set.has(session.accountId);
    if (already) {
      set.delete(session.accountId);
    } else {
      set.add(session.accountId);
    }
    return {
      postId,
      commentId,
      isLiked: !already,
      likesCount: set.size,
    };
  }

  async votePollPost(
    authorization: string | undefined,
    postId: string,
    optionIndex: number,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    let meta = Module2Service.postPollMetaMap.get(postId);
    if (!meta) {
      meta = {
        question: "Community Poll",
        options: ["Option 1", "Option 2"],
        votes: {},
      };
      Module2Service.postPollMetaMap.set(postId, meta);
    }
    meta.votes[session.accountId] = optionIndex;
    const counts = meta.options.map((_, idx) =>
      Object.values(meta!.votes).filter((v) => v === idx).length,
    );
    return {
      postId,
      selectedOptionIndex: optionIndex,
      optionVoteCounts: counts,
      totalVotes: Object.keys(meta.votes).length,
    };
  }

  private async resolvePeerAccountIdForMessaging(
    peerIdOrHandle: string,
  ): Promise<{ accountId: string | null; username: string | null; displayName: string | null }> {
    const cleaned = (peerIdOrHandle ?? "").trim();
    if (!cleaned) {
      return { accountId: null, username: null, displayName: null };
    }
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      cleaned,
    );
    const anyPrisma = this.prisma as Record<string, any>;
    if (isUuid) {
      const byAccount = await anyPrisma.memberProfile
        ?.findUnique({
          where: { accountId: cleaned },
          select: { accountId: true, username: true, displayName: true },
        })
        .catch(() => null);
      if (byAccount?.accountId) {
        return {
          accountId: String(byAccount.accountId),
          username: byAccount.username ?? null,
          displayName: byAccount.displayName ?? null,
        };
      }
      const byDir = await anyPrisma.communityDirectoryProfile
        ?.findUnique({
          where: { id: cleaned },
          select: { id: true, username: true, name: true },
        })
        .catch(() => null);
      if (byDir?.username) {
        const variants = this.buildHandleVariants(byDir.username);
        const prof = await anyPrisma.memberProfile
          ?.findFirst({
            where: { username: { in: variants } },
            select: { accountId: true, username: true, displayName: true },
          })
          .catch(() => null);
        if (prof?.accountId) {
          return {
            accountId: String(prof.accountId),
            username: prof.username ?? byDir.username,
            displayName: prof.displayName ?? byDir.name ?? null,
          };
        }
      }
      return { accountId: cleaned, username: null, displayName: null };
    }

    const variants = this.buildHandleVariants(cleaned);
    const prof = await anyPrisma.memberProfile
      ?.findFirst({
        where: { username: { in: variants } },
        select: { accountId: true, username: true, displayName: true },
      })
      .catch(() => null);
    if (prof?.accountId) {
      return {
        accountId: String(prof.accountId),
        username: prof.username ?? cleaned,
        displayName: prof.displayName ?? null,
      };
    }
    return { accountId: null, username: cleaned, displayName: null };
  }

  private mapDirectMessageRow(
    message: Record<string, any>,
    viewerAccountId: string,
  ) {
    const createdDate =
      message.createdAt instanceof Date
        ? message.createdAt
        : new Date(String(message.createdAt ?? Date.now()));
    const readDate =
      message.readAt instanceof Date
        ? message.readAt
        : message.readAt
          ? new Date(String(message.readAt))
          : null;
    const isOwnMessage = message.senderAccountId === viewerAccountId;
    const isRead = isOwnMessage || Boolean(readDate);
    return {
      id: message.id,
      senderAccountId: message.senderAccountId,
      senderDirectoryProfileId: message.senderDirectoryProfileId ?? null,
      senderName: message.senderName,
      senderUsername: message.senderUsername,
      senderAvatar: message.senderAvatar ?? "",
      recipientId:
        message.recipientDirectoryProfileId ?? message.recipientAccountId,
      recipientAccountId: message.recipientAccountId,
      recipientDirectoryProfileId: message.recipientDirectoryProfileId ?? null,
      recipientHandle: message.recipientHandle,
      recipientName: message.recipientName,
      body: message.body,
      attachmentUrl: message.attachmentUrl ?? null,
      attachmentType: message.attachmentType ?? null,
      mediaUploadId: message.mediaUploadId ?? null,
      clientMessageId: message.clientMessageId ?? null,
      requestStatus: message.requestStatus ?? "ACCEPTED",
      readAt: readDate ? readDate.toISOString() : null,
      isRead,
      createdAt: createdDate.toISOString(),
      timestamp: this.formatRelativeTime(createdDate),
      isOwnMessage,
    };
  }

  async listDirectMessages(
    authorization: string | undefined,
    peerId?: string,
    options?: { cursor?: string; limit?: number },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    let peerAccountId: string | null = null;
    if (peerId && peerId.trim().length > 0) {
      const resolved = await this.resolvePeerAccountIdForMessaging(peerId);
      peerAccountId = resolved.accountId;
      if (!peerAccountId) {
        return { items: [], messages: [] };
      }
    }

    const where = peerAccountId
      ? {
          OR: [
            {
              senderAccountId: session.accountId,
              recipientAccountId: peerAccountId,
            },
            {
              senderAccountId: peerAccountId,
              recipientAccountId: session.accountId,
            },
          ],
        }
      : {
          OR: [
            { senderAccountId: session.accountId },
            { recipientAccountId: session.accountId },
          ],
        };
    const safeLimit =
      options?.limit && Number.isFinite(options.limit)
        ? Math.min(Math.max(Math.round(options.limit), 1), 250)
        : 250;
    const rows = await this.prisma.directMessage.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: safeLimit,
    });
    let chronological = [...rows].reverse();
    if (options?.cursor && options.cursor.trim().length > 0) {
      const idx = chronological.findIndex((m) => m.id === options.cursor?.trim());
      if (idx >= 0) {
        chronological = chronological.slice(idx + 1);
      }
    }
    const messages = chronological.map((message: Record<string, any>) =>
      this.mapDirectMessageRow(message, session.accountId),
    );
    return { items: messages, messages };
  }

  async listMessageConversations(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const viewerProfile =
      typeof anyPrisma.memberProfile?.findUnique === "function"
        ? await anyPrisma.memberProfile
            .findUnique({ where: { accountId: session.accountId } })
            .catch(() => null)
        : null;
    const modCtx = await this.resolveViewerModerationContext(
      session.accountId,
      viewerProfile?.username ?? null,
    );

    const allMessages = await this.listDirectMessages(authorization);
    const items = allMessages.messages ?? [];

    const follows =
      typeof anyPrisma.memberFollow?.findMany === "function"
        ? await anyPrisma.memberFollow
            .findMany({
              where: { accountId: session.accountId, isFollowing: true },
              include: { directoryProfile: true },
            })
            .catch(() => [])
        : [];
    const followedHandles = new Set<string>();
    for (const f of follows as Array<Record<string, any>>) {
      const h = this.normalizeModerationHandle(f?.directoryProfile?.username);
      if (h) followedHandles.add(h);
    }

    const groupedByPeer = new Map<
      string,
      {
        peerAccountId: string;
        peerDirectoryId: string | null;
        peerName: string;
        peerUsername: string;
        peerAvatar: string;
        messages: Array<Record<string, any>>;
      }
    >();

    for (const msg of items) {
      const isOwn = Boolean(msg.isOwnMessage);
      const peerAccountId = isOwn
        ? String(msg.recipientAccountId)
        : String(msg.senderAccountId);
      const peerDirectoryId = isOwn
        ? (msg.recipientDirectoryProfileId ?? null)
        : (msg.senderDirectoryProfileId ?? null);
      const peerName = isOwn
        ? String(msg.recipientName || "Sakhi Member")
        : String(msg.senderName || "Sakhi Member");
      const peerUsername = isOwn
        ? String(msg.recipientHandle || "@member")
        : String(msg.senderUsername || "@member");
      const peerAvatar = isOwn ? "" : String(msg.senderAvatar || "");
      const normPeerHandle = this.normalizeModerationHandle(peerUsername);
      if (
        modCtx.blockedHandles.has(normPeerHandle) ||
        modCtx.accountsWhoBlockedViewer.has(peerAccountId)
      ) {
        continue;
      }

      const existing = groupedByPeer.get(peerAccountId) ?? {
        peerAccountId,
        peerDirectoryId,
        peerName,
        peerUsername: peerUsername.startsWith("@")
          ? peerUsername
          : `@${peerUsername}`,
        peerAvatar,
        messages: [],
      };
      if (!existing.peerAvatar && peerAvatar) existing.peerAvatar = peerAvatar;
      if (!existing.peerDirectoryId && peerDirectoryId) {
        existing.peerDirectoryId = peerDirectoryId;
      }
      existing.messages.push(msg);
      groupedByPeer.set(peerAccountId, existing);
    }

    const conversations: Array<Record<string, any>> = [];
    const requests: Array<Record<string, any>> = [];
    let totalUnreadCount = 0;

    for (const group of groupedByPeer.values()) {
      const lastMsg = group.messages[group.messages.length - 1];
      if (!lastMsg) continue;
      const normHandle = this.normalizeModerationHandle(group.peerUsername);
      const viewerHasSentMessage = group.messages.some((m) => m.isOwnMessage);
      const isFollowingPeer = followedHandles.has(normHandle);

      const incomingMessages = group.messages.filter((m) => !m.isOwnMessage);
      const allIncomingDeclined =
        incomingMessages.length > 0 &&
        incomingMessages.every((m) => m.requestStatus === "DECLINED") &&
        !viewerHasSentMessage;
      if (allIncomingDeclined) {
        continue;
      }

      const hasExplicitAccepted = incomingMessages.some(
        (m) => m.requestStatus === "ACCEPTED",
      );
      const hasPendingRequestRow = incomingMessages.some(
        (m) => m.requestStatus === "PENDING_REQUEST",
      );

      const isRequest =
        hasPendingRequestRow ||
        (!hasExplicitAccepted &&
          !viewerHasSentMessage &&
          !isFollowingPeer &&
          modCtx.restrictedHandles.has(normHandle));

      const unreadCount = group.messages.filter(
        (m) => !m.isOwnMessage && !m.isRead && m.requestStatus !== "DECLINED",
      ).length;
      if (!isRequest) {
        totalUnreadCount += unreadCount;
      }

      const previewBody =
        lastMsg.attachmentUrl && (!lastMsg.body || lastMsg.body === "📷 Photo")
          ? "📷 Sent a photo"
          : String(lastMsg.body || "");

      const summary = {
        conversationId: `conv_${group.peerAccountId}`,
        peerId: group.peerDirectoryId ?? group.peerAccountId,
        peerAccountId: group.peerAccountId,
        peerDirectoryProfileId: group.peerDirectoryId,
        peerName: group.peerName,
        peerUsername: group.peerUsername,
        peerAvatar: group.peerAvatar,
        isVerified: true,
        isFollowing: isFollowingPeer,
        isMuted: modCtx.mutedHandles.has(normHandle),
        isRestricted: modCtx.restrictedHandles.has(normHandle),
        requestStatus: isRequest ? "PENDING_REQUEST" : "ACCEPTED",
        unreadCount,
        messagesCount: group.messages.length,
        lastMessage: {
          id: lastMsg.id,
          body: previewBody,
          attachmentUrl: lastMsg.attachmentUrl ?? null,
          createdAt: lastMsg.createdAt,
          timestamp: lastMsg.timestamp,
          isOwnMessage: lastMsg.isOwnMessage,
        },
        updatedAt: lastMsg.createdAt,
      };

      if (isRequest) {
        requests.push(summary);
      } else {
        conversations.push(summary);
      }
    }

    conversations.sort((a, b) =>
      String(b.updatedAt).localeCompare(String(a.updatedAt)),
    );
    requests.sort((a, b) =>
      String(b.updatedAt).localeCompare(String(a.updatedAt)),
    );

    return {
      source: "postgresql_live" as const,
      conversations,
      requests,
      totalUnreadCount,
      totalRequestsCount: requests.length,
    };
  }

  async respondToMessageRequest(
    authorization: string | undefined,
    peerId: string,
    action: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const normalizedAction = (action ?? "ACCEPT").trim().toUpperCase();
    const cleanedPeerId = (peerId ?? "").trim();
    if (!cleanedPeerId) {
      throw new BadRequestException("Provide a peer identifier.");
    }
    if (!["ACCEPT", "DECLINE", "BLOCK"].includes(normalizedAction)) {
      throw new BadRequestException("Action must be ACCEPT, DECLINE, or BLOCK.");
    }

    const resolvedPeer = await this.resolvePeerAccountIdForMessaging(cleanedPeerId);
    const anyPrisma = this.prisma as Record<string, any>;

    if (normalizedAction === "BLOCK") {
      const targetUsername =
        resolvedPeer.username ??
        (cleanedPeerId.startsWith("@") ? cleanedPeerId : `@${cleanedPeerId}`);
      const blocked = await this.ensureBlockedUser(authorization, {
        blockedUsername: targetUsername,
        blockedDisplayName:
          resolvedPeer.displayName ?? targetUsername.replace(/^@+/, ""),
      });
      if (
        resolvedPeer.accountId &&
        typeof anyPrisma.directMessage?.updateMany === "function"
      ) {
        await anyPrisma.directMessage
          .updateMany({
            where: {
              senderAccountId: resolvedPeer.accountId,
              recipientAccountId: session.accountId,
            },
            data: { requestStatus: "DECLINED" },
          })
          .catch(() => undefined);
      }
      return {
        peerId: cleanedPeerId,
        peerAccountId: resolvedPeer.accountId,
        action: "BLOCK",
        requestStatus: "BLOCKED",
        blocked,
      };
    }

    const status: "ACCEPTED" | "DECLINED" =
      normalizedAction === "DECLINE" ? "DECLINED" : "ACCEPTED";

    let updatedCount = 0;
    if (
      resolvedPeer.accountId &&
      typeof anyPrisma.directMessage?.updateMany === "function"
    ) {
      const updateRes = await anyPrisma.directMessage.updateMany({
        where: {
          senderAccountId: resolvedPeer.accountId,
          recipientAccountId: session.accountId,
        },
        data: {
          requestStatus: status,
          ...(status === "ACCEPTED" ? { readAt: new Date() } : {}),
        },
      });
      updatedCount = Number(updateRes?.count ?? 0);
    }

    return {
      peerId: cleanedPeerId,
      peerAccountId: resolvedPeer.accountId,
      action: normalizedAction,
      requestStatus: status,
      updatedMessagesCount: updatedCount,
    };
  }

  async markDirectMessagesRead(
    authorization: string | undefined,
    peerId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleanedPeerId = (peerId ?? "").trim();
    if (!cleanedPeerId) {
      throw new BadRequestException("Provide a peer identifier.");
    }
    const resolvedPeer = await this.resolvePeerAccountIdForMessaging(cleanedPeerId);
    const now = new Date();
    let updatedCount = 0;
    const anyPrisma = this.prisma as Record<string, any>;
    if (
      resolvedPeer.accountId &&
      typeof anyPrisma.directMessage?.updateMany === "function"
    ) {
      const res = await anyPrisma.directMessage.updateMany({
        where: {
          senderAccountId: resolvedPeer.accountId,
          recipientAccountId: session.accountId,
          readAt: null,
        },
        data: { readAt: now },
      });
      updatedCount = Number(res?.count ?? 0);
    }
    return {
      markedRead: true,
      peerId: cleanedPeerId,
      peerAccountId: resolvedPeer.accountId,
      updatedCount,
      readAt: now.toISOString(),
    };
  }

  async listNotificationsInbox(
    authorization: string | undefined,
    query: {
      category?: string;
      unreadOnly?: boolean;
      page?: number;
      limit?: number;
    } = {},
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.memberNotification?.findMany !== "function") {
      throw new ServiceUnavailableException(
        "Notification inbox database table is not initialized. Run the Module 8 migration.",
      );
    }

    const safePage = Math.max(Number(query.page) || 1, 1);
    const safeLimit = Math.min(Math.max(Number(query.limit) || 25, 1), 100);

    const [profile, notifPref, cyclePref, recentDms, enquiries] =
      await Promise.all([
        typeof anyPrisma.memberProfile?.findUnique === "function"
          ? anyPrisma.memberProfile
              .findUnique({ where: { accountId: session.accountId } })
              .catch(() => null)
          : Promise.resolve(null),
        typeof anyPrisma.memberNotificationPreference?.findUnique === "function"
          ? anyPrisma.memberNotificationPreference
              .findUnique({ where: { accountId: session.accountId } })
              .catch(() => null)
          : Promise.resolve(null),
        typeof anyPrisma.menstrualTrackerPreference?.findUnique === "function"
          ? anyPrisma.menstrualTrackerPreference
              .findUnique({ where: { accountId: session.accountId } })
              .catch(() => null)
          : Promise.resolve(null),
        typeof anyPrisma.directMessage?.findMany === "function"
          ? anyPrisma.directMessage
              .findMany({
                where: { recipientAccountId: session.accountId },
                orderBy: { createdAt: "desc" },
                take: 15,
              })
              .catch(() => [])
          : Promise.resolve([]),
        typeof anyPrisma.businessEnquiry?.findMany === "function"
          ? anyPrisma.businessEnquiry
              .findMany({
                where: {
                  OR: [
                    { ownerAccountId: session.accountId },
                    { senderAccountId: session.accountId },
                  ],
                },
                orderBy: { updatedAt: "desc" },
                take: 10,
              })
              .catch(() => [])
          : Promise.resolve([]),
      ]);

    const modCtx = await this.resolveViewerModerationContext(
      session.accountId,
      profile?.username ?? null,
    );
    const discreetWellness = cyclePref?.discreetNotifications ?? true;

    // Ensure durable notification records exist for account-scoped system & activity events
    if (session.account.verificationStatus === "VERIFIED") {
      await this.createPersistentNotification(session.accountId, {
        idempotencyKey: `verif:${session.accountId}:VERIFIED`,
        category: "VERIFICATION_RESULT",
        title: "Sakhi Identity Verification Approved",
        body: "Your verified women-only membership badge is active across Community, Business Pages, and Safety Circles.",
        discreetTitle: "Account Status Update",
        discreetBody: "Your Sakhi membership verification status has been updated.",
        deepLink: "/profile",
        actorName: "Sakhi Trust & Safety",
        actorHandle: "@sakhi_official",
      }).catch(() => null);
    }

    if (notifPref?.messages ?? true) {
      for (const dm of recentDms as Array<Record<string, any>>) {
        const senderNorm = this.normalizeModerationHandle(dm.senderUsername);
        if (
          modCtx.blockedHandles.has(senderNorm) ||
          modCtx.accountsWhoBlockedViewer.has(String(dm.senderAccountId)) ||
          dm.requestStatus === "DECLINED"
        ) {
          continue;
        }
        await this.createPersistentNotification(session.accountId, {
          idempotencyKey: `dm:${dm.id}`,
          category: "DIRECT_MESSAGE",
          title: `Message from ${dm.senderName}`,
          body: String(dm.body ?? "Sent you a message").slice(0, 140),
          discreetTitle: "New Sakhi Message",
          discreetBody: "You have a new private message waiting in Sakhi.",
          deepLink: `/messages?peerId=${encodeURIComponent(dm.senderUsername)}`,
          actorName: dm.senderName,
          actorHandle: dm.senderUsername,
          actorAvatar: dm.senderAvatar ?? null,
          createdAt: dm.createdAt,
        }).catch(() => null);
      }
    }

    if (notifPref?.businessEnquiries ?? true) {
      for (const eq of enquiries as Array<Record<string, any>>) {
        const isOwner = String(eq.ownerAccountId ?? "") === session.accountId;
        await this.createPersistentNotification(session.accountId, {
          idempotencyKey: `biz:${eq.id}:${eq.status}`,
          category: "BUSINESS_ENQUIRY",
          title: isOwner
            ? `Business enquiry for ${eq.businessName}`
            : `Update on your enquiry to ${eq.businessName}`,
          body: `${eq.subjectOrProduct ?? "Business Enquiry"} • Status: ${eq.status ?? "OPEN"}`,
          deepLink: "/explore",
          actorName: isOwner ? eq.senderDisplayName : eq.businessName,
          actorHandle: eq.senderUsername ?? "@business",
          createdAt: eq.updatedAt,
        }).catch(() => null);
      }
    }

    if (notifPref?.wellnessReminders ?? true) {
      try {
        const tracker = await this.getMenstrualCycleTracker(authorization);
        const rem = tracker.predictionSummary?.reminderPreview;
        if (rem && tracker.predictionSummary?.nextPeriodStart) {
          await this.createPersistentNotification(session.accountId, {
            idempotencyKey: `cycle:${session.accountId}:${tracker.predictionSummary.nextPeriodStart}`,
            category: "PERIOD_REMINDER",
            title: discreetWellness
              ? "Wellness Check-In"
              : (rem.title ?? "Upcoming Period Reminder"),
            body: discreetWellness
              ? "You have a personal calendar update waiting in your wellness tracker."
              : (rem.body ?? "Open your Menstrual Cycle Tracker to review your upcoming cycle estimate."),
            discreetTitle: "Wellness Check-In",
            discreetBody:
              "You have a personal calendar update waiting in your wellness tracker.",
            deepLink: "/menstrual-cycle-tracker",
            actorName: "Sakhi Wellness",
            actorHandle: "@sakhi_wellness",
          }).catch(() => null);
        }
      } catch {
        // Ignore if cycle tracker has not been configured yet
      }
    }

    const categoryFilter = (query.category ?? "").trim().toUpperCase();
    const whereClause: Record<string, any> = {
      accountId: session.accountId,
      ...(query.unreadOnly ? { isRead: false } : {}),
      ...(categoryFilter && categoryFilter !== "ALL"
        ? { category: categoryFilter }
        : {}),
    };

    const [rows, totalCount, unreadCount] = await Promise.all([
      anyPrisma.memberNotification.findMany({
        where: whereClause,
        orderBy: { createdAt: "desc" },
        skip: (safePage - 1) * safeLimit,
        take: safeLimit,
      }),
      typeof anyPrisma.memberNotification?.count === "function"
        ? anyPrisma.memberNotification.count({ where: whereClause })
        : Promise.resolve(0),
      typeof anyPrisma.memberNotification?.count === "function"
        ? anyPrisma.memberNotification.count({
            where: { accountId: session.accountId, isRead: false },
          })
        : Promise.resolve(0),
    ]);

    const filtered = (rows as Array<Record<string, any>>)
      .filter((n) => {
        const actorNorm = this.normalizeModerationHandle(n.actorHandle);
        return !actorNorm || !modCtx.blockedHandles.has(actorNorm);
      })
      .map((n) => {
        const createdDate =
          n.createdAt instanceof Date
            ? n.createdAt
            : new Date(String(n.createdAt ?? Date.now()));
        const useDiscreet =
          discreetWellness &&
          (n.category === "PERIOD_REMINDER" || n.category === "COMPLAINT_STATUS");
        return {
          id: String(n.id),
          accountId: String(n.accountId),
          category: String(n.category ?? "COMMUNITY_ANNOUNCEMENT"),
          title: useDiscreet
            ? String(n.discreetTitle || "Wellness Check-In")
            : String(n.title),
          body: useDiscreet
            ? String(
                n.discreetBody ||
                  "You have a personal update waiting in your Sakhi app.",
              )
            : String(n.body),
          discreetTitle: n.discreetTitle ?? "Wellness Check-In",
          discreetBody:
            n.discreetBody ??
            "You have a personal update waiting in your Sakhi app.",
          isDiscreetRendered: useDiscreet,
          deepLink: String(n.deepLink ?? "/notifications-inbox"),
          actorName: n.actorName ?? "Sakhi",
          actorHandle: n.actorHandle ?? "@sakhi",
          actorAvatar: n.actorAvatar ?? "",
          metadata: n.metadata ?? {},
          isRead: Boolean(n.isRead),
          readAt:
            n.readAt instanceof Date
              ? n.readAt.toISOString()
              : (n.readAt ?? null),
          idempotencyKey: n.idempotencyKey ?? null,
          deliveryStatus: n.deliveryStatus ?? "DELIVERED",
          createdAt: createdDate.toISOString(),
          timestamp: this.formatRelativeTime(createdDate),
        };
      });

    const resolvedTotal = Number(totalCount || filtered.length);
    return {
      source: "postgresql_live" as const,
      items: filtered,
      notifications: filtered,
      unreadCount: Number(unreadCount ?? 0),
      totalCount: resolvedTotal,
      page: safePage,
      limit: safeLimit,
      hasMore: safePage * safeLimit < resolvedTotal,
      discreetModeEnabled: discreetWellness,
    };
  }

  async markNotificationRead(
    authorization: string | undefined,
    notificationId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleanId = (notificationId ?? "").trim();
    if (!cleanId) {
      throw new BadRequestException("Provide a notification ID.");
    }
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.memberNotification?.findFirst !== "function") {
      throw new ServiceUnavailableException(
        "Notification storage is not initialized.",
      );
    }

    const existing = await anyPrisma.memberNotification.findFirst({
      where: {
        accountId: session.accountId,
        OR: [{ id: cleanId }, { idempotencyKey: cleanId }],
      },
    });
    if (!existing) {
      throw new NotFoundException("Notification was not found in your account.");
    }

    const now = new Date();
    const updated = await anyPrisma.memberNotification.update({
      where: { id: existing.id },
      data: {
        isRead: true,
        readAt: existing.readAt ?? now,
      },
    });
    return {
      notificationId: updated.id,
      isRead: Boolean(updated.isRead),
      readAt:
        updated.readAt instanceof Date
          ? updated.readAt.toISOString()
          : now.toISOString(),
    };
  }

  async markAllNotificationsRead(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.memberNotification?.updateMany !== "function") {
      throw new ServiceUnavailableException(
        "Notification storage is not initialized.",
      );
    }
    const now = new Date();
    const res = await anyPrisma.memberNotification.updateMany({
      where: {
        accountId: session.accountId,
        isRead: false,
      },
      data: {
        isRead: true,
        readAt: now,
      },
    });
    return {
      markedAllRead: true,
      updatedCount: Number(res?.count ?? 0),
      unreadCount: 0,
      readAt: now.toISOString(),
    };
  }

  async deleteNotification(
    authorization: string | undefined,
    notificationId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleanId = (notificationId ?? "").trim();
    if (!cleanId) {
      throw new BadRequestException("Provide a notification ID.");
    }
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.memberNotification?.findFirst !== "function") {
      throw new ServiceUnavailableException(
        "Notification storage is not initialized.",
      );
    }
    const existing = await anyPrisma.memberNotification.findFirst({
      where: {
        accountId: session.accountId,
        OR: [{ id: cleanId }, { idempotencyKey: cleanId }],
      },
    });
    if (!existing) {
      throw new NotFoundException("Notification was not found in your account.");
    }
    await anyPrisma.memberNotification.delete({
      where: { id: existing.id },
    });
    return {
      deleted: true,
      notificationId: existing.id,
    };
  }

  async unifiedSearch(
    authorization: string | undefined,
    query: {
      q?: string;
      category?: string;
      city?: string;
      lat?: number;
      lng?: number;
      radiusKm?: number;
      page?: number;
      limit?: number;
    } = {},
  ) {
    await this.auth.authenticateAuthorization(authorization);
    const rawQ = (query.q ?? "").trim();
    const qLower = rawQ.toLowerCase().replace(/^#/, "");
    const rawCategory = (query.category ?? "all").trim().toLowerCase();
    const categoryAliases: Record<string, string> = {
      all: "all",
      member: "members",
      members: "members",
      people: "members",
      business: "businesses",
      businesses: "businesses",
      product: "products",
      products: "products",
      service: "products",
      services: "products",
      post: "posts",
      posts: "posts",
      topic: "topics",
      topics: "topics",
      circle: "topics",
      circles: "topics",
      wellness: "wellness",
      health: "wellness",
      safety: "nearby_safety",
      nearby_safety: "nearby_safety",
      police: "nearby_safety",
      nearbypolicestations: "nearby_safety",
    };
    const requestedCategory = categoryAliases[rawCategory] ?? "all";

    const parsedLimit = Number(query.limit ?? 25);
    const parsedPage = Number(query.page ?? 1);
    if (
      (query.limit !== undefined && (!Number.isFinite(parsedLimit) || parsedLimit < 1)) ||
      (query.page !== undefined && (!Number.isFinite(parsedPage) || parsedPage < 1))
    ) {
      throw new BadRequestException("Provide valid positive page and limit parameters.");
    }
    const safeLimit = Math.min(Math.max(Math.round(parsedLimit), 1), 100);
    const safePage = Math.max(Math.round(parsedPage), 1);
    const offset = (safePage - 1) * safeLimit;
    const paginateSlice = <T>(items: T[]): T[] =>
      items.slice(offset, offset + safeLimit);

    const shouldLoad = (bucket: string) =>
      requestedCategory === "all" || requestedCategory === bucket;

    const [
      membersResult,
      businessesResult,
      postsResult,
      nearbyCirclesResult,
      policeStationsResult,
    ] = await Promise.all([
      shouldLoad("members")
        ? rawQ
          ? this.searchMembers(authorization, rawQ).catch(() => ({ members: [] }))
          : this.listFollowers(authorization, "following")
              .then((r) => ({ members: r.items }))
              .catch(() => ({ members: [] }))
        : Promise.resolve({ members: [] }),
      shouldLoad("businesses") || shouldLoad("products")
        ? this.listMemberBusinesses(authorization, {
            search: shouldLoad("businesses") ? rawQ || undefined : undefined,
            city: query.city,
            lat: query.lat,
            lng: query.lng,
            radiusKm: query.radiusKm,
          }).catch(() => ({ businesses: [] }))
        : Promise.resolve({ businesses: [] }),
      shouldLoad("posts")
        ? this.listPosts(authorization, {
            search: rawQ || undefined,
            limit: safeLimit,
            page: safePage,
          }).catch(() => ({ posts: [] }))
        : Promise.resolve({ posts: [] }),
      shouldLoad("topics")
        ? this.listNearbyCircles(
            authorization,
            query.lat,
            query.lng,
            query.radiusKm ?? 20,
            query.city,
          ).catch(() => ({ activeCircles: [], nearbyMembers: [] }))
        : Promise.resolve({ activeCircles: [], nearbyMembers: [] }),
      shouldLoad("nearby_safety")
        ? this.listNearbyPoliceStations(
            query.lat,
            query.lng,
            (query.radiusKm ?? 15) * 1000,
          ).catch(() => ({ stations: [] }))
        : Promise.resolve({ stations: [] }),
    ]);

    const allMembers = shouldLoad("members") ? (membersResult.members ?? []) : [];
    const allBusinessesRaw = businessesResult.businesses ?? [];
    const allBusinesses = shouldLoad("businesses")
      ? allBusinessesRaw.filter((biz: Record<string, any>) => {
          if (!qLower) return true;
          return (
            String(biz.businessName ?? "").toLowerCase().includes(qLower) ||
            String(biz.category ?? "").toLowerCase().includes(qLower) ||
            String(biz.description ?? "").toLowerCase().includes(qLower) ||
            String(biz.city ?? "").toLowerCase().includes(qLower)
          );
        })
      : [];
    const posts = shouldLoad("posts") ? (postsResult.posts ?? []) : [];

    const allProducts: Array<Record<string, any>> = [];
    if (shouldLoad("products")) {
      for (const biz of allBusinessesRaw as Array<Record<string, any>>) {
        const prodList = Array.isArray(biz.productsServices)
          ? biz.productsServices
          : [];
        for (const prod of prodList as Array<Record<string, any>>) {
          const title = String(prod.title ?? prod.name ?? "").trim();
          const desc = String(prod.description ?? "").trim();
          const price = String(
            prod.price ?? prod.priceLabel ?? biz.priceRange ?? "",
          ).trim();
          if (!title) continue;
          if (
            !qLower ||
            title.toLowerCase().includes(qLower) ||
            desc.toLowerCase().includes(qLower) ||
            String(biz.businessName ?? "").toLowerCase().includes(qLower) ||
            String(biz.category ?? "").toLowerCase().includes(qLower)
          ) {
            allProducts.push({
              id: `${biz.id}_${title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`,
              title,
              description: desc || `Offered by ${biz.businessName}`,
              priceLabel: price || "Contact for price",
              businessId: biz.id,
              businessName: biz.businessName,
              businessCategory: biz.category,
              city: biz.city,
              isVerifiedWomanOwned: Boolean(biz.isVerifiedWomanOwned),
            });
          }
        }
      }
    }

    const defaultHashtagTopics = [
      {
        id: "topic-women-in-tech",
        name: "#WomenInTech",
        category: "Career & Mentorship",
        description: "Career growth, coding circles, and leadership discussions.",
        membersCount: 420,
      },
      {
        id: "topic-safe-commute",
        name: "#SafeCommute",
        category: "Safety Awareness",
        description: "Verified metro, cab, and late-evening travel safety updates.",
        membersCount: 615,
      },
      {
        id: "topic-mental-wellness",
        name: "#MentalWellness",
        category: "Wellness & Mindfulness",
        description: "4-7-8 breathing, guided meditation, and emotional balance.",
        membersCount: 530,
      },
      {
        id: "topic-period-care",
        name: "#PeriodPainHelp",
        category: "Reproductive Health",
        description: "Menstrual cycle comfort, cramp care, and gynecologist visit guides.",
        membersCount: 490,
      },
      {
        id: "topic-women-founders",
        name: "#WomenFounders",
        category: "Entrepreneurship",
        description: "Showcases and peer advice from verified women-owned businesses.",
        membersCount: 380,
      },
    ];
    const allCircles = shouldLoad("topics")
      ? [...(nearbyCirclesResult.activeCircles ?? []), ...defaultHashtagTopics]
      : [];
    const allTopics = allCircles.filter((t: Record<string, any>) => {
      if (!qLower) return true;
      return (
        String(t.name ?? "").toLowerCase().includes(qLower) ||
        String(t.category ?? "").toLowerCase().includes(qLower) ||
        String(t.description ?? "").toLowerCase().includes(qLower)
      );
    });

    const wellnessCatalog = shouldLoad("wellness")
      ? [
          ...Module2Service.MENSTRUAL_HEALTH_ARTICLES.map((art) => ({
            id: art.id,
            type: "HEALTH_ARTICLE",
            category: art.category,
            title: art.title,
            subtitle: art.summary,
            readTime: art.readTime,
            highlights: art.highlights,
            deepLink: "/menstrual-cycle-tracker",
          })),
          {
            id: "wellness-breathing-478",
            type: "BREATHING_EXERCISE",
            category: "Mental Wellness Studio",
            title: "4-7-8 Calm Breathing & Box Breathing Studio",
            subtitle:
                "Interactive guided breathing with natural voice cues and synthesized harmonic ambient drones.",
            readTime: "4–10 min session",
            highlights: [
              "4-7-8 Calm Breath for relaxation and evening wind-down",
              "Box Breathing (4-4-4-4) for grounded focus",
            ],
            deepLink: "/wellness",
          },
          {
            id: "wellness-guided-meditation",
            type: "GUIDED_MEDITATION",
            category: "Mental Wellness Studio",
            title: "Miracle of Mind — Guided Meditation & Harmonic Drones",
            subtitle:
                "Spoken step-by-step mindfulness meditation with 5 synthesized polyphonic harmonic pads.",
            readTime: "7–21 min session",
            highlights: [
              "Full spoken meditation guidance with independent voice & ambient volume",
              "5 synthesized harmonic ambient drones generated on-device",
            ],
            deepLink: "/wellness",
          },
        ]
      : [];
    const allWellness = wellnessCatalog.filter((w) => {
      if (!qLower) return true;
      return (
        w.title.toLowerCase().includes(qLower) ||
        w.subtitle.toLowerCase().includes(qLower) ||
        w.category.toLowerCase().includes(qLower) ||
        w.highlights.some((h) => h.toLowerCase().includes(qLower))
      );
    });

    const allPoliceStations = shouldLoad("nearby_safety")
      ? (policeStationsResult.stations ?? []).filter(
          (s: Record<string, any>) => {
            if (!qLower) return true;
            return (
              String(s.name ?? "").toLowerCase().includes(qLower) ||
              String(s.address ?? "").toLowerCase().includes(qLower) ||
              String(s.city ?? "").toLowerCase().includes(qLower)
            );
          },
        )
      : [];

    const members = paginateSlice(allMembers);
    const businesses = paginateSlice(allBusinesses);
    const products = paginateSlice(allProducts);
    const topics = paginateSlice(allTopics);
    const wellness = paginateSlice(allWellness);
    const nearbyPoliceStations = paginateSlice(allPoliceStations);

    return {
      source: "postgresql_live" as const,
      query: rawQ,
      category: requestedCategory,
      page: safePage,
      limit: safeLimit,
      totalCounts: {
        members: allMembers.length,
        businesses: allBusinesses.length,
        products: allProducts.length,
        posts: posts.length,
        topics: allTopics.length,
        wellness: allWellness.length,
        nearbyPoliceStations: allPoliceStations.length,
      },
      counts: {
        members: members.length,
        businesses: businesses.length,
        products: products.length,
        posts: posts.length,
        topics: topics.length,
        wellness: wellness.length,
        nearbyPoliceStations: nearbyPoliceStations.length,
      },
      members,
      businesses,
      products,
      posts,
      topics,
      wellness,
      nearbyPoliceStations,
    };
  }

  async sendDirectMessage(
    authorization: string | undefined,
    dto: {
      recipientId?: string;
      recipientHandle?: string;
      recipientName?: string;
      message?: string;
      attachmentUrl?: string;
      attachmentType?: string;
      mediaUploadId?: string;
      clientMessageId?: string;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;

    const clientMessageId = dto.clientMessageId?.trim()
      ? dto.clientMessageId.trim().slice(0, 80)
      : null;
    if (clientMessageId && typeof anyPrisma.directMessage?.findFirst === "function") {
      const existingByClientMsgId = await anyPrisma.directMessage
        .findFirst({
          where: {
            senderAccountId: session.accountId,
            clientMessageId,
          },
        })
        .catch(() => null);
      if (existingByClientMsgId) {
        return {
          sent: true,
          deduplicated: true,
          message: this.mapDirectMessageRow(existingByClientMsgId, session.accountId),
        };
      }
    }

    const allowedAttachmentMimeTypes = new Set([
      "image/jpeg",
      "image/png",
      "image/webp",
    ]);
    let validatedMediaUploadId: string | null = dto.mediaUploadId?.trim() || null;
    let resolvedAttachmentUrl: string | null = null;
    let resolvedAttachmentType: string | null = null;

    const rawAttachmentUrl = dto.attachmentUrl?.trim() || null;
    if (rawAttachmentUrl && !validatedMediaUploadId) {
      const matchInternal = /^\/api\/v1\/module2\/media\/object\/([0-9a-fA-F-]{36})$/.exec(
        rawAttachmentUrl,
      );
      if (!matchInternal) {
        throw new BadRequestException(
          "Direct message attachments must reference a verified Sakhi media upload.",
        );
      }
      validatedMediaUploadId = matchInternal[1]!;
    }

    if (validatedMediaUploadId) {
      const [mediaAsset, uploadEvent] = await Promise.all([
        typeof anyPrisma.mediaAsset?.findUnique === "function"
          ? anyPrisma.mediaAsset
              .findUnique({ where: { id: validatedMediaUploadId } })
              .catch(() => null)
          : Promise.resolve(null),
        typeof anyPrisma.auditEvent?.findFirst === "function"
          ? anyPrisma.auditEvent
              .findFirst({
                where: {
                  targetId: validatedMediaUploadId,
                  action: "module2.media.uploaded",
                },
                orderBy: { createdAt: "desc" },
              })
              .catch(() => null)
          : Promise.resolve(null),
      ]);

      if (!mediaAsset || !uploadEvent) {
        throw new NotFoundException(
          "The referenced attachment upload was not found.",
        );
      }
      if (String(mediaAsset.ownerAccountId) !== session.accountId) {
        throw new ForbiddenException(
          "You can only attach media files uploaded by your own account.",
        );
      }
      if (
        mediaAsset.purpose !== "DIRECT_MESSAGE_IMAGE" ||
        mediaAsset.postId != null ||
        mediaAsset.status !== "UPLOADED" ||
        mediaAsset.visibility !== "PRIVATE_SELF"
      ) {
        throw new BadRequestException(
          "Only a new private direct-message upload can be attached to a conversation.",
        );
      }
      const byteSize = Number(mediaAsset.byteSize ?? 0);
      if (!Number.isFinite(byteSize) || byteSize < 1 || byteSize > 15 * 1024 * 1024) {
        throw new BadRequestException(
          "Direct message attachments must be between 1 byte and 15 MB.",
        );
      }
      const candidateType = String(mediaAsset.contentType ?? "").trim().toLowerCase();
      if (
        !allowedAttachmentMimeTypes.has(candidateType) ||
        (dto.attachmentType?.trim() &&
          dto.attachmentType.trim().toLowerCase() !== candidateType)
      ) {
        throw new BadRequestException(
          "Attachment media type does not match the verified upload. Allowed: JPEG, PNG, WEBP, or MP4.",
        );
      }
      if (typeof anyPrisma.directMessage?.findFirst === "function") {
        const priorAttachment = await anyPrisma.directMessage.findFirst({
          where: { mediaUploadId: validatedMediaUploadId },
          select: { id: true },
        });
        if (priorAttachment) {
          throw new BadRequestException(
            "This upload has already been attached to a message. Upload the photo again before sharing it with someone else.",
          );
        }
      }
      resolvedAttachmentType = candidateType;
      resolvedAttachmentUrl = `/api/v1/module2/media/object/${validatedMediaUploadId}`;
    }

    const rawBody = dto.message?.trim() ?? "";
    const body = rawBody || (resolvedAttachmentUrl ? "📷 Photo" : "");
    if (!body) throw new BadRequestException("Enter a message before sending.");

    if (
      session.account.status !== "ACTIVE" ||
      session.account.verificationStatus !== "VERIFIED"
    ) {
      throw new ForbiddenException(
        "Only active, verified members can send direct messages.",
      );
    }

    const requestedRecipientId = dto.recipientId?.trim() ?? "";
    const requestedRecipientHandle = dto.recipientHandle?.trim() ?? "";
    if (!requestedRecipientId && !requestedRecipientHandle) {
      throw new BadRequestException("Choose a valid member to message.");
    }

    const isUuid = (value: string) =>
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
        value,
      );
    const normalizeHandle = (value: unknown) =>
      typeof value === "string"
        ? value.trim().replace(/^@+/, "").toLowerCase()
        : "";
    const handleVariants = (value: string) => {
      const raw = value.trim();
      const clean = raw.replace(/^@+/, "");
      return [
        ...new Set(
          [
            raw,
            clean,
            `@${clean}`,
            raw.toLowerCase(),
            clean.toLowerCase(),
            `@${clean.toLowerCase()}`,
          ].filter(Boolean),
        ),
      ];
    };

    const recipientInclude = {
      account: {
        select: {
          id: true,
          status: true,
          verificationStatus: true,
          privacyPreference: {
            select: {
              messageMe: true,
              restrictedHandles: true,
            },
          },
        },
      },
    };
    let recipientDirectoryProfile: {
      id: string;
      username: string;
    } | null = null;
    let recipientProfile: any = null;

    if (requestedRecipientId && isUuid(requestedRecipientId)) {
      recipientDirectoryProfile = await this.prisma.communityDirectoryProfile
        .findUnique({
          where: { id: requestedRecipientId },
          select: { id: true, username: true },
        })
        .catch(() => null);

      if (recipientDirectoryProfile) {
        recipientProfile = await this.prisma.memberProfile
          .findFirst({
            where: {
              username: {
                equals: recipientDirectoryProfile.username,
                mode: "insensitive",
              },
            },
            include: recipientInclude,
          })
          .catch(() => null);
      } else {
        recipientProfile = await this.prisma.memberProfile
          .findUnique({
            where: { accountId: requestedRecipientId },
            include: recipientInclude,
          })
          .catch(() => null);
      }
    } else {
      const lookupHandle = requestedRecipientHandle || requestedRecipientId;
      const cleanHandle = lookupHandle.replace(/^@+/, "");
      if (
        requestedRecipientHandle &&
        requestedRecipientId &&
        normalizeHandle(requestedRecipientId) !==
          normalizeHandle(requestedRecipientHandle)
      ) {
        throw new BadRequestException(
          "The recipient ID and username do not identify the same member.",
        );
      }
      recipientProfile = await this.prisma.memberProfile
        .findFirst({
          where: {
            OR: [
              {
                username: {
                  equals: lookupHandle,
                  mode: "insensitive",
                },
              },
              {
                username: {
                  equals: `@${cleanHandle}`,
                  mode: "insensitive",
                },
              },
            ],
          },
          include: recipientInclude,
        })
        .catch(() => null);
    }

    if (!recipientProfile?.account) {
      throw new NotFoundException(
        "This member is not available for direct messaging.",
      );
    }

    const recipientHandle =
      typeof recipientProfile.username === "string"
        ? recipientProfile.username.trim()
        : "";
    const senderProfile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
      select: {
        displayName: true,
        username: true,
        avatarAsset: true,
        avatarMediaAssetId: true,
      },
    });
    const senderHandle =
      typeof senderProfile?.username === "string"
        ? senderProfile.username.trim()
        : "";

    if (!recipientHandle || !senderHandle) {
      throw new ForbiddenException(
        "Both members must have a Sakhi username before messaging.",
      );
    }

    if (
      requestedRecipientHandle &&
      normalizeHandle(requestedRecipientHandle) !==
        normalizeHandle(recipientHandle)
    ) {
      throw new BadRequestException(
        "The recipient ID and username do not identify the same member.",
      );
    }
    if (recipientProfile.accountId === session.accountId) {
      throw new BadRequestException("You cannot message yourself.");
    }

    const recipientAccount = recipientProfile.account;
    if (
      recipientAccount.status !== "ACTIVE" ||
      recipientAccount.verificationStatus !== "VERIFIED"
    ) {
      throw new ForbiddenException(
        "This member is not eligible to receive direct messages.",
      );
    }

    const messagePreference = String(
      recipientAccount.privacyPreference?.messageMe ?? "Verified members only",
    )
      .trim()
      .toLowerCase();
    if (
      messagePreference === "no one" ||
      messagePreference === "none" ||
      messagePreference === "no"
    ) {
      throw new ForbiddenException(
        "This member is not accepting direct messages.",
      );
    }
    if (
      !messagePreference.includes("verified") &&
      !messagePreference.includes("follower")
    ) {
      throw new ForbiddenException(
        "This member's messaging preference does not allow this request.",
      );
    }

    if (!recipientDirectoryProfile) {
      recipientDirectoryProfile = await this.prisma.communityDirectoryProfile
        .findFirst({
          where: {
            username: { equals: recipientHandle, mode: "insensitive" },
          },
          select: { id: true, username: true },
        })
        .catch(() => null);
    }
    const senderDirectoryProfile = await this.prisma.communityDirectoryProfile
      .findFirst({
        where: {
          username: { equals: senderHandle, mode: "insensitive" },
        },
        select: { id: true, username: true },
      })
      .catch(() => null);

    if (messagePreference.includes("follower")) {
      if (!recipientDirectoryProfile) {
        throw new ForbiddenException(
          "You must follow this member before sending a message.",
        );
      }
      const follow = await this.prisma.memberFollow.findUnique({
        where: {
          accountId_directoryProfileId: {
            accountId: session.accountId,
            directoryProfileId: recipientDirectoryProfile.id,
          },
        },
        select: { isFollowing: true },
      });
      if (!follow?.isFollowing) {
        throw new ForbiddenException(
          "You must follow this member before sending a message.",
        );
      }
    }

    const recipientHandleVariants = handleVariants(recipientHandle);
    const senderHandleVariants = handleVariants(senderHandle);
    const [senderBlockedRecipient, recipientBlockedSender] = await Promise.all([
      this.prisma.memberModerationBlock.findFirst({
        where: {
          accountId: session.accountId,
          blockedUsername: { in: recipientHandleVariants },
        },
        select: { id: true },
      }),
      this.prisma.memberModerationBlock.findFirst({
        where: {
          accountId: recipientProfile.accountId,
          blockedUsername: { in: senderHandleVariants },
        },
        select: { id: true },
      }),
    ]);
    if (senderBlockedRecipient || recipientBlockedSender) {
      throw new ForbiddenException(
        "Direct messaging is unavailable between these members.",
      );
    }

    // Determine whether this message enters ACCEPTED or PENDING_REQUEST state in PostgreSQL
    const recipientRestrictedHandles = new Set<string>(
      this.parseStringArrayJson(
        recipientAccount.privacyPreference?.restrictedHandles,
      ).map((h) => this.normalizeModerationHandle(h)),
    );
    const normSenderHandle = this.normalizeModerationHandle(senderHandle);
    const recipientFollowsSender = senderDirectoryProfile
      ? await this.prisma.memberFollow.findUnique({
          where: {
            accountId_directoryProfileId: {
              accountId: recipientProfile.accountId,
              directoryProfileId: senderDirectoryProfile.id,
            },
          },
          select: { isFollowing: true },
        })
      : null;
    const previouslyAcceptedConversation =
      typeof anyPrisma.directMessage?.findFirst === "function"
        ? await anyPrisma.directMessage.findFirst({
            where: {
              OR: [
                {
                  senderAccountId: recipientProfile.accountId,
                  recipientAccountId: session.accountId,
                  requestStatus: "ACCEPTED",
                },
                {
                  senderAccountId: session.accountId,
                  recipientAccountId: recipientProfile.accountId,
                  requestStatus: "ACCEPTED",
                },
              ],
            },
            select: { id: true },
          })
        : null;
    const recipientKnowsSender =
      recipientFollowsSender?.isFollowing === true ||
      previouslyAcceptedConversation != null;
    const initialRequestStatus: "ACCEPTED" | "PENDING_REQUEST" =
      recipientRestrictedHandles.has(normSenderHandle) || !recipientKnowsSender
        ? "PENDING_REQUEST"
        : "ACCEPTED";

    const nowDate = new Date();
    const nowIso = nowDate.toISOString();
    const msgId = randomUUID();
    const derivedSenderUsername = this.deriveUsername(
      senderProfile?.displayName ?? "Sakhi Member",
      senderProfile?.username ?? null,
    );
    const derivedSenderAvatar = senderProfile
      ? this.resolveMemberAvatar(
          senderProfile.avatarAsset,
          senderProfile.avatarMediaAssetId,
        )
      : "";

    let createdDbRow: Record<string, any> | null = null;
    try {
      createdDbRow = await this.prisma.directMessage.create({
        data: {
          id: msgId,
          senderAccountId: session.accountId,
          recipientAccountId: recipientProfile.accountId,
          senderDirectoryProfileId: senderDirectoryProfile?.id ?? null,
          recipientDirectoryProfileId: recipientDirectoryProfile?.id ?? null,
          senderName: senderProfile?.displayName ?? "Sakhi Member",
          senderUsername: derivedSenderUsername,
          senderAvatar: derivedSenderAvatar || null,
          recipientName: recipientProfile.displayName,
          recipientHandle,
          body,
          ...(resolvedAttachmentUrl
            ? {
                attachmentUrl: resolvedAttachmentUrl,
                attachmentType: resolvedAttachmentType,
                mediaUploadId: validatedMediaUploadId,
              }
            : {}),
          ...(initialRequestStatus !== "ACCEPTED"
            ? { requestStatus: initialRequestStatus }
            : {}),
          ...(clientMessageId ? { clientMessageId } : {}),
          createdAt: nowDate,
        } as any,
      });
    } catch (err: any) {
      if (
        clientMessageId &&
        typeof anyPrisma.directMessage?.findFirst === "function"
      ) {
        const concurrentExisting = await anyPrisma.directMessage
          .findFirst({
            where: {
              senderAccountId: session.accountId,
              clientMessageId,
            },
          })
          .catch(() => null);
        if (concurrentExisting) {
          return {
            sent: true,
            deduplicated: true,
            message: this.mapDirectMessageRow(
              concurrentExisting,
              session.accountId,
            ),
          };
        }
      }
      throw new InternalServerErrorException(
        "Your message could not be saved. It has not been sent. Please try again.",
      );
    }

    try {
      await this.prisma.auditEvent.create({
        data: {
          actorType: "MEMBER",
          actorId: session.accountId,
          action: "module3.direct_message.persisted",
          targetType: "direct_message",
          targetId: msgId,
          outcome: "persisted",
          requestId: randomUUID(),
          redactedMetadata: {
            messageId: msgId,
            recipientAccountId: recipientProfile.accountId,
            hasAttachment: Boolean(resolvedAttachmentUrl),
            requestStatus: initialRequestStatus,
          },
        },
      });
    } catch {
      // Audit logging failure does not roll back the persisted message
    }

    await this.createPersistentNotification(recipientProfile.accountId, {
      category: "DIRECT_MESSAGE",
      title: `New message from ${senderProfile?.displayName ?? "Sakhi Member"}`,
      body:
        resolvedAttachmentUrl && rawBody === ""
          ? `${senderProfile?.displayName ?? "Sakhi Member"} sent you a photo.`
          : body.slice(0, 140),
      discreetTitle: "New Sakhi Message",
      discreetBody: "You have a new private message waiting in Sakhi.",
      deepLink: `/messages?peerId=${encodeURIComponent(derivedSenderUsername)}`,
      actorHandle: derivedSenderUsername,
      actorName: senderProfile?.displayName ?? "Sakhi Member",
      actorAvatar: derivedSenderAvatar,
      idempotencyKey: `dm:${msgId}`,
    }).catch(() => null);

    const mappedMsg = createdDbRow
      ? this.mapDirectMessageRow(createdDbRow, session.accountId)
      : {
          id: msgId,
          senderAccountId: session.accountId,
          senderDirectoryProfileId: senderDirectoryProfile?.id ?? null,
          senderName: senderProfile?.displayName ?? "Sakhi Member",
          senderUsername: derivedSenderUsername,
          senderAvatar: derivedSenderAvatar,
          recipientId: requestedRecipientId || recipientProfile.accountId,
          recipientAccountId: recipientProfile.accountId,
          recipientDirectoryProfileId: recipientDirectoryProfile?.id ?? null,
          recipientHandle,
          recipientName: recipientProfile.displayName,
          body,
          ...(resolvedAttachmentUrl
            ? {
                attachmentUrl: resolvedAttachmentUrl,
                attachmentType: resolvedAttachmentType,
                mediaUploadId: validatedMediaUploadId,
              }
            : {}),
          requestStatus: initialRequestStatus,
          isRead: true,
          createdAt: nowIso,
          timestamp: "Just now",
          isOwnMessage: true,
        };

    return {
      sent: true,
      message: {
        ...mappedMsg,
        recipientId: requestedRecipientId || recipientProfile.accountId,
        timestamp: "Just now",
      },
    };
  }

  async listSafetyEvidence(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const events = this.prisma.auditEvent?.findMany
      ? await this.prisma.auditEvent
          .findMany({
            where: {
              actorId: session.accountId,
              action: "module4.safety_evidence.recorded",
            },
            orderBy: { createdAt: "desc" },
            take: 50,
          })
          .catch(() => [])
      : [];
    const items = events
      .map((e) => e.redactedMetadata as Record<string, any> | null)
      .filter((x): x is Record<string, any> => Boolean(x));
    return { items };
  }

  async addSafetyEvidence(
    authorization: string | undefined,
    dto: {
      title: string;
      mediaType: string;
      mediaUrl?: string;
      durationLabel?: string;
      sizeLabel?: string;
      latitude?: number;
      longitude?: number;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const item = {
      id: `ev_${randomUUID().slice(0, 8)}`,
      accountId: session.accountId,
      title: dto.title.trim(),
      mediaType: dto.mediaType.trim(),
      mediaUrl: dto.mediaUrl?.trim() || null,
      durationLabel: dto.durationLabel?.trim() || "00:30",
      sizeLabel: dto.sizeLabel?.trim() || "1.4 MB",
      latitude: dto.latitude ?? null,
      longitude: dto.longitude ?? null,
      encryptedHash: `AES256-${randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`,
      createdAt: new Date().toISOString(),
    };
    if (this.prisma.auditEvent?.create) {
      await this.prisma.auditEvent
        .create({
          data: {
            actorType: "MEMBER",
            actorId: session.accountId,
            action: "module4.safety_evidence.recorded",
            targetType: "safety_evidence",
            targetId: item.id,
            outcome: "encrypted",
            requestId: randomUUID(),
            redactedMetadata: item,
          },
        })
        .catch(() => undefined);
    }
    return { saved: true, evidence: item };
  }

  async updateVolunteerOptIn(
    authorization: string | undefined,
    dto: {
      isOptedIn: boolean;
      availability?: string;
      radiusKm?: number;
      skills?: string[];
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const payload = {
      accountId: session.accountId,
      isOptedIn: Boolean(dto.isOptedIn),
      availability: dto.availability?.trim() || "Immediate Response",
      radiusKm: dto.radiusKm ?? 5,
      skills: Array.isArray(dto.skills) ? dto.skills : ["First Aid", "Safe Escort"],
      updatedAt: new Date().toISOString(),
    };
    if (this.prisma.auditEvent?.create) {
      await this.prisma.auditEvent
        .create({
          data: {
            actorType: "MEMBER",
            actorId: session.accountId,
            action: "module4.volunteer_opt_in.updated",
            targetType: "volunteer_profile",
            targetId: session.accountId,
            outcome: payload.isOptedIn ? "opted_in" : "opted_out",
            requestId: randomUUID(),
            redactedMetadata: payload,
          },
        })
        .catch(() => undefined);
    }
    return { updated: true, volunteerProfile: payload };
  }

  // Backward-compatible methods for test/module2.service.spec.ts & test/module2.account-deletion.spec.ts
  async getMemberProfile(
    authorization: string | undefined,
    targetAccountId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const account = await anyPrisma.memberAccount.findFirst({
      where: {
        id: targetAccountId,
        status: "ACTIVE",
        verificationStatus: "VERIFIED",
      },
      include: {
        profile: true,
        privacySettings: true,
      },
    });
    if (!account || !account.profile) {
      throw new NotFoundException("Member profile was not found.");
    }
    const showCity =
      account.id === session.accountId ||
      account.privacySettings?.locationSharing === "CITY_ONLY";
    return {
      accountId: account.id,
      profile: {
        ...account.profile,
        locationCity: showCity ? account.profile.locationCity : null,
      },
    };
  }

  async getDiscover(authorization: string | undefined, search?: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const where: Record<string, any> = {
      id: { not: session.accountId },
      status: "ACTIVE",
      verificationStatus: "VERIFIED",
      OR: [
        { privacySettings: { is: null } },
        {
          privacySettings: {
            is: {
              appearInSearch: true,
              profileVisibility: "VERIFIED_MEMBERS",
            },
          },
        },
        {
          AND: [
            {
              privacySettings: {
                is: {
                  appearInSearch: true,
                  profileVisibility: "FOLLOWERS_ONLY",
                },
              },
            },
            {
              followsAsFollowing: {
                some: { followerAccountId: session.accountId },
              },
            },
          ],
        },
      ],
    };
    if (search?.trim()) {
      const q = search.trim();
      where.AND = [
        {
          OR: [
            {
              profile: {
                is: { displayName: { contains: q, mode: "insensitive" } },
              },
            },
            {
              AND: [
                { privacySettings: { is: { locationSharing: "CITY_ONLY" } } },
                {
                  profile: {
                    is: { locationCity: { contains: q, mode: "insensitive" } },
                  },
                },
              ],
            },
          ],
        },
      ];
    }
    const items = await anyPrisma.memberAccount.findMany({ where, take: 30 });
    return { items };
  }

  async listGroups(authorization: string | undefined) {
    // CommunityGroup currently only persists name, description, category,
    // member count, today's post count, and createdAt. It has no visibility,
    // status, owner, or membership relation in the installed Prisma schema.
    // Query only existing fields and do not imply that listed groups are joined.
    await this.auth.authenticateAuthorization(authorization);
    const items = await this.prisma.communityGroup.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return { source: "postgresql_live" as const, items };
  }

  async listFollowers(
    authorization: string | undefined,
    mode: "followers" | "following" = "followers",
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const viewerProfile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
      select: { accountId: true, displayName: true, username: true },
    });
    const viewerUsername = this.deriveUsername(
      viewerProfile?.displayName ?? "Sakhi Member",
      viewerProfile?.username,
    );
    const normalizeHandle = (value: string) =>
      value.trim().replace(/^@/, "").toLowerCase();
    const viewerHandle = normalizeHandle(viewerUsername);

    const [ownedDirectory, outgoingBlocks, incomingBlocks, outgoingFollows] =
      await Promise.all([
        this.prisma.communityDirectoryProfile.findUnique({
          where: { username: viewerUsername },
        }),
        this.prisma.memberModerationBlock.findMany({
          where: { accountId: session.accountId },
          select: { blockedUsername: true },
        }),
        this.prisma.memberModerationBlock.findMany({
          where: {
            blockedUsername: {
              in: [viewerUsername, viewerHandle, `@${viewerHandle}`],
            },
          },
          select: { accountId: true },
        }),
        this.prisma.memberFollow.findMany({
          where: { accountId: session.accountId, isFollowing: true },
          select: { directoryProfileId: true },
        }),
      ]);

    const blockedHandles = new Set(
      outgoingBlocks.map((item) => normalizeHandle(item.blockedUsername)),
    );
    const accountsWhoBlockedViewer = new Set(
      incomingBlocks.map((item) => item.accountId),
    );
    const followingDirectoryIds = new Set(
      outgoingFollows.map((item) => item.directoryProfileId),
    );

    let rawProfiles: Array<{
      accountId: string;
      displayName: string;
      username: string | null;
      bio: string;
      avatarAsset: string;
      avatarMediaAssetId: string | null;
      interests: unknown;
      businessProfileUrl: string | null;
      businessProfileName: string | null;
      businessCategory: string | null;
      account: {
        status: string;
        verificationStatus: string;
        privacyPreference: {
          viewProfile: string;
          searchResults: string;
        } | null;
      };
      directoryProfileId?: string | null;
    }> = [];

    if (mode === "following") {
      const followedRows = await this.prisma.memberFollow.findMany({
        where: { accountId: session.accountId, isFollowing: true },
        include: { directoryProfile: true },
      });
      const candidates = followedRows
        .map((item) => item.directoryProfile)
        .filter((item): item is NonNullable<typeof item> => Boolean(item && item.username))
        .filter((item) => !blockedHandles.has(normalizeHandle(item.username)));
      const handleVariants = [
        ...new Set(
          candidates.flatMap((item) => {
            const clean = item.username.replace(/^@+/, "");
            return [item.username, clean, `@${clean}`, `@${clean.toLowerCase()}`, clean.toLowerCase()];
          }),
        ),
      ];
      if (handleVariants.length > 0) {
        const matchedProfiles = await this.prisma.memberProfile.findMany({
          where: {
            username: { in: handleVariants },
            account: {
              is: {
                status: "ACTIVE",
                verificationStatus: "VERIFIED",
              },
            },
          },
          include: {
            account: {
              select: {
                status: true,
                verificationStatus: true,
                privacyPreference: {
                  select: { viewProfile: true, searchResults: true },
                },
              },
            },
          },
        });
        const profileByNormHandle = new Map(
          matchedProfiles.map((p) => [normalizeHandle(p.username ?? ""), p]),
        );
        rawProfiles = candidates.map((cand) => {
          const norm = normalizeHandle(cand.username);
          const matched = profileByNormHandle.get(norm);
          if (matched) {
            return {
              ...matched,
              directoryProfileId: cand.id,
            };
          }
          return {
            accountId: cand.id,
            displayName: cand.name,
            username: cand.username.startsWith("@") ? cand.username : `@${cand.username}`,
            bio: cand.bio ?? "",
            avatarAsset: cand.avatarAsset ?? "",
            avatarMediaAssetId: null,
            interests: [],
            businessProfileUrl: null,
            businessProfileName: null,
            businessCategory: null,
            account: {
              status: "ACTIVE",
              verificationStatus: "VERIFIED",
              privacyPreference: null,
            },
            directoryProfileId: cand.id,
          };
        });
      }
    } else if (ownedDirectory) {
      const followerRows = await this.prisma.memberFollow.findMany({
        where: {
          directoryProfileId: ownedDirectory.id,
          isFollowing: true,
        },
        include: {
          account: {
            include: { profile: true, privacyPreference: true },
          },
        },
      });
      rawProfiles = followerRows
        .map((item) => {
          const account = item.account;
          const profile = account.profile;
          if (!profile) return null;
          const privacyPreference = account.privacyPreference;
          return {
            ...profile,
            account: {
              status: account.status,
              verificationStatus: account.verificationStatus,
              privacyPreference: privacyPreference
                ? {
                    viewProfile: privacyPreference.viewProfile,
                    searchResults: privacyPreference.searchResults,
                  }
                : null,
            },
          };
        })
        .filter(
          (profile): profile is NonNullable<typeof profile> => profile !== null,
        )
        .filter((profile) => !accountsWhoBlockedViewer.has(profile.accountId));
      const candidateHandles = rawProfiles
        .map((profile) => profile.username)
        .filter((username): username is string => Boolean(username));
      const directoryRows = candidateHandles.length
        ? await this.prisma.communityDirectoryProfile.findMany({
            where: { username: { in: candidateHandles } },
            select: { id: true, username: true },
          })
        : [];
      const directoryByHandle = new Map(
        directoryRows.map((item) => [item.username, item.id]),
      );
      rawProfiles = rawProfiles.map((profile) => ({
        ...profile,
        directoryProfileId:
          directoryByHandle.get(profile.username ?? "") ?? null,
      }));
    }

    const items = rawProfiles
      .filter((profile) => profile.account.status === "ACTIVE")
      .filter((profile) => profile.account.verificationStatus === "VERIFIED")
      .filter(
        (profile) =>
          !blockedHandles.has(normalizeHandle(profile.username ?? "")),
      )
      .filter((profile) => {
        const visibility = (
          profile.account.privacyPreference?.viewProfile ??
          "Verified members only"
        ).toLowerCase();
        if (
          visibility.includes("circle") ||
          visibility.includes("only me") ||
          visibility.includes("no one") ||
          visibility.includes("hidden")
        ) {
          return false;
        }
        if (visibility.includes("followers")) {
          return followingDirectoryIds.has(profile.directoryProfileId ?? "");
        }
        return true;
      })
      .map((profile) => {
        const username =
          profile.username ?? this.deriveUsername(profile.displayName, null);
        return {
          id: profile.directoryProfileId ?? profile.accountId,
          accountId: profile.accountId,
          name: profile.displayName,
          username,
          avatarAsset: this.resolveMemberAvatar(
            profile.avatarAsset,
            profile.avatarMediaAssetId,
          ),
          bio: profile.bio,
          isVerified: true,
          verificationStatus: profile.account.verificationStatus,
          isFollowing: Boolean(
            profile.directoryProfileId &&
            followingDirectoryIds.has(profile.directoryProfileId),
          ),
          followsMe: mode === "followers" ? true : false,
          canFollow: Boolean(profile.directoryProfileId),
          interests: this.parseInterests(profile.interests),
          businessProfileUrl: profile.businessProfileUrl,
          businessProfileName: profile.businessProfileName,
          businessCategory: profile.businessCategory,
        };
      });

    if (mode === "following" && ownedDirectory && items.length > 0) {
      const incomingFollows = await this.prisma.memberFollow
        .findMany({
          where: {
            directoryProfileId: ownedDirectory.id,
            isFollowing: true,
            accountId: { in: items.map((i) => i.accountId) },
          },
          select: { accountId: true },
        })
        .catch(() => []);
      const followerAccountSet = new Set(
        incomingFollows.map((row: Record<string, any>) => row.accountId),
      );
      for (const item of items) {
        item.followsMe = followerAccountSet.has(item.accountId);
      }
    }

    return { source: "postgresql_live" as const, mode, items };
  }

  async listNearbyCircles(
    authorization?: string,
    lat?: number,
    lng?: number,
    radiusKm = 15,
    cityQuery?: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const viewerProfile = await this.prisma.memberProfile.findUnique({
      where: { accountId: session.accountId },
    });

    const cityCoordinates: Record<
      string,
      { lat: number; lng: number; city: string }
    > = {
      bangalore: { lat: 12.9716, lng: 77.5946, city: "Bengaluru" },
      bengaluru: { lat: 12.9716, lng: 77.5946, city: "Bengaluru" },
      hyderabad: { lat: 17.385, lng: 78.4867, city: "Hyderabad" },
      chennai: { lat: 13.0827, lng: 80.2707, city: "Chennai" },
      kochi: { lat: 9.9312, lng: 76.2673, city: "Kochi" },
      mumbai: { lat: 19.076, lng: 72.8777, city: "Mumbai" },
      pune: { lat: 18.5204, lng: 73.8567, city: "Pune" },
      delhi: { lat: 28.6139, lng: 77.209, city: "New Delhi" },
      kurnool: { lat: 15.8281, lng: 78.0373, city: "Kurnool" },
      tirupati: { lat: 13.6288, lng: 79.4192, city: "Tirupati" },
    };

    const hasGps = hasValidCoordinatePair(lat, lng);
    const effectiveRadiusKm = Math.min(Math.max(radiusKm || 15, 2), 100);
    let viewerCity = (
      cityQuery ||
      viewerProfile?.location ||
      "Bengaluru, India"
    ).trim();
    if (hasGps) {
      let closestCity = viewerCity;
      let minDist = Infinity;
      for (const entry of Object.values(cityCoordinates)) {
        const d = this.haversineDistanceKm(lat!, lng!, entry.lat, entry.lng);
        if (d < minDist) {
          minDist = d;
          if (d <= 65) closestCity = `${entry.city}, India`;
        }
      }
      viewerCity = closestCity;
    }

    const [verifiedProfiles, groups, directoryProfiles, userFollows] =
      await Promise.all([
        this.prisma.memberProfile.findMany({
          where: {
            accountId: { not: session.accountId },
            account: {
              is: { status: "ACTIVE", verificationStatus: "VERIFIED" },
            },
          },
          include: {
            account: {
              select: {
                status: true,
                verificationStatus: true,
                privacyPreference: true,
              },
            },
          },
          take: 60,
        }),
        this.prisma.communityGroup.findMany({
          orderBy: { createdAt: "desc" },
          take: 20,
        }),
        this.prisma.communityDirectoryProfile.findMany(),
        this.prisma.memberFollow.findMany({
          where: { accountId: session.accountId, isFollowing: true },
        }),
      ]);

    const directoryByUsername = new Map(
      directoryProfiles.map((d) => [d.username.toLowerCase(), d]),
    );
    const followedDirIds = new Set(
      userFollows.map((f) => f.directoryProfileId),
    );

    const resolveMemberCoords = (locationText: string, index: number) => {
      const lower = (locationText || "").toLowerCase();
      for (const [key, coords] of Object.entries(cityCoordinates)) {
        if (lower.includes(key)) {
          const offsetLat = ((index % 5) - 2) * 0.012;
          const offsetLng = ((index % 4) - 1.5) * 0.012;
          return {
            lat: coords.lat + offsetLat,
            lng: coords.lng + offsetLng,
            cityLabel: coords.city,
          };
        }
      }
      if (hasGps) {
        const offsetLat = ((index % 5) + 1) * 0.011;
        const offsetLng = ((index % 3) - 1) * 0.011;
        return {
          lat: lat! + offsetLat,
          lng: lng! + offsetLng,
          cityLabel: locationText || viewerCity,
        };
      }
      return {
        lat: 12.9716 + index * 0.01,
        lng: 77.5946 + index * 0.01,
        cityLabel: locationText || "Bengaluru",
      };
    };

    const baseLat = hasGps ? lat! : 12.9716;
    const baseLng = hasGps ? lng! : 77.5946;

    const mappedMembers = verifiedProfiles
      .filter((p) => {
        const showLoc =
          p.account.privacyPreference?.showLocation ?? "General location only";
        return !showLoc.toLowerCase().includes("hide");
      })
      .map((p, idx) => {
        const coords = resolveMemberCoords(p.location, idx);
        const distanceKm = this.haversineDistanceKm(
          baseLat,
          baseLng,
          coords.lat,
          coords.lng,
        );
        const handle = p.username ?? this.deriveUsername(p.displayName, null);
        const dir = directoryByUsername.get(handle.toLowerCase());
        return {
          id: dir?.id ?? p.accountId,
          accountId: p.accountId,
          name: p.displayName,
          username: handle,
          bio: p.bio,
          location: p.location || coords.cityLabel,
          distanceKm,
          avatarAsset: this.resolveMemberAvatar(
            p.avatarAsset,
            p.avatarMediaAssetId,
          ),
          interests: this.parseInterests(p.interests),
          isVerified: true,
          isFollowing: dir ? followedDirIds.has(dir.id) : false,
        };
      })
      .sort((a, b) => a.distanceKm - b.distanceKm);

    const nearbyMembers = mappedMembers.filter(
      (m) => m.distanceKm <= effectiveRadiusKm,
    );
    const suggestedMembers =
      nearbyMembers.length > 0 ? nearbyMembers : mappedMembers.slice(0, 8);

    const activeCircles = groups.map((g, idx) => {
      const circleDistanceKm = Number(
        Math.min(effectiveRadiusKm - 0.5, 1.2 + idx * 1.6).toFixed(1),
      );
      return {
        id: g.id,
        name: g.name,
        description: g.description.replace(
          /^\d+(\.\d+)?k?\s*members\s*•\s*/i,
          "",
        ),
        category: g.category,
        membersCount: g.membersCount,
        newPostsToday: g.newPostsToday,
        distanceKm: circleDistanceKm,
        locationArea: viewerCity,
      };
    });

    return {
      source: "postgresql_live" as const,
      hasLiveCoordinates: hasGps,
      locationLabel: viewerCity,
      radiusKm: effectiveRadiusKm,
      coordinates: { latitude: baseLat, longitude: baseLng },
      totalNearbyMembers: suggestedMembers.length,
      totalActiveCircles: activeCircles.length,
      nearbyMembers: suggestedMembers,
      activeCircles,
    };
  }

  async listMemberConnections(
    authorization: string | undefined,
    targetIdentifier: string,
    mode: "followers" | "following" = "followers",
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleanTarget = (targetIdentifier ?? "").trim();
    if (!cleanTarget) {
      return { source: "postgresql_live" as const, mode, items: [] };
    }
    const normalizeHandle = (val: string) =>
      val.trim().replace(/^@+/, "").toLowerCase();

    let targetProfile = await this.prisma.memberProfile
      .findFirst({
        where: {
          OR: [
            ...(cleanTarget.length === 36 ? [{ accountId: cleanTarget }] : []),
            { username: { equals: cleanTarget, mode: "insensitive" } },
            {
              username: {
                equals: `@${normalizeHandle(cleanTarget)}`,
                mode: "insensitive",
              },
            },
          ],
        },
      })
      .catch(() => null);

    if (!targetProfile && cleanTarget.length === 36) {
      const dirById = await this.prisma.communityDirectoryProfile
        .findUnique({ where: { id: cleanTarget } })
        .catch(() => null);
      if (dirById) {
        targetProfile = await this.prisma.memberProfile
          .findFirst({
            where: {
              username: { equals: dirById.username, mode: "insensitive" },
            },
          })
          .catch(() => null);
      }
    }

    if (!targetProfile || targetProfile.accountId === session.accountId) {
      return this.listFollowers(authorization, mode);
    }

    const targetUsername = this.deriveUsername(
      targetProfile.displayName,
      targetProfile.username,
    );
    const targetDir = await this.prisma.communityDirectoryProfile
      .findFirst({
        where: {
          username: { equals: targetUsername, mode: "insensitive" },
        },
      })
      .catch(() => null);

    const viewerProfile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const viewerUsername = this.deriveUsername(
      viewerProfile?.displayName ?? "Sakhi Member",
      viewerProfile?.username,
    );
    const [viewerDir, viewerFollowingRows] = await Promise.all([
      this.prisma.communityDirectoryProfile
        .findFirst({
          where: { username: { equals: viewerUsername, mode: "insensitive" } },
        })
        .catch(() => null),
      this.prisma.memberFollow
        .findMany({
          where: { accountId: session.accountId, isFollowing: true },
        })
        .catch(() => []),
    ]);
    const viewerFollowedDirIds = new Set(
      viewerFollowingRows.map((r) => r.directoryProfileId),
    );
    const viewerIncomingRows = viewerDir
      ? await this.prisma.memberFollow
          .findMany({
            where: { directoryProfileId: viewerDir.id, isFollowing: true },
          })
          .catch(() => [])
      : [];
    const viewerFollowerAccountIds = new Set(
      viewerIncomingRows.map((r) => r.accountId),
    );

    if (mode === "following") {
      const targetFollowing = await this.prisma.memberFollow
        .findMany({
          where: { accountId: targetProfile.accountId, isFollowing: true },
          include: { directoryProfile: true },
        })
        .catch(() => []);
      const handles = targetFollowing
        .map((r) => r.directoryProfile?.username)
        .filter((u): u is string => Boolean(u));
      const memberRows = handles.length
        ? await this.prisma.memberProfile
            .findMany({
              where: { username: { in: handles } },
            })
            .catch(() => [])
        : [];
      const memberByHandle = new Map(
        memberRows.map((m) => [normalizeHandle(m.username ?? ""), m]),
      );
      const items = targetFollowing
        .map((r) => {
          const dir = r.directoryProfile;
          if (!dir) return null;
          const m = memberByHandle.get(normalizeHandle(dir.username));
          return {
            id: dir.id,
            accountId: m?.accountId ?? dir.id,
            name: m?.displayName ?? dir.name,
            username: dir.username,
            avatarAsset: this.resolveMemberAvatar(
              m?.avatarAsset ?? dir.avatarAsset,
              m?.avatarMediaAssetId,
            ),
            bio: m?.bio ?? dir.bio,
            isVerified: true,
            isFollowing: viewerFollowedDirIds.has(dir.id),
            followsMe: m ? viewerFollowerAccountIds.has(m.accountId) : false,
            canFollow: true,
            interests: this.parseInterests(m?.interests),
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);
      return { source: "postgresql_live" as const, mode, items };
    }

    if (!targetDir) {
      return { source: "postgresql_live" as const, mode, items: [] };
    }
    const targetFollowers = await this.prisma.memberFollow
      .findMany({
        where: { directoryProfileId: targetDir.id, isFollowing: true },
        include: { account: { include: { profile: true } } },
      })
      .catch(() => []);
    const allDirs = await this.prisma.communityDirectoryProfile
      .findMany()
      .catch(() => []);
    const dirByHandle = new Map(
      allDirs.map((d) => [normalizeHandle(d.username), d]),
    );
    const items = targetFollowers
      .map((row) => {
        const p = row.account?.profile;
        if (!p) return null;
        const handle = this.deriveUsername(p.displayName, p.username);
        const dir = dirByHandle.get(normalizeHandle(handle));
        return {
          id: dir?.id ?? p.accountId,
          accountId: p.accountId,
          name: p.displayName,
          username: handle,
          avatarAsset: this.resolveMemberAvatar(
            p.avatarAsset,
            p.avatarMediaAssetId,
          ),
          bio: p.bio,
          isVerified: row.account.verificationStatus === "VERIFIED",
          isFollowing: dir ? viewerFollowedDirIds.has(dir.id) : false,
          followsMe: viewerFollowerAccountIds.has(p.accountId),
          canFollow: Boolean(dir),
          interests: this.parseInterests(p.interests),
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);

    return { source: "postgresql_live" as const, mode, items };
  }

  async getMemberProfileOverview(
    authorization: string | undefined,
    targetIdentifier: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleanTarget = (targetIdentifier ?? "").trim();
    const normalizeHandle = (val: string) =>
      val.trim().replace(/^@+/, "").toLowerCase();

    let targetProfile = await this.prisma.memberProfile
      .findFirst({
        where: {
          OR: [
            ...(cleanTarget.length === 36 ? [{ accountId: cleanTarget }] : []),
            { username: { equals: cleanTarget, mode: "insensitive" } },
            {
              username: {
                equals: `@${normalizeHandle(cleanTarget)}`,
                mode: "insensitive",
              },
            },
          ],
        },
        include: { account: true },
      })
      .catch(() => null);

    if (!targetProfile && cleanTarget.length === 36) {
      const dir = await this.prisma.communityDirectoryProfile
        .findUnique({ where: { id: cleanTarget } })
        .catch(() => null);
      if (dir) {
        targetProfile = await this.prisma.memberProfile
          .findFirst({
            where: {
              username: { equals: dir.username, mode: "insensitive" },
            },
            include: { account: true },
          })
          .catch(() => null);
      }
    }

    if (!targetProfile) {
      throw new NotFoundException("Member profile was not found.");
    }

    const handle = this.deriveUsername(
      targetProfile.displayName,
      targetProfile.username,
    );
    const normTargetHandle = normalizeHandle(handle);
    const viewerProfileForMod = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const modCtx = await this.resolveViewerModerationContext(
      session.accountId,
      viewerProfileForMod?.username ?? null,
    );

    if (
      targetProfile.accountId !== session.accountId &&
      modCtx.accountsWhoBlockedViewer.has(targetProfile.accountId)
    ) {
      throw new NotFoundException("Member profile was not found.");
    }

    const isBlockedByViewer =
      targetProfile.accountId !== session.accountId &&
      modCtx.blockedHandles.has(normTargetHandle);
    const isMutedByViewer = modCtx.mutedHandles.has(normTargetHandle);
    const isRestrictedByViewer = modCtx.restrictedHandles.has(normTargetHandle);

    const anyPrismaForPrivacy = this.prisma as Record<string, any>;
    const targetPrivacy =
      typeof anyPrismaForPrivacy.memberPrivacyPreference?.findUnique ===
      "function"
        ? await anyPrismaForPrivacy.memberPrivacyPreference
            .findUnique({ where: { accountId: targetProfile.accountId } })
            .catch(() => null)
        : null;

    const [targetDir, posts, followingCount, userLikes, userSaves] =
      await Promise.all([
        this.prisma.communityDirectoryProfile
          .findFirst({
            where: { username: { equals: handle, mode: "insensitive" } },
          })
          .catch(() => null),
        this.prisma.communityPost
          .findMany({
            where: {
              OR: [
                { authorAccountId: targetProfile.accountId },
                { authorUsername: { equals: handle, mode: "insensitive" } },
              ],
              deletedAt: null,
              status: { in: ["PUBLISHED", "EDITED"] },
              visibility: { not: "PRIVATE_SELF" },
            },
            orderBy: { createdAt: "desc" },
            take: 50,
          })
          .catch(() => []),
        this.prisma.memberFollow
          .count({
            where: { accountId: targetProfile.accountId, isFollowing: true },
          })
          .catch(() => 0),
        this.prisma.communityPostLike
          .findMany({
            where: { accountId: session.accountId },
            select: { postId: true },
          })
          .catch(() => []),
        this.prisma.communityPostSave
          .findMany({
            where: { accountId: session.accountId },
            select: { postId: true },
          })
          .catch(() => []),
      ]);

    const followersCount = targetDir
      ? await this.prisma.memberFollow
          .count({
            where: { directoryProfileId: targetDir.id, isFollowing: true },
          })
          .catch(() => 0)
      : 0;

    const isFollowing = targetDir
      ? Boolean(
          (
            await this.prisma.memberFollow
              .findUnique({
                where: {
                  accountId_directoryProfileId: {
                    accountId: session.accountId,
                    directoryProfileId: targetDir.id,
                  },
                },
              })
              .catch(() => null)
          )?.isFollowing,
        )
      : false;

    const viewerProfile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const viewerHandle = this.deriveUsername(
      viewerProfile?.displayName ?? "Sakhi Member",
      viewerProfile?.username,
    );
    const viewerDir = await this.prisma.communityDirectoryProfile
      .findFirst({
        where: { username: { equals: viewerHandle, mode: "insensitive" } },
      })
      .catch(() => null);
    const followsMe = viewerDir
      ? Boolean(
          (
            await this.prisma.memberFollow
              .findUnique({
                where: {
                  accountId_directoryProfileId: {
                    accountId: targetProfile.accountId,
                    directoryProfileId: viewerDir.id,
                  },
                },
              })
              .catch(() => null)
          )?.isFollowing,
        )
      : false;

    const likedSet = new Set(userLikes.map((l) => l.postId));
    const savedSet = new Set(userSaves.map((s) => s.postId));
    const overviewPostIds = posts.map((p) => p.id);
    const anyPrismaOverview = this.prisma as Record<string, any>;
    const hasOverviewCommentQuery =
      typeof anyPrismaOverview.communityPostComment?.findMany === "function";
    const overviewCommentsRaw =
      hasOverviewCommentQuery && overviewPostIds.length > 0
        ? await anyPrismaOverview.communityPostComment
            .findMany({
              where: {
                postId: { in: overviewPostIds },
                deletedAt: null,
                isRemovedByModerator: false,
              },
              orderBy: { createdAt: "asc" },
            })
            .catch(() => [])
        : [];
    const overviewCommentCountByPostId = new Map<string, number>();
    for (const c of overviewCommentsRaw as Array<Record<string, any>>) {
      const pid = String(c.postId ?? "");
      if (!pid) continue;
      overviewCommentCountByPostId.set(
        pid,
        (overviewCommentCountByPostId.get(pid) ?? 0) + 1,
      );
    }

    const isSelf = targetProfile.accountId === session.accountId;
    const viewProfilePref = String(
      targetPrivacy?.viewProfile ?? "Verified members only",
    ).toLowerCase();
    const seePostsPref = String(
      targetPrivacy?.seePosts ?? "Verified members only",
    ).toLowerCase();
    const showLocationPref = String(
      targetPrivacy?.showLocation ?? "General location only",
    ).toLowerCase();
    const messageMePref = String(
      targetPrivacy?.messageMe ?? "Verified members only",
    ).toLowerCase();

    const isProfilePrivateToViewer =
      !isSelf &&
      (viewProfilePref.includes("only me") ||
        viewProfilePref.includes("no one") ||
        (viewProfilePref.includes("follower") && !isFollowing));

    const canViewerSeePosts =
      isSelf ||
      (!isBlockedByViewer &&
        !isProfilePrivateToViewer &&
        !seePostsPref.includes("only me") &&
        !seePostsPref.includes("no one") &&
        (!seePostsPref.includes("follower") || isFollowing));

    const canViewerMessage =
      !isSelf &&
      !isBlockedByViewer &&
      !messageMePref.includes("no one") &&
      (!messageMePref.includes("follower") || isFollowing);

    const visiblePosts = canViewerSeePosts
      ? posts.filter(
          (post) =>
            !modCtx.reportedPostIds.has(post.id) &&
            !modCtx.hiddenPostIds.has(post.id) &&
            (isSelf ||
              post.visibility !== "FOLLOWERS_ONLY" ||
              isFollowing),
        )
      : [];

    const mappedOverviewPosts = visiblePosts.map((post) => ({
      id: post.id,
      postId: post.id,
      authorAccountId: post.authorAccountId ?? targetProfile.accountId,
      authorName: targetProfile.displayName,
      authorUsername: handle,
      authorAvatar: this.resolveMemberAvatar(
        targetProfile.avatarAsset,
        targetProfile.avatarMediaAssetId,
      ),
      authorVerified: targetProfile.account.verificationStatus === "VERIFIED",
      timestamp: this.formatRelativeTime(post.createdAt),
      createdAt: post.createdAt.toISOString(),
      content: post.content,
      body: post.content,
      imageAsset: post.imageAsset,
      mediaAsset: post.imageAsset,
      categoryBadge: post.categoryBadge,
      categorySlug: post.categorySlug,
      visibility: post.visibility,
      likesCount: post.likesCount,
      commentsCount: hasOverviewCommentQuery
        ? (overviewCommentCountByPostId.get(post.id) ?? 0)
        : post.commentsCount,
      savesCount: post.savesCount,
      isLiked: likedSet.has(post.id),
      isSaved: savedSet.has(post.id),
      isOwnPost: post.authorAccountId === session.accountId,
    }));

    const mediaPosts = mappedOverviewPosts.filter((p) =>
      Boolean(p.imageAsset && String(p.imageAsset).trim().length > 0),
    );

    return {
      id: targetDir?.id ?? targetProfile.accountId,
      accountId: targetProfile.accountId,
      displayName: targetProfile.displayName,
      username: handle,
      bio: isBlockedByViewer
        ? "You have blocked this member."
        : isProfilePrivateToViewer
          ? "This member's profile is shared only with approved followers."
          : (targetProfile.bio ?? ""),
      location:
        isBlockedByViewer ||
        isProfilePrivateToViewer ||
        showLocationPref.includes("hide")
          ? ""
          : (targetProfile.location ?? ""),
      avatarAsset: this.resolveMemberAvatar(
        targetProfile.avatarAsset,
        targetProfile.avatarMediaAssetId,
      ),
      isVerified: targetProfile.account.verificationStatus === "VERIFIED",
      isFollowing: isBlockedByViewer ? false : isFollowing,
      followsMe: isBlockedByViewer ? false : followsMe,
      isBlocked: isBlockedByViewer,
      isMuted: isMutedByViewer,
      isRestricted: isRestrictedByViewer,
      isPrivateProfile: isProfilePrivateToViewer,
      canMessage: canViewerMessage,
      messageRequiresRequest: !isFollowing && canViewerMessage,
      postsCount: mappedOverviewPosts.length,
      mediaCount: mediaPosts.length,
      followersCount,
      followingCount,
      interests:
        isBlockedByViewer || isProfilePrivateToViewer
          ? []
          : this.parseInterests(targetProfile.interests),
      businessProfileUrl:
        isBlockedByViewer || isProfilePrivateToViewer
          ? null
          : (targetProfile.businessProfileUrl ?? null),
      businessProfileName:
        isBlockedByViewer || isProfilePrivateToViewer
          ? null
          : (targetProfile.businessProfileName ?? null),
      businessCategory:
        isBlockedByViewer || isProfilePrivateToViewer
          ? null
          : (targetProfile.businessCategory ?? null),
      posts: mappedOverviewPosts,
      mediaPosts,
    };
  }

  async createGroup(
    authorization: string | undefined,
    dto: {
      name: string;
      description?: string;
      visibility: "VERIFIED_MEMBERS" | "PRIVATE";
    },
  ) {
    await this.auth.authenticateAuthorization(authorization);
    const trimmedName = dto.name.trim();
    if (trimmedName.length < 2) {
      throw new BadRequestException(
        "Group name must be at least 2 characters.",
      );
    }
    const group = await this.prisma.communityGroup.create({
      data: {
        name: trimmedName,
        description:
          dto.description?.trim() || "Verified Sakhi community group.",
        category: dto.visibility === "PRIVATE" ? "Private Circle" : "Community",
        membersCount: 1,
        newPostsToday: 0,
      },
    });
    return group;
  }

  async createEvent(
    authorization: string | undefined,
    dto: {
      groupId: string;
      title: string;
      description: string;
      startsAt: string;
      endsAt: string;
      locationCity?: string;
    },
  ) {
    await this.auth.authenticateAuthorization(authorization);
    const title = dto.title.trim();
    const description = dto.description.trim();
    if (!title || !description) {
      throw new BadRequestException(
        "Event title and description cannot be empty.",
      );
    }
    return {
      id: randomUUID(),
      groupId: dto.groupId,
      title,
      description,
      startsAt: dto.startsAt,
      endsAt: dto.endsAt,
    };
  }

  async reportMember(
    authorization: string | undefined,
    dto: {
      reportedAccountId: string;
      postId?: string;
      reason: string;
      details?: string;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (dto.postId && anyPrisma.memberPost?.findFirst) {
      const visiblePost = await anyPrisma.memberPost.findFirst({
        where: {
          id: dto.postId,
          status: "PUBLISHED",
          deletedAt: null,
          account: {
            is: {
              id: dto.reportedAccountId,
              status: "ACTIVE",
              verificationStatus: "VERIFIED",
            },
          },
        },
      });
      if (!visiblePost) {
        throw new NotFoundException("The reported post was not found.");
      }
      return anyPrisma.memberReport.create({
        data: {
          reporterAccountId: session.accountId,
          reportedAccountId: dto.reportedAccountId,
          postId: dto.postId,
          reason: dto.reason,
          details: dto.details ?? null,
        },
      });
    }
    return this.reportUserOrPost(authorization, {
      targetHandle: dto.reportedAccountId,
      postId: dto.postId,
      reason: dto.reason,
      details: dto.details,
    });
  }

  async listSavedPosts(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (anyPrisma.memberPostBookmark?.findMany) {
      const items = await anyPrisma.memberPostBookmark.findMany({
        where: {
          accountId: session.accountId,
          post: {
            is: {
              status: "PUBLISHED",
              deletedAt: null,
              account: {
                is: {
                  status: "ACTIVE",
                  verificationStatus: "VERIFIED",
                },
              },
            },
          },
        },
      });
      return { items };
    }
    return this.listPosts(authorization, { savedOnly: true });
  }

  async requestAccountDeletion(
    authorization: string | undefined,
    dto: { confirmation: string; reason?: string },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    if (dto.confirmation !== "DELETE") {
      throw new BadRequestException("Confirmation must be DELETE.");
    }
    const anyPrisma = this.prisma as Record<string, any>;
    const now = new Date();
    return anyPrisma.$transaction(async (tx: Record<string, any>) => {
      const existingReq = tx.accountDeletionRequest?.findFirst
        ? await tx.accountDeletionRequest.findFirst({
            where: {
              accountId: session.accountId,
              status: { in: ["REQUESTED", "PROCESSING"] },
            },
          })
        : null;
      const createdReq =
        existingReq ??
        (tx.accountDeletionRequest?.create
          ? await tx.accountDeletionRequest.create({
              data: {
                accountId: session.accountId,
                status: "REQUESTED",
                requestReason: dto.reason ?? null,
              },
            })
          : { id: randomUUID(), status: "REQUESTED", requestedAt: now });

      if (tx.memberAccount?.update) {
        await tx.memberAccount.update({
          where: { id: session.accountId },
          data: { status: "DELETED", phoneVerifiedAt: null },
        });
      }
      if (tx.memberProfile?.update) {
        await tx.memberProfile
          .update({
            where: { accountId: session.accountId },
            data: {
              displayName: "Deleted member",
              email: null,
              profilePhotoRef: null,
              bio: null,
              locationCity: null,
              interests: [],
            },
          })
          .catch(async () => {
            await tx.memberProfile.update({
              where: { accountId: session.accountId },
              data: {
                displayName: "Deleted member",
                username: null,
                email: null,
                profilePhotoRef: null,
                bio: "",
                location: "",
                interests: [],
                businessProfileUrl: null,
                businessProfileName: null,
                businessCategory: null,
              },
            });
          });
      }
      if (tx.communityPost?.updateMany) {
        await tx.communityPost
          .updateMany({
            where: { authorAccountId: session.accountId },
            data: {
              content: "[removed]",
              imageAsset: null,
              moderationStatus: "REMOVED",
            },
          })
          .catch(() => undefined);
      }
      if (tx.communityPostComment?.deleteMany) {
        await tx.communityPostComment
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.communityPostLike?.deleteMany) {
        await tx.communityPostLike
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.communityPostSave?.deleteMany) {
        await tx.communityPostSave
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.memberFollow?.deleteMany) {
        await tx.memberFollow
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.memberPrivacyPreference?.deleteMany) {
        await tx.memberPrivacyPreference
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.memberNotificationPreference?.deleteMany) {
        await tx.memberNotificationPreference
          .deleteMany({
            where: { accountId: session.accountId },
          })
          .catch(() => undefined);
      }
      if (tx.memberPost?.updateMany) {
        await tx.memberPost.updateMany({
          where: { accountId: session.accountId },
          data: {
            body: "[removed]",
            mediaRef: null,
            status: "REMOVED",
            deletedAt: now,
          },
        });
      }
      if (tx.memberPostComment?.updateMany) {
        await tx.memberPostComment.updateMany({
          where: { accountId: session.accountId },
          data: { body: "[removed]", deletedAt: now },
        });
        await tx.memberPostComment.updateMany({
          where: { post: { is: { accountId: session.accountId } } },
          data: { body: "[removed]", deletedAt: now },
        });
      }
      if (tx.memberPostLike?.deleteMany) {
        await tx.memberPostLike.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.memberPostBookmark?.deleteMany) {
        await tx.memberPostBookmark.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.postAudienceMember?.deleteMany) {
        await tx.postAudienceMember.deleteMany({
          where: {
            OR: [
              { accountId: session.accountId },
              { post: { is: { accountId: session.accountId } } },
            ],
          },
        });
      }
      if (tx.socialFollow?.deleteMany) {
        await tx.socialFollow.deleteMany({
          where: {
            OR: [
              { followerAccountId: session.accountId },
              { followingAccountId: session.accountId },
            ],
          },
        });
      }
      if (tx.memberBlock?.deleteMany) {
        await tx.memberBlock.deleteMany({
          where: {
            OR: [
              { blockerAccountId: session.accountId },
              { blockedAccountId: session.accountId },
            ],
          },
        });
      }
      if (tx.eventRegistration?.deleteMany) {
        await tx.eventRegistration.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.communityEvent?.updateMany) {
        await tx.communityEvent.updateMany({
          where: { hostAccountId: session.accountId },
          data: { status: "CANCELLED" },
        });
      }
      if (tx.communityGroup?.updateMany) {
        await tx.communityGroup.updateMany({
          where: { createdByAccountId: session.accountId },
          data: { status: "ARCHIVED" },
        });
      }
      if (tx.groupMembership?.deleteMany) {
        await tx.groupMembership.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.businessProfile?.deleteMany) {
        await tx.businessProfile.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.memberPrivacySettings?.deleteMany) {
        await tx.memberPrivacySettings.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.memberNotificationPreferences?.deleteMany) {
        await tx.memberNotificationPreferences.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.memberCommunicationPreference?.deleteMany) {
        await tx.memberCommunicationPreference.deleteMany({
          where: { accountId: session.accountId },
        });
      }
      if (tx.authSession?.updateMany) {
        await tx.authSession.updateMany({
          where: { accountId: session.accountId, revokedAt: null },
          data: { revokedAt: now },
        });
      }
      if (tx.auditEvent?.createMany) {
        await tx.auditEvent.createMany({
          data: {
            actorType: "MEMBER",
            actorId: session.accountId,
            action: "module2.account.deletion_requested",
            targetType: "account_deletion_request",
            targetId: createdReq.id,
            outcome: "requested",
            requestId: randomUUID(),
          },
        });
      }
      return {
        requestId: createdReq.id,
        status: createdReq.status,
        requestedAt: (createdReq.requestedAt ?? now).toISOString(),
      };
    });
  }

  async deleteSosEvent(authorization: string | undefined, eventId: string) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const existing = await this.prisma.safetySosEvent
      .findFirst({
        where: { id: eventId, accountId: session.accountId },
      })
      .catch(() => null);
    if (!existing) {
      return { deleted: true, eventId };
    }
    const anyPrisma = this.prisma as Record<string, any>;
    if (existing.shareToken && anyPrisma.safetyLocationShare?.updateMany) {
      await anyPrisma.safetyLocationShare
        .updateMany({
          where: { shareToken: existing.shareToken },
          data: { status: "STOPPED", stoppedAt: new Date() },
        })
        .catch(() => undefined);
    }
    await this.prisma.safetySosEvent
      .delete({ where: { id: eventId } })
      .catch(() => undefined);
    return { deleted: true, eventId };
  }

  async clearSosEvents(
    authorization: string | undefined,
    mode: "resolved" | "all" | "tests" = "all",
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const whereClause: Record<string, any> = {
      accountId: session.accountId,
    };
    if (mode === "tests") {
      whereClause.OR = [
        { isTestMode: true },
        { status: { in: ["TEST_MODE", "CANCELLED"] } },
      ];
    } else if (mode === "resolved") {
      whereClause.status = { in: ["RESOLVED", "CANCELLED", "TEST_MODE"] };
    }
    if (mode === "all" && anyPrisma.safetyLocationShare?.updateMany) {
      await anyPrisma.safetyLocationShare
        .updateMany({
          where: { accountId: session.accountId, status: "ACTIVE" },
          data: { status: "STOPPED", stoppedAt: new Date() },
        })
        .catch(() => undefined);
    }
    const res = await this.prisma.safetySosEvent
      .deleteMany({ where: whereClause })
      .catch(() => ({ count: 0 }));
    return { clearedCount: res.count, mode };
  }

  async toggleJoinCommunityGroup(
    authorization: string | undefined,
    groupIdOrName: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const cleaned = decodeURIComponent(groupIdOrName).trim();
    let group = await this.prisma.communityGroup
      .findFirst({
        where: {
          OR: [
            ...(cleaned.length === 36 ? [{ id: cleaned }] : []),
            { name: { equals: cleaned, mode: "insensitive" } },
          ],
        },
      })
      .catch(() => null);

    if (!group) {
      group = await this.prisma.communityGroup.create({
        data: {
          name: cleaned.slice(0, 120) || "Sakhi Community Circle",
          description: "Verified women community support circle",
          category: "Community",
          membersCount: 1,
          newPostsToday: 0,
        },
      });
    }

    const updated = await this.prisma.communityGroup.update({
      where: { id: group.id },
      data: { membersCount: Math.max(1, group.membersCount + 1) },
    });

    await this.prisma.auditEvent
      .create({
        data: {
          actorType: "MEMBER",
          actorId: session.accountId,
          action: "module2.circle.joined",
          targetType: "community_group",
          targetId: updated.id,
          outcome: "joined",
          requestId: randomUUID(),
        },
      })
      .catch(() => undefined);

    return {
      groupId: updated.id,
      name: updated.name,
      membersCount: updated.membersCount,
      joined: true,
    };
  }

  // ===========================================================================
  // MODULE 6: WOMEN-OWNED BUSINESS PAGES (SRS Section 8.1 - 8.5)
  // ===========================================================================
  private static readonly SRS_BUSINESS_CATEGORIES = [
    "Fashion and clothing",
    "Beauty and personal care",
    "Food and catering",
    "Health and fitness",
    "Education and training",
    "Home services",
    "Professional consulting",
    "Art and handicrafts",
    "Retail and ecommerce",
    "Events and photography",
    "Freelancers and independent professionals",
    "Other",
  ];

  async listBusinessCategories() {
    const cfg = await SakhiAdminRbacRegistry.getPlatformConfig(this.prisma);
    const merged = Array.from(
      new Set([
        ...Module2Service.SRS_BUSINESS_CATEGORIES,
        ...(cfg.businessCategories ?? []),
      ]),
    );
    return {
      categories: merged,
      total: merged.length,
    };
  }

  private mapBusinessForViewer(
    raw: Record<string, any>,
    viewerAccountId: string | null,
    viewerLat?: number,
    viewerLng?: number,
  ) {
    const isOwner = Boolean(
      viewerAccountId &&
      raw.ownerAccountId &&
      String(raw.ownerAccountId) === viewerAccountId,
    );
    const hidePhone = Boolean(raw.hidePhoneNumber);
    const savedIds = Array.isArray(raw.savedByAccountIds)
      ? (raw.savedByAccountIds as unknown[]).map((x) => String(x))
      : [];
    const isSaved = Boolean(
      viewerAccountId && savedIds.includes(viewerAccountId),
    );

    let distanceKm: number | null = null;
    if (
      typeof viewerLat === "number" &&
      Number.isFinite(viewerLat) &&
      typeof viewerLng === "number" &&
      Number.isFinite(viewerLng) &&
      typeof raw.latitude === "number" &&
      Number.isFinite(raw.latitude) &&
      typeof raw.longitude === "number" &&
      Number.isFinite(raw.longitude)
    ) {
      distanceKm = this.haversineDistanceKm(
        viewerLat,
        viewerLng,
        raw.latitude,
        raw.longitude,
      );
    }

    const rawPhone = raw.contactPhone ? String(raw.contactPhone).trim() : null;
    const exposedPhone = !rawPhone
      ? null
      : isOwner || !hidePhone
        ? rawPhone
        : null;
    const maskedPhone = rawPhone ? this.maskPhone(rawPhone) : null;

    return {
      id: String(raw.id),
      businessCode: String(raw.businessCode ?? "#BIZ-1000"),
      businessName: String(raw.businessName ?? ""),
      ownerAccountId: raw.ownerAccountId ? String(raw.ownerAccountId) : null,
      ownerDisplayName: String(raw.ownerDisplayName ?? "Sakhi Entrepreneur"),
      isOwnBusiness: isOwner,
      category: String(raw.category ?? "Fashion and clothing"),
      city: String(raw.city ?? "Bengaluru"),
      serviceArea: raw.serviceArea
        ? String(raw.serviceArea)
        : String(raw.city ?? "Bengaluru"),
      latitude: typeof raw.latitude === "number" ? raw.latitude : null,
      longitude: typeof raw.longitude === "number" ? raw.longitude : null,
      distanceKm,
      priceRange: String(raw.priceRange ?? "₹500 – ₹2,500"),
      description: String(raw.description ?? ""),
      logoAsset: raw.logoAsset ? String(raw.logoAsset) : null,
      coverImage: raw.coverImage ? String(raw.coverImage) : null,
      contactPhone: exposedPhone,
      contactPhoneMasked: maskedPhone,
      hasPhoneConfigured: Boolean(rawPhone),
      hidePhoneNumber: hidePhone,
      whatsappNumber: raw.whatsappNumber ? String(raw.whatsappNumber) : null,
      instagramHandle: raw.instagramHandle ? String(raw.instagramHandle) : null,
      websiteOrInstagram: raw.websiteOrInstagram
        ? String(raw.websiteOrInstagram)
        : null,
      businessHours:
        raw.businessHours && typeof raw.businessHours === "object"
          ? raw.businessHours
          : {
              mondayToFriday: "10:00 AM – 7:00 PM",
              saturday: "10:00 AM – 5:00 PM",
              sunday: "By Appointment",
              isOpenNow: true,
            },
      productsServices: Array.isArray(raw.productsServices)
        ? raw.productsServices
        : [],
      mediaGallery: Array.isArray(raw.mediaGallery)
        ? raw.mediaGallery
            .map((item: unknown) => {
              if (typeof item === "string") return item.trim();
              if (item && typeof item === "object") {
                const m = item as Record<string, unknown>;
                return String(m.url ?? m.mediaUrl ?? m.imageAsset ?? "").trim();
              }
              return "";
            })
            .filter(Boolean)
        : [],
      offersAndPosts: Array.isArray(raw.offersAndPosts)
        ? raw.offersAndPosts
        : [],
      isSaved,
      savesCount: savedIds.length,
      enquiriesCount: Number(raw.enquiriesCount ?? 0),
      viewsCount: Number(raw.viewsCount ?? 0),
      approvalStatus: String(raw.approvalStatus ?? "PENDING_APPROVAL"),
      verificationBadgeStatus: String(raw.verificationBadgeStatus ?? "NONE"),
      isVerifiedWomanOwned:
        raw.verificationBadgeStatus === "VERIFIED_WOMAN_OWNED",
      isFeatured: Boolean(raw.isFeatured),
      reviewNotes: raw.reviewNotes ? String(raw.reviewNotes) : null,
      reviewedBy: raw.reviewedBy ? String(raw.reviewedBy) : null,
      reportReason: isOwner && raw.reportReason ? String(raw.reportReason) : null,
      createdAt:
        raw.createdAt instanceof Date
          ? raw.createdAt.toISOString()
          : String(raw.createdAt ?? new Date().toISOString()),
      updatedAt:
        raw.updatedAt instanceof Date
          ? raw.updatedAt.toISOString()
          : String(raw.updatedAt ?? new Date().toISOString()),
    };
  }

  async listMemberBusinesses(
    authorization?: string,
    query: {
      search?: string;
      category?: string;
      city?: string;
      lat?: number;
      lng?: number;
      radiusKm?: number;
      savedOnly?: boolean;
      ownerOnly?: boolean;
    } = {},
  ) {
    let viewerAccountId: string | null = null;
    if (authorization) {
      try {
        const session =
          await this.auth.authenticateAuthorization(authorization);
        viewerAccountId = session.accountId;
      } catch {
        viewerAccountId = null;
      }
    }

    const anyPrisma = this.prisma as Record<string, any>;
    let rows: Array<Record<string, any>> = [];
    if (anyPrisma.businessDirectoryListing?.findMany) {
      rows = await anyPrisma.businessDirectoryListing
        .findMany({
          orderBy: [{ isFeatured: "desc" }, { createdAt: "desc" }],
          take: 120,
        })
        .catch(() => []);
    }

    // Also merge any records from SakhiAdminRbacRegistry if not in DB yet
    const regPayload = await SakhiAdminRbacRegistry.listBusinesses(
      this.prisma,
    ).catch(() => null);
    if (regPayload && Array.isArray(regPayload.businesses)) {
      const seenIds = new Set(rows.map((r) => String(r.id)));
      for (const b of regPayload.businesses) {
        if (!seenIds.has(String(b.id))) {
          rows.push(b as unknown as Record<string, any>);
        }
      }
    }

    // Owner-only queries are private. Public browse/search exposes only reviewed listings.
    let items = rows
      .filter((r) => {
        const isOwner =
          Boolean(viewerAccountId) &&
          String(r.ownerAccountId ?? "") === viewerAccountId;
        if (query.ownerOnly) return isOwner;
        const status = String(
          r.approvalStatus ?? "PENDING_APPROVAL",
        ).toUpperCase();
        return status === "APPROVED" || status === "VERIFIED";
      })
      .map((r) =>
        this.mapBusinessForViewer(r, viewerAccountId, query.lat, query.lng),
      );

    if (query.savedOnly) {
      items = items.filter((b) => b.isSaved);
    }

    if (query.category && query.category.trim() && query.category !== "All") {
      const catLower = query.category.trim().toLowerCase();
      items = items.filter(
        (b) =>
          b.category.toLowerCase().includes(catLower) ||
          catLower.includes(b.category.toLowerCase()),
      );
    }

    if (query.city && query.city.trim()) {
      const cityLower = query.city.trim().toLowerCase();
      items = items.filter(
        (b) =>
          b.city.toLowerCase().includes(cityLower) ||
          b.serviceArea.toLowerCase().includes(cityLower),
      );
    }

    if (query.search && query.search.trim()) {
      const q = query.search.trim().toLowerCase();
      items = items.filter((b) => {
        const productText = (b.productsServices as Array<Record<string, any>>)
          .map((p) => `${p.title ?? ""} ${p.description ?? ""}`)
          .join(" ")
          .toLowerCase();
        return (
          b.businessName.toLowerCase().includes(q) ||
          b.category.toLowerCase().includes(q) ||
          b.city.toLowerCase().includes(q) ||
          b.serviceArea.toLowerCase().includes(q) ||
          b.description.toLowerCase().includes(q) ||
          b.ownerDisplayName.toLowerCase().includes(q) ||
          productText.includes(q)
        );
      });
    }

    if (
      typeof query.lat === "number" &&
      Number.isFinite(query.lat) &&
      typeof query.lng === "number" &&
      Number.isFinite(query.lng)
    ) {
      const maxRadius =
        query.radiusKm && query.radiusKm > 0 ? query.radiusKm : 50;
      const nearby = items.filter(
        (b) => b.distanceKm === null || b.distanceKm <= maxRadius,
      );
      items = (nearby.length > 0 ? nearby : items).sort(
        (a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999),
      );
    }

    const catPayload = await this.listBusinessCategories();
    return {
      businesses: items,
      items,
      categories: catPayload.categories,
      total: items.length,
    };
  }

  async getMemberBusinessDetail(
    authorization: string | undefined,
    businessId: string,
  ) {
    let viewerAccountId: string | null = null;
    if (authorization) {
      try {
        const session =
          await this.auth.authenticateAuthorization(authorization);
        viewerAccountId = session.accountId;
      } catch {
        viewerAccountId = null;
      }
    }

    const anyPrisma = this.prisma as Record<string, any>;
    let row = await anyPrisma.businessDirectoryListing
      ?.findFirst({
        where: {
          OR: [
            ...(businessId.length === 36 ? [{ id: businessId }] : []),
            { businessCode: businessId },
          ],
        },
      })
      .catch(() => null);

    if (!row) {
      throw new NotFoundException("Business page was not found.");
    }

    const isOwner =
      Boolean(viewerAccountId) &&
      String(row.ownerAccountId ?? "") === viewerAccountId;
    const status = String(
      row.approvalStatus ?? "PENDING_APPROVAL",
    ).toUpperCase();
    if (!isOwner && status !== "APPROVED" && status !== "VERIFIED") {
      throw new NotFoundException("Business page was not found.");
    }

    // Do not mutate view counts for private/pending listings before access checks.
    if (anyPrisma.businessDirectoryListing?.update) {
      row = await anyPrisma.businessDirectoryListing
        .update({
          where: { id: row.id },
          data: { viewsCount: Number(row.viewsCount ?? 0) + 1 },
        })
        .catch(() => row);
    }

    return {
      business: this.mapBusinessForViewer(row, viewerAccountId),
    };
  }

  async createMemberBusiness(
    authorization: string | undefined,
    dto: Record<string, any>,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const profile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);

    const id = randomUUID();
    const businessCode = `#BIZ-${Math.floor(1000 + Math.random() * 9000)}`;
    const ownerDisplayName =
      profile?.displayName?.trim() || "Verified Sakhi Entrepreneur";
    const businessName = String(dto.businessName ?? "").trim();
    const category =
      String(dto.category ?? "").trim() || "Fashion and clothing";
    const city =
      String(dto.city ?? profile?.location ?? "Bengaluru").trim() ||
      "Bengaluru";
    const serviceArea = String(dto.serviceArea ?? city).trim();
    const description = String(dto.description ?? "").trim();
    const priceRange = String(dto.priceRange ?? "₹500 – ₹2,500").trim();
    const hidePhoneNumber = Boolean(dto.hidePhoneNumber);
    const contactPhone = dto.contactPhone
      ? String(dto.contactPhone).trim()
      : null;
    const whatsappNumber = dto.whatsappNumber
      ? String(dto.whatsappNumber).trim()
      : null;
    const instagramHandle = dto.instagramHandle
      ? String(dto.instagramHandle).trim()
      : null;
    const websiteOrInstagram = dto.websiteOrInstagram
      ? String(dto.websiteOrInstagram).trim()
      : instagramHandle;
    const logoAsset = dto.logoAsset ? String(dto.logoAsset).trim() : null;
    const coverImage = dto.coverImage ? String(dto.coverImage).trim() : null;
    const latitude =
      typeof dto.latitude === "number" && Number.isFinite(dto.latitude)
        ? dto.latitude
        : null;
    const longitude =
      typeof dto.longitude === "number" && Number.isFinite(dto.longitude)
        ? dto.longitude
        : null;
    const businessHours =
      dto.businessHours && typeof dto.businessHours === "object"
        ? dto.businessHours
        : {
            mondayToFriday: "10:00 AM – 7:00 PM",
            saturday: "10:00 AM – 5:00 PM",
            sunday: "Closed",
            isOpenNow: true,
          };
    const productsServices = Array.isArray(dto.productsServices)
      ? dto.productsServices
      : [];
    const mediaGallery = Array.isArray(dto.mediaGallery)
      ? dto.mediaGallery
      : [];
    const offersAndPosts = Array.isArray(dto.offersAndPosts)
      ? dto.offersAndPosts
      : [];
    const verificationBadgeStatus =
      dto.requestVerificationBadge === false ? "NONE" : "PENDING_BADGE";

    const anyPrisma = this.prisma as Record<string, any>;
    let created: Record<string, any> | null = null;
    try {
      created = await anyPrisma.businessDirectoryListing.create({
        data: {
          id,
          businessCode,
          businessName,
          ownerAccountId: session.accountId,
          ownerDisplayName,
          category,
          city,
          serviceArea,
          latitude,
          longitude,
          priceRange,
          description,
          logoAsset,
          coverImage,
          contactPhone,
          hidePhoneNumber,
          whatsappNumber,
          instagramHandle,
          websiteOrInstagram,
          businessHours,
          productsServices,
          mediaGallery,
          offersAndPosts,
          savedByAccountIds: [],
          approvalStatus: "PENDING_APPROVAL",
          verificationBadgeStatus,
          isFeatured: false,
          isReportedFraudulent: false,
        },
      });
    } catch {
      created = await anyPrisma.businessDirectoryListing.create({
        data: {
          id,
          businessCode,
          businessName,
          ownerAccountId: session.accountId,
          ownerDisplayName,
          category,
          city,
          description,
          contactPhone,
          websiteOrInstagram,
          approvalStatus: "PENDING_APPROVAL",
          verificationBadgeStatus,
          isFeatured: false,
          isReportedFraudulent: false,
        },
      });
    }

    // Sync with SakhiAdminRbacRegistry so Super Admin immediately sees the listing with all photos & catalog
    await SakhiAdminRbacRegistry.upsertBusinessListing(
      this.prisma,
      {
        id,
        businessCode,
        businessName,
        ownerAccountId: session.accountId,
        ownerDisplayName,
        category,
        city,
        serviceArea,
        priceRange,
        description,
        logoAsset: logoAsset ?? undefined,
        coverImage: coverImage ?? undefined,
        mediaGallery,
        businessHours,
        productsServices,
        offersAndPosts,
        contactPhone: contactPhone ?? undefined,
        hidePhoneNumber,
        whatsappNumber: whatsappNumber ?? undefined,
        instagramHandle: instagramHandle ?? undefined,
        websiteOrInstagram: websiteOrInstagram ?? undefined,
        approvalStatus: "PENDING_APPROVAL",
        verificationBadgeStatus: verificationBadgeStatus as any,
      },
      ownerDisplayName,
    ).catch(() => undefined);

    // Link business profile on MemberProfile
    await this.prisma.memberProfile
      .update({
        where: { accountId: session.accountId },
        data: {
          businessProfileName: businessName.slice(0, 120),
          businessCategory: category.slice(0, 80),
          businessProfileUrl: `sakhi://business/${id}`,
        },
      })
      .catch(() => undefined);

    return {
      business: this.mapBusinessForViewer(
        created ?? {
          id,
          businessCode,
          businessName,
          ownerAccountId: session.accountId,
          ownerDisplayName,
          category,
          city,
          serviceArea,
          latitude,
          longitude,
          priceRange,
          description,
          logoAsset,
          coverImage,
          contactPhone,
          hidePhoneNumber,
          whatsappNumber,
          instagramHandle,
          websiteOrInstagram,
          businessHours,
          productsServices,
          mediaGallery,
          offersAndPosts,
          approvalStatus: "PENDING_APPROVAL",
          verificationBadgeStatus,
        },
        session.accountId,
      ),
    };
  }

  async updateMemberBusiness(
    authorization: string | undefined,
    businessId: string,
    dto: Record<string, any>,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const existing = await anyPrisma.businessDirectoryListing
      ?.findFirst({
        where: {
          OR: [
            ...(businessId.length === 36 ? [{ id: businessId }] : []),
            { businessCode: businessId },
          ],
        },
      })
      .catch(() => null);

    if (!existing) {
      throw new NotFoundException("Business page was not found.");
    }
    if (
      !existing.ownerAccountId ||
      String(existing.ownerAccountId) !== session.accountId
    ) {
      throw new ForbiddenException(
        "Only the business owner can edit this business page.",
      );
    }

    // Any owner edit requires renewed review before public display.
    const nextVerificationBadgeStatus =
      String(existing.verificationBadgeStatus ?? "NONE") ===
      "VERIFIED_WOMAN_OWNED"
        ? "PENDING_BADGE"
        : String(existing.verificationBadgeStatus ?? "NONE");

    const nextData: Record<string, any> = {
      approvalStatus: "PENDING_APPROVAL",
      verificationBadgeStatus: nextVerificationBadgeStatus,
      ...(dto.businessName !== undefined
        ? { businessName: String(dto.businessName).trim() }
        : {}),
      ...(dto.category !== undefined
        ? { category: String(dto.category).trim() }
        : {}),
      ...(dto.city !== undefined ? { city: String(dto.city).trim() } : {}),
      ...(dto.serviceArea !== undefined
        ? { serviceArea: String(dto.serviceArea).trim() }
        : {}),
      ...(dto.latitude !== undefined ? { latitude: dto.latitude } : {}),
      ...(dto.longitude !== undefined ? { longitude: dto.longitude } : {}),
      ...(dto.priceRange !== undefined
        ? { priceRange: String(dto.priceRange).trim() }
        : {}),
      ...(dto.description !== undefined
        ? { description: String(dto.description).trim() }
        : {}),
      ...(dto.logoAsset !== undefined ? { logoAsset: dto.logoAsset } : {}),
      ...(dto.coverImage !== undefined ? { coverImage: dto.coverImage } : {}),
      ...(dto.contactPhone !== undefined
        ? {
            contactPhone: dto.contactPhone
              ? String(dto.contactPhone).trim()
              : null,
          }
        : {}),
      ...(dto.hidePhoneNumber !== undefined
        ? { hidePhoneNumber: Boolean(dto.hidePhoneNumber) }
        : {}),
      ...(dto.whatsappNumber !== undefined
        ? {
            whatsappNumber: dto.whatsappNumber
              ? String(dto.whatsappNumber).trim()
              : null,
          }
        : {}),
      ...(dto.instagramHandle !== undefined
        ? {
            instagramHandle: dto.instagramHandle
              ? String(dto.instagramHandle).trim()
              : null,
          }
        : {}),
      ...(dto.websiteOrInstagram !== undefined
        ? {
            websiteOrInstagram: dto.websiteOrInstagram
              ? String(dto.websiteOrInstagram).trim()
              : null,
          }
        : {}),
      ...(dto.businessHours !== undefined
        ? { businessHours: dto.businessHours }
        : {}),
      ...(dto.productsServices !== undefined
        ? { productsServices: dto.productsServices }
        : {}),
      ...(dto.mediaGallery !== undefined
        ? { mediaGallery: dto.mediaGallery }
        : {}),
      ...(dto.offersAndPosts !== undefined
        ? { offersAndPosts: dto.offersAndPosts }
        : {}),
    };

    let updated: Record<string, any> = { ...existing, ...nextData };
    try {
      updated = await anyPrisma.businessDirectoryListing.update({
        where: { id: existing.id },
        data: nextData,
      });
    } catch {
      updated = await anyPrisma.businessDirectoryListing.update({
        where: { id: existing.id },
        data: {
          businessName: nextData.businessName ?? existing.businessName,
          category: nextData.category ?? existing.category,
          city: nextData.city ?? existing.city,
          description: nextData.description ?? existing.description,
          contactPhone:
            nextData.contactPhone !== undefined
              ? nextData.contactPhone
              : existing.contactPhone,
          websiteOrInstagram:
            nextData.websiteOrInstagram !== undefined
              ? nextData.websiteOrInstagram
              : existing.websiteOrInstagram,
          approvalStatus: "PENDING_APPROVAL",
          verificationBadgeStatus: nextData.verificationBadgeStatus,
        },
      });
    }

    await SakhiAdminRbacRegistry.upsertBusinessListing(
      this.prisma,
      {
        ...updated,
        id: existing.id,
        approvalStatus: "PENDING_APPROVAL",
        verificationBadgeStatus: nextData.verificationBadgeStatus,
      },
      updated.ownerDisplayName ?? "Sakhi Entrepreneur",
    ).catch(() => undefined);

    return {
      business: this.mapBusinessForViewer(updated, session.accountId),
    };
  }

  async toggleSaveBusiness(
    authorization: string | undefined,
    businessId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const existing = await anyPrisma.businessDirectoryListing
      ?.findFirst({
        where: {
          OR: [
            ...(businessId.length === 36 ? [{ id: businessId }] : []),
            { businessCode: businessId },
          ],
        },
      })
      .catch(() => null);
    if (!existing) {
      throw new NotFoundException("Business page was not found.");
    }
    const isOwner = String(existing.ownerAccountId ?? "") === session.accountId;
    const listingStatus = String(
      existing.approvalStatus ?? "PENDING_APPROVAL",
    ).toUpperCase();
    if (
      !isOwner &&
      listingStatus !== "APPROVED" &&
      listingStatus !== "VERIFIED"
    ) {
      throw new NotFoundException("Business page was not found.");
    }

    const currentSaved = Array.isArray(existing.savedByAccountIds)
      ? (existing.savedByAccountIds as unknown[]).map((x) => String(x))
      : [];
    const alreadySaved = currentSaved.includes(session.accountId);
    const nextSaved = alreadySaved
      ? currentSaved.filter((id) => id !== session.accountId)
      : [...currentSaved, session.accountId];

    try {
      await anyPrisma.businessDirectoryListing.update({
        where: { id: existing.id },
        data: { savedByAccountIds: nextSaved },
      });
    } catch {
      throw new InternalServerErrorException(
        "Your saved-listing change could not be stored. Please try again.",
      );
    }

    return {
      businessId: existing.id,
      isSaved: !alreadySaved,
      savesCount: nextSaved.length,
    };
  }

  async reportBusiness(
    authorization: string | undefined,
    businessId: string,
    dto: { reason: string; details?: string },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const existing = await anyPrisma.businessDirectoryListing
      ?.findFirst({
        where: {
          OR: [
            ...(businessId.length === 36 ? [{ id: businessId }] : []),
            { businessCode: businessId },
          ],
        },
      })
      .catch(() => null);
    if (!existing) {
      throw new NotFoundException("Business page was not found.");
    }
    const isOwner = String(existing.ownerAccountId ?? "") === session.accountId;
    const listingStatus = String(
      existing.approvalStatus ?? "PENDING_APPROVAL",
    ).toUpperCase();
    if (
      !isOwner &&
      listingStatus !== "APPROVED" &&
      listingStatus !== "VERIFIED"
    ) {
      throw new NotFoundException("Business page was not found.");
    }

    const reasonText = dto.reason.trim();
    const detailsText = dto.details?.trim() || "";
    const combinedReason = detailsText
      ? `${reasonText}: ${detailsText}`
      : reasonText;

    if (typeof anyPrisma.businessReport?.create !== "function") {
      throw new InternalServerErrorException(
        "Business reporting is temporarily unavailable. Please try again later.",
      );
    }

    // A report is not successful until its durable report record is saved.
    // Listing flags and registry notes are secondary moderation signals.
    try {
      await anyPrisma.businessReport.create({
        data: {
          id: randomUUID(),
          businessId: existing.id,
          businessName: existing.businessName,
          reporterAccountId: session.accountId,
          reason: reasonText,
          details: detailsText || null,
          status: "OPEN",
        },
      });
    } catch {
      throw new InternalServerErrorException(
        "Your report could not be saved. Please try again later.",
      );
    }

    await anyPrisma.businessDirectoryListing
      .update({
        where: { id: existing.id },
        data: {
          isReportedFraudulent: true,
          reportReason: combinedReason.slice(0, 500),
        },
      })
      .catch(() => undefined);

    await SakhiAdminRbacRegistry.reviewBusinessListing(
      this.prisma,
      existing.id,
      {
        isReportedFraudulent: true,
        reviewNotes: `Reported by member: ${combinedReason}`,
      },
      "Member Safety Report",
    ).catch(() => undefined);

    return {
      reported: true,
      businessId: existing.id,
      message:
        "Business report submitted confidentially to Sakhi Trust & Safety moderators.",
    };
  }

  async createBusinessEnquiry(
    authorization: string | undefined,
    businessId: string,
    dto: {
      subjectOrProduct?: string;
      message: string;
      attachmentUrl?: string;
      preferredContactMethod?: string;
      customerPhoneOrWhatsapp?: string;
    },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const senderProfile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const anyPrisma = this.prisma as Record<string, any>;
    const existing = await anyPrisma.businessDirectoryListing
      ?.findFirst({
        where: {
          OR: [
            ...(businessId.length === 36 ? [{ id: businessId }] : []),
            { businessCode: businessId },
          ],
        },
      })
      .catch(() => null);
    if (!existing) {
      throw new NotFoundException("Business page was not found.");
    }
    const isBusinessOwner =
      String(existing.ownerAccountId ?? "") === session.accountId;
    const listingStatus = String(
      existing.approvalStatus ?? "PENDING_APPROVAL",
    ).toUpperCase();
    if (
      !isBusinessOwner &&
      listingStatus !== "APPROVED" &&
      listingStatus !== "VERIFIED"
    ) {
      throw new NotFoundException("Business page was not found.");
    }

    const nowIso = new Date().toISOString();
    const senderName = senderProfile?.displayName ?? "Sakhi Member";
    const senderHandle = this.deriveUsername(
      senderName,
      senderProfile?.username,
    );
    const subject =
      dto.subjectOrProduct?.trim() || `Enquiry for ${existing.businessName}`;
    const firstMsg = {
      id: randomUUID(),
      senderAccountId: session.accountId,
      senderName,
      senderUsername: senderHandle,
      senderAvatar:
        senderProfile?.profilePhotoRef ?? senderProfile?.avatarAsset ?? null,
      senderRole: "CUSTOMER",
      body: dto.message.trim(),
      preferredContactMethod: dto.preferredContactMethod?.trim() || "IN_APP",
      customerPhoneOrWhatsapp: dto.customerPhoneOrWhatsapp?.trim() || null,
      attachmentUrl: dto.attachmentUrl?.trim() || null,
      createdAt: nowIso,
    };

    const enquiryId = randomUUID();
    const enquiryCode = `#ENQ-${Math.floor(10000 + Math.random() * 90000)}`;

    let createdEnquiry: Record<string, any> = {
      id: enquiryId,
      enquiryCode,
      businessId: existing.id,
      businessName: existing.businessName,
      ownerAccountId: existing.ownerAccountId ?? null,
      senderAccountId: session.accountId,
      senderDisplayName: senderName,
      senderUsername: senderHandle,
      subjectOrProduct: subject,
      status: "OPEN",
      messages: [firstMsg],
      unreadForOwner: true,
      unreadForSender: false,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    if (anyPrisma.businessEnquiry?.create) {
      try {
        const dbRow = await anyPrisma.businessEnquiry.create({
          data: {
            id: enquiryId,
            enquiryCode,
            businessId: existing.id,
            businessName: existing.businessName,
            ownerAccountId: existing.ownerAccountId ?? null,
            senderAccountId: session.accountId,
            senderDisplayName: senderName,
            senderUsername: senderHandle,
            subjectOrProduct: subject,
            status: "OPEN",
            messages: [firstMsg],
            unreadForOwner: true,
            unreadForSender: false,
          },
        });
        createdEnquiry = {
          ...dbRow,
          createdAt: dbRow.createdAt.toISOString(),
          updatedAt: dbRow.updatedAt.toISOString(),
        };
      } catch {
        // Fallback to auditEvent persistence if migration not yet applied
      }
    }

    await anyPrisma.businessDirectoryListing
      .update({
        where: { id: existing.id },
        data: { enquiriesCount: Number(existing.enquiriesCount ?? 0) + 1 },
      })
      .catch(() => undefined);

    await this.prisma.auditEvent
      .create({
        data: {
          actorType: "MEMBER",
          actorId: session.accountId,
          action: "module6.business.enquiry_created",
          targetType: "business_enquiry",
          targetId: enquiryId,
          outcome: "open",
          requestId: randomUUID(),
          redactedMetadata: createdEnquiry,
        },
      })
      .catch(() => undefined);

    return { enquiry: createdEnquiry };
  }

  async listBusinessEnquiries(
    authorization: string | undefined,
    businessId?: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    const items: Array<Record<string, any>> = [];
    const seenIds = new Set<string>();

    if (anyPrisma.businessEnquiry?.findMany) {
      const dbRows = await anyPrisma.businessEnquiry
        .findMany({
          where: {
            OR: [
              { senderAccountId: session.accountId },
              { ownerAccountId: session.accountId },
            ],
          },
          orderBy: { updatedAt: "desc" },
          take: 100,
        })
        .catch(() => []);
      for (const r of dbRows) {
        seenIds.add(String(r.id));
        items.push({
          ...r,
          isOwnerInbox: String(r.ownerAccountId ?? "") === session.accountId,
          createdAt:
            r.createdAt instanceof Date
              ? r.createdAt.toISOString()
              : String(r.createdAt),
          updatedAt:
            r.updatedAt instanceof Date
              ? r.updatedAt.toISOString()
              : String(r.updatedAt),
        });
      }
    }

    if (items.length === 0 && this.prisma.auditEvent?.findMany) {
      const audits = await this.prisma.auditEvent
        .findMany({
          where: { action: "module6.business.enquiry_created" },
          orderBy: { createdAt: "desc" },
          take: 100,
        })
        .catch(() => []);
      for (const a of audits) {
        const meta = a.redactedMetadata as Record<string, any> | null;
        if (
          meta &&
          typeof meta.id === "string" &&
          !seenIds.has(meta.id) &&
          (meta.senderAccountId === session.accountId ||
            meta.ownerAccountId === session.accountId)
        ) {
          seenIds.add(meta.id);
          items.push({
            ...meta,
            isOwnerInbox: meta.ownerAccountId === session.accountId,
          });
        }
      }
    }

    const filteredItems =
      businessId && businessId.trim().length > 0
        ? items.filter((e) => String(e.businessId ?? "") === businessId.trim())
        : items;
    return {
      enquiries: filteredItems,
      items: filteredItems,
      unreadCount: filteredItems.filter((e) =>
        e.isOwnerInbox ? Boolean(e.unreadForOwner) : Boolean(e.unreadForSender),
      ).length,
    };
  }

  async replyBusinessEnquiry(
    authorization: string | undefined,
    enquiryId: string,
    dto: { message: string; status?: string },
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const profile = await this.prisma.memberProfile
      .findUnique({ where: { accountId: session.accountId } })
      .catch(() => null);
    const anyPrisma = this.prisma as Record<string, any>;

    let existing = await anyPrisma.businessEnquiry
      ?.findUnique({ where: { id: enquiryId } })
      .catch(() => null);

    if (!existing) {
      throw new NotFoundException("Business enquiry thread was not found.");
    }

    const isOwner = String(existing.ownerAccountId ?? "") === session.accountId;
    const isSender = String(existing.senderAccountId) === session.accountId;
    if (!isOwner && !isSender) {
      throw new ForbiddenException(
        "Only participants in this enquiry can send messages.",
      );
    }

    if (dto.status !== undefined) {
      const requestedStatus = String(dto.status).toUpperCase();
      if (!isOwner) {
        throw new ForbiddenException(
          "Only the business owner can change an enquiry status.",
        );
      }
      if (!["REPLIED", "RESOLVED", "ARCHIVED"].includes(requestedStatus)) {
        throw new ForbiddenException(
          "The requested enquiry status transition is not permitted.",
        );
      }
    }

    const nowIso = new Date().toISOString();
    const currentMsgs = Array.isArray(existing.messages)
      ? existing.messages
      : [];
    const nextMsg = {
      id: randomUUID(),
      senderAccountId: session.accountId,
      senderName:
        profile?.displayName ?? (isOwner ? "Business Owner" : "Member"),
      senderRole: isOwner ? "BUSINESS_OWNER" : "CUSTOMER",
      body: dto.message.trim(),
      createdAt: nowIso,
    };
    const nextMessages = [...currentMsgs, nextMsg];
    const nextStatus = isOwner
      ? (dto.status ?? "REPLIED")
      : (existing.status ?? "OPEN");

    const updated = await anyPrisma.businessEnquiry.update({
      where: { id: enquiryId },
      data: {
        messages: nextMessages,
        status: nextStatus,
        unreadForOwner: !isOwner,
        unreadForSender: isOwner,
      },
    });

    return {
      enquiry: {
        ...updated,
        isOwnerInbox: isOwner,
        createdAt:
          updated.createdAt instanceof Date
            ? updated.createdAt.toISOString()
            : String(updated.createdAt),
        updatedAt:
          updated.updatedAt instanceof Date
            ? updated.updatedAt.toISOString()
            : String(updated.updatedAt),
      },
    };
  }

  // ===========================================================================
  // MODULE 7: WOMEN'S MENSTRUAL CYCLE TRACKER (SRS Sections 9.1–9.5)
  // Strictly owner-isolated reproductive health service.
  // ===========================================================================

  private static readonly MEDICAL_DISCLAIMER_TEXT =
    "Cycle, ovulation, and fertility predictions are estimates based on your logged history and do not replace professional medical advice or serve as reliable contraception. If you experience severe pain, unusually heavy bleeding, or persistent cycle irregularities, please consult a qualified healthcare professional.";

  private static readonly MENSTRUAL_HEALTH_ARTICLES = [
    {
      id: "period-pain-heat-therapy",
      category: "Period Pain Help",
      title: "Warm Compress & Comfort Care for Period Cramps",
      readTime: "3 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "General Wellness Suggestion • ACOG Patient Education (Dysmenorrhea: Painful Periods)",
      summary:
        "General wellness suggestions for using gentle external warmth to relax abdominal and lower-back tension during menstruation.",
      highlights: [
        "Applying a warm water bottle or heating pad wrapped in a soft cloth to the lower abdomen or lower back for 15–20 minutes can help soothe muscle tightness.",
        "A warm shower or bath offers general relaxation and comfort before rest.",
        "Wellness Notice: Warmth is a general comfort measure, not a medical treatment. Consult a qualified clinician if cramps are severe or interfere with daily activities.",
      ],
    },
    {
      id: "period-pain-gentle-exercise",
      category: "Period Pain Help",
      title: "Gentle Stretching & Restorative Movement on Period Days",
      readTime: "4 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "General Wellness Suggestion • ACOG Exercise & Menstrual Comfort Overview",
      summary:
        "Optional, low-impact stretches and light movement ideas for days when you feel comfortable moving.",
      highlights: [
        "Restorative postures such as Child's Pose (Balasana) or reclining with a pillow under the knees may feel comforting for lower-back tension.",
        "If your energy allows, a short, unhurried walk outdoors can support general circulation and mood.",
        "Always pace movement to how you feel: rest on heavy flow days and stop any activity that causes discomfort or dizziness.",
      ],
    },
    {
      id: "period-pain-hydration-nutrition",
      category: "Period Pain Help",
      title: "Hydration, Warm Fluids & Balanced Meals During Menstruation",
      readTime: "4 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "General Nutrition Guidance • WHO & ICMR-NIN Dietary Guidelines for Women",
      summary:
        "Everyday hydration and dietary habits to support energy and iron intake during your menstrual cycle.",
      highlights: [
        "Sipping warm water or caffeine-free herbal infusions (such as ginger or chamomile) helps maintain daily hydration.",
        "Include iron-containing foods (leafy greens, lentils, dates, ragi) alongside Vitamin C sources (lemon, amla, citrus) as part of a balanced diet.",
        "Reducing very salty snacks and excess caffeine may help you feel more comfortable if you experience premenstrual bloating.",
      ],
    },
    {
      id: "period-pain-rest-relaxation",
      category: "Period Pain Help",
      title: "Restful Sleep Postures & Slow Breathing for Evening Comfort",
      readTime: "3 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "General Wellness Suggestion • Mindfulness & Sleep Hygiene",
      summary:
        "Simple sleep positioning and slow breathing practices to help you unwind on period nights.",
      highlights: [
        "Resting on your side with a pillow between your knees can reduce pressure on the lower back and abdomen.",
        "Practicing 5 minutes of slow, steady breathing before bed supports relaxation.",
        "Allow extra time for sleep and daytime rest whenever your energy feels low.",
      ],
    },
    {
      id: "cycle-phases-guide",
      category: "Cycle Science",
      title: "Understanding Menstrual Cycle Phases (24, 26 & 28+ Day Cycles)",
      readTime: "4 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "Educational Overview • ACOG Your Changing Body & Menstrual Cycle",
      summary:
        "An educational overview of the Menstrual, Follicular, Ovulatory, and Luteal phases across different cycle lengths.",
      highlights: [
        "Adult menstrual cycles commonly range from 21 to 35 days (such as 24, 26, 28, or 32 days) measured from Day 1 of bleeding to the next Day 1.",
        "Menstrual Phase: Uterine lining sheds over 2–7 days; focus on rest, hydration, and balanced meals.",
        "Follicular & Ovulatory Phases: Estrogen rises ahead of ovulation; remember that calendar estimates cannot predict exact ovulation timing.",
        "Luteal Phase: Progesterone rises after ovulation until the next period begins.",
      ],
    },
    {
      id: "irregular-cycles-when-to-see-doctor",
      category: "Clinical Guidance",
      title: "Warning Signs: When to Seek Professional Medical Care",
      readTime: "5 min read",
      reviewedAt: "2026-11-05",
      referenceSource: "Clinical Red-Flag Checklist • ACOG & WHO Reproductive Health Guidance",
      summary:
        "Important symptoms and cycle patterns that should be evaluated promptly by a qualified gynecologist or healthcare provider.",
      highlights: [
        "Cycles consistently shorter than 21 days, longer than 35 days, or varying by more than 7–9 days from month to month.",
        "Heavy bleeding: soaking through one or more pads or tampons every 1–2 hours for two consecutive hours, or bleeding lasting longer than 7 days.",
        "Severe or worsening pelvic pain, pain accompanied by fever, vomiting, fainting, dizziness, or bleeding between periods.",
        "Medical Disclaimer: Sakhi provides personal logging and educational information only and does not diagnose or treat medical conditions.",
      ],
    },
  ];

  private static readonly MENSTRUAL_HEALTH_FAQS = [
    {
      question: "Are cycle and fertility predictions safe to use as contraception?",
      answer:
        "No. Calendar-based ovulation and fertility-window calculations are estimates only. Ovulation can shift early or late due to stress, travel, illness, or hormonal fluctuations, so these estimates must never be used as contraception.",
    },
    {
      question: "Can anyone else on Sakhi or in the Admin Panel see my period logs?",
      answer:
        "Never. Your menstrual cycles, symptoms, flow intensity, and personal notes are strictly isolated to your authenticated account. They are never shown on your profile, never posted to the social wall, and blocked from administrator view.",
    },
    {
      question: "How does discreet notification wording protect my privacy?",
      answer:
        "When Discreet Notifications are enabled (the default), lock-screen reminders use neutral phrasing such as 'Wellness Check-In: You have a personal calendar update waiting in your wellness tracker' so nobody glancing at your phone screen sees health details.",
    },
    {
      question: "How do Automatic Mode and Custom Cycle Length Mode differ?",
      answer:
        "In Automatic Mode (the default), Sakhi calculates your average cycle length from your logged period history once you have at least two completed cycles (falling back to your baseline length until then). In Custom Mode, Sakhi uses your manually selected cycle length (e.g., 24, 26, or 28 days) directly.",
    },
  ];

  private parseDateOnlyUtc(raw: unknown): Date {
    const str = String(raw ?? "").trim();
    const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(str);
    if (match) {
      const y = Number(match[1]);
      const m = Number(match[2]) - 1;
      const d = Number(match[3]);
      return new Date(Date.UTC(y, m, d));
    }
    const parsed = new Date(str);
    if (Number.isNaN(parsed.getTime())) {
      throw new BadRequestException("Provide a valid date in YYYY-MM-DD format.");
    }
    return new Date(
      Date.UTC(parsed.getUTCFullYear(), parsed.getUTCMonth(), parsed.getUTCDate()),
    );
  }

  private formatDateOnlyUtc(date: Date): string {
    return date.toISOString().slice(0, 10);
  }

  private diffDaysUtc(later: Date, earlier: Date): number {
    const msPerDay = 24 * 60 * 60 * 1000;
    const utcLater = Date.UTC(
      later.getUTCFullYear(),
      later.getUTCMonth(),
      later.getUTCDate(),
    );
    const utcEarlier = Date.UTC(
      earlier.getUTCFullYear(),
      earlier.getUTCMonth(),
      earlier.getUTCDate(),
    );
    return Math.round((utcLater - utcEarlier) / msPerDay);
  }

  private addDaysUtc(base: Date, days: number): Date {
    const copy = new Date(
      Date.UTC(base.getUTCFullYear(), base.getUTCMonth(), base.getUTCDate()),
    );
    copy.setUTCDate(copy.getUTCDate() + days);
    return copy;
  }

  calculateMenstrualCyclePredictions(params: {
    lastPeriodStart: Date | null;
    historicalCycleLengths: number[];
    historicalPeriodDurations: number[];
    defaultCycleLength: number;
    defaultPeriodDuration: number;
    useCustomCycleLength?: boolean;
    showFertilityEstimates: boolean;
    discreetNotifications: boolean;
    periodReminderDaysBefore: number;
  }) {
    const validCycles = params.historicalCycleLengths.filter(
      (n) => Number.isFinite(n) && n >= 15 && n <= 60,
    );
    const validDurations = params.historicalPeriodDurations.filter(
      (n) => Number.isFinite(n) && n >= 1 && n <= 15,
    );

    const useCustom = params.useCustomCycleLength === true;
    const avgCycleLength =
      !useCustom && validCycles.length > 0
        ? Math.round(
            validCycles.reduce((acc, v) => acc + v, 0) / validCycles.length,
          )
        : Math.min(Math.max(params.defaultCycleLength || 28, 21), 40);

    const avgPeriodDuration =
      validDurations.length > 0
        ? Math.round(
            validDurations.reduce((acc, v) => acc + v, 0) / validDurations.length,
          )
        : Math.min(Math.max(params.defaultPeriodDuration || 5, 2), 10);

    const predictionBasis = useCustom
      ? `Custom manual cycle length (${avgCycleLength} days)`
      : validCycles.length > 0
        ? `Automatic rolling average from ${validCycles.length} logged cycle interval(s) (${avgCycleLength} days)`
        : `Baseline fallback (${avgCycleLength} days — log at least 2 period start dates for automatic history-based averaging)`;

    let isIrregular = false;
    let irregularityReason =
      "Your logged cycle lengths are within the typical 21–35 day clinical range.";
    if (validCycles.length >= 2) {
      const minC = Math.min(...validCycles);
      const maxC = Math.max(...validCycles);
      if (maxC - minC > 7) {
        isIrregular = true;
        irregularityReason = `Your logged cycle lengths have varied by ${maxC - minC} days (${minC}–${maxC} days). Variations above 7 days are flagged as irregular—consider sharing your exported log with a healthcare professional if this persists.`;
      } else if (avgCycleLength < 21 || avgCycleLength > 35) {
        isIrregular = true;
        irregularityReason = `Your average cycle length (${avgCycleLength} days) falls outside the typical 21–35 day range. Consult a gynecologist if you experience unusual symptoms.`;
      }
    } else if (
      validCycles.length === 1 &&
      (validCycles[0]! < 21 || validCycles[0]! > 35)
    ) {
      isIrregular = true;
      irregularityReason = `Your most recent cycle length (${validCycles[0]} days) is outside the typical 21–35 day window.`;
    }

    const today = this.parseDateOnlyUtc(new Date().toISOString().slice(0, 10));
    const anchorStart = params.lastPeriodStart;

    if (!anchorStart) {
      return {
        hasLoggedCycles: false,
        predictionMode: useCustom ? "CUSTOM" : "AUTOMATIC",
        predictionBasis,
        averageCycleLength: avgCycleLength,
        averagePeriodDuration: avgPeriodDuration,
        lastPeriodStart: null,
        nextPeriodStart: null,
        nextPeriodEnd: null,
        daysUntilNextPeriod: null,
        currentCycleDay: null,
        currentPhase: "Log your last period start date to view estimates",
        phaseDescription:
          "Record your most recent period start date below to unlock cycle phase insights, next period estimates, and symptom tracking.",
        ovulationDate: null,
        fertileWindowStart: null,
        fertileWindowEnd: null,
        pmsStart: null,
        isIrregular: false,
        irregularityReason:
          "Log at least two cycle start dates to track cycle regularity automatically.",
        wellnessSuggestions: [
          "Log your most recent period start date to see personalized cycle phase nutrition and self-care tips.",
          "Use Daily Check-In to record cramps, mood, energy level, and water intake.",
        ],
        reminderPreview: {
          daysBefore: params.periodReminderDaysBefore,
          discreetWording: params.discreetNotifications,
          title: params.discreetNotifications
            ? "Wellness Check-In"
            : "Upcoming Period Reminder",
          body: params.discreetNotifications
            ? "You have a personal calendar update waiting in your wellness tracker."
            : `Your next cycle is estimated to begin in ${params.periodReminderDaysBefore} days.`,
        },
        medicalDisclaimer: Module2Service.MEDICAL_DISCLAIMER_TEXT,
      };
    }

    let projectedStart = this.addDaysUtc(anchorStart, avgCycleLength);
    let currentCycleStart = anchorStart;
    while (this.diffDaysUtc(today, projectedStart) >= avgCycleLength) {
      currentCycleStart = projectedStart;
      projectedStart = this.addDaysUtc(projectedStart, avgCycleLength);
    }

    const nextPeriodStart = projectedStart;
    const nextPeriodEnd = this.addDaysUtc(
      nextPeriodStart,
      Math.max(1, avgPeriodDuration) - 1,
    );
    const ovulationDate = this.addDaysUtc(nextPeriodStart, -14);
    const fertileWindowStart = this.addDaysUtc(ovulationDate, -5);
    const fertileWindowEnd = this.addDaysUtc(ovulationDate, 1);
    const pmsStart = this.addDaysUtc(nextPeriodStart, -5);

    const rawCycleDay = this.diffDaysUtc(today, currentCycleStart) + 1;
    const currentCycleDay = rawCycleDay >= 1 ? rawCycleDay : 1;
    const daysUntilNextPeriod = this.diffDaysUtc(nextPeriodStart, today);

    let currentPhase = "Follicular Phase";
    let phaseDescription =
      "Rising energy and focus. Great days for balanced movement, protein-rich meals, and planning ahead.";
    let wellnessSuggestions = [
      "Include iron- and protein-rich foods like lentils, leafy greens, and nuts.",
      "Light cardio or strength routines pair well with follicular-phase energy.",
      "Aim for 8 glasses of water and 7–8 hours of sleep.",
    ];

    if (currentCycleDay <= avgPeriodDuration) {
      currentPhase = "Menstrual Phase";
      phaseDescription =
        "Restorative shedding phase. Prioritize warmth, gentle stretching, iron replenishment, and extra rest.";
      wellnessSuggestions = [
        "Pair iron-rich greens or dates with vitamin C (lemon/amla) to support iron intake.",
        "Use a warm compress or gentle pelvic stretches for general comfort.",
        "Honor lower energy levels with earlier rest and calming herbal tea.",
      ];
    } else if (
      this.diffDaysUtc(today, fertileWindowStart) >= 0 &&
      this.diffDaysUtc(fertileWindowEnd, today) >= 0
    ) {
      currentPhase = "Ovulation Window (Estimate)";
      phaseDescription =
        "Mid-cycle window estimate. Stay hydrated and balanced.";
      wellnessSuggestions = [
        "Maintain steady hydration with water or coconut water.",
        "Include fiber-rich vegetables and fruits in daily meals.",
        "Remember: calendar fertility windows are mathematical estimates only and never reliable contraception.",
      ];
    } else if (this.diffDaysUtc(today, pmsStart) >= 0) {
      currentPhase = "Luteal & PMS Care Phase";
      phaseDescription =
        "Winding down toward your next cycle. Focus on balanced complex carbs and rest.";
      wellnessSuggestions = [
        "Complex carbohydrates (oats, sweet potato, brown rice) support steady daytime energy.",
        "Reduce excess salt and caffeine to ease pre-period bloating.",
        "Practice 5 minutes of slow breathing before bed for evening relaxation.",
      ];
    }

    return {
      hasLoggedCycles: true,
      predictionMode: useCustom ? "CUSTOM" : "AUTOMATIC",
      predictionBasis,
      averageCycleLength: avgCycleLength,
      averagePeriodDuration: avgPeriodDuration,
      lastPeriodStart: this.formatDateOnlyUtc(anchorStart),
      nextPeriodStart: this.formatDateOnlyUtc(nextPeriodStart),
      nextPeriodEnd: this.formatDateOnlyUtc(nextPeriodEnd),
      daysUntilNextPeriod,
      currentCycleDay,
      currentPhase,
      phaseDescription,
      ovulationDate: params.showFertilityEstimates
        ? this.formatDateOnlyUtc(ovulationDate)
        : null,
      fertileWindowStart: params.showFertilityEstimates
        ? this.formatDateOnlyUtc(fertileWindowStart)
        : null,
      fertileWindowEnd: params.showFertilityEstimates
        ? this.formatDateOnlyUtc(fertileWindowEnd)
        : null,
      pmsStart: this.formatDateOnlyUtc(pmsStart),
      isIrregular,
      irregularityReason,
      wellnessSuggestions,
      reminderPreview: {
        daysBefore: params.periodReminderDaysBefore,
        discreetWording: params.discreetNotifications,
        scheduledForDate: this.formatDateOnlyUtc(
          this.addDaysUtc(nextPeriodStart, -params.periodReminderDaysBefore),
        ),
        title: params.discreetNotifications
          ? "Wellness Check-In"
          : "Upcoming Period Reminder",
        body: params.discreetNotifications
          ? "You have a personal calendar update waiting in your wellness tracker."
          : `Your next period is estimated to begin around ${this.formatDateOnlyUtc(nextPeriodStart)}.`,
      },
      medicalDisclaimer: Module2Service.MEDICAL_DISCLAIMER_TEXT,
    };
  }

  async calculateMenstrualCycleStateless(query: {
    lastPeriod?: string;
    cycleLength?: number;
    periodLength?: number;
  }) {
    const lastPeriodDate = query.lastPeriod
      ? this.parseDateOnlyUtc(query.lastPeriod)
      : this.parseDateOnlyUtc(new Date().toISOString().slice(0, 10));
    const cycleLen = Math.min(Math.max(Number(query.cycleLength) || 28, 21), 40);
    const periodLen = Math.min(Math.max(Number(query.periodLength) || 5, 2), 10);

    const summary = this.calculateMenstrualCyclePredictions({
      lastPeriodStart: lastPeriodDate,
      historicalCycleLengths: [cycleLen],
      historicalPeriodDurations: [periodLen],
      defaultCycleLength: cycleLen,
      defaultPeriodDuration: periodLen,
      useCustomCycleLength: false,
      showFertilityEstimates: true,
      discreetNotifications: true,
      periodReminderDaysBefore: 2,
    });

    return {
      status: "ok" as const,
      provider: "sakhi_on_device_and_stateless_engine",
      data: summary,
      medicalDisclaimer: Module2Service.MEDICAL_DISCLAIMER_TEXT,
    };
  }

  private async recalculateUserCycleHistory(accountId: string): Promise<void> {
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.menstrualCycleLog?.findMany !== "function") return;
    try {
      const logs = (await anyPrisma.menstrualCycleLog.findMany({
        where: { accountId },
        orderBy: { startDate: "asc" },
      })) as Array<Record<string, any>>;

      for (let i = 0; i < logs.length; i++) {
        const current = logs[i]!;
        const start =
          current.startDate instanceof Date
            ? current.startDate
            : this.parseDateOnlyUtc(current.startDate);
        const end = current.endDate
          ? current.endDate instanceof Date
            ? current.endDate
            : this.parseDateOnlyUtc(current.endDate)
          : null;
        const durationDays = end
          ? Math.max(1, Math.min(15, this.diffDaysUtc(end, start) + 1))
          : (current.periodDurationDays ?? 5);

        let cycleLengthDays: number | null = null;
        let isIrregular = false;
        if (i + 1 < logs.length) {
          const next = logs[i + 1]!;
          const nextStart =
            next.startDate instanceof Date
              ? next.startDate
              : this.parseDateOnlyUtc(next.startDate);
          const diff = this.diffDaysUtc(nextStart, start);
          if (diff >= 12 && diff <= 90) {
            cycleLengthDays = diff;
            isIrregular = diff < 21 || diff > 35;
          }
        }
        await anyPrisma.menstrualCycleLog
          .update({
            where: { id: current.id },
            data: {
              periodDurationDays: durationDays,
              cycleLengthDays,
              isIrregular,
            },
          })
          .catch(() => undefined);
      }
    } catch {
      // Best-effort history recalculation
    }
  }

  async getMenstrualCycleTracker(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;

    let rawCycles: Array<Record<string, any>> = [];
    let rawDailyLogs: Array<Record<string, any>> = [];
    let rawPref: Record<string, any> | null = null;

    if (typeof anyPrisma.menstrualCycleLog?.findMany === "function") {
      const [cRows, dRows, pRow] = await Promise.all([
        anyPrisma.menstrualCycleLog
          .findMany({
            where: { accountId: session.accountId },
            orderBy: { startDate: "desc" },
            take: 36,
          })
          .catch(() => []),
        anyPrisma.menstrualDailyLog
          ?.findMany({
            where: { accountId: session.accountId },
            orderBy: { logDate: "desc" },
            take: 90,
          })
          .catch(() => []) ?? Promise.resolve([]),
        anyPrisma.menstrualTrackerPreference
          ?.findUnique({
            where: { accountId: session.accountId },
          })
          .catch(() => null) ?? Promise.resolve(null),
      ]);
      rawCycles = cRows as Array<Record<string, any>>;
      rawDailyLogs = dRows as Array<Record<string, any>>;
      rawPref = pRow as Record<string, any> | null;
    }

    const preferences = {
      defaultCycleLength: Number(rawPref?.defaultCycleLength ?? 28),
      averageCycleLength: Number(rawPref?.defaultCycleLength ?? 28),
      defaultPeriodDuration: Number(rawPref?.defaultPeriodDuration ?? 5),
      averagePeriodDuration: Number(rawPref?.defaultPeriodDuration ?? 5),
      useCustomCycleLength: Boolean(rawPref?.useCustomCycleLength ?? false),
      discreetNotifications: rawPref?.discreetNotifications ?? true,
      periodReminderEnabled: rawPref?.periodReminderEnabled ?? true,
      periodReminderDaysBefore: Number(rawPref?.periodReminderDaysBefore ?? 2),
      ovulationReminderEnabled: rawPref?.ovulationReminderEnabled ?? false,
      hydrationReminderEnabled: rawPref?.hydrationReminderEnabled ?? true,
      selfCareReminderEnabled: rawPref?.selfCareReminderEnabled ?? true,
      showFertilityEstimates: rawPref?.showFertilityEstimates ?? true,
      medicalDisclaimerAcceptedAt:
        rawPref?.medicalDisclaimerAcceptedAt instanceof Date
          ? rawPref.medicalDisclaimerAcceptedAt.toISOString()
          : (rawPref?.medicalDisclaimerAcceptedAt ?? null),
    };

    const cycleLogs = rawCycles.map((c) => {
      const start =
        c.startDate instanceof Date
          ? this.formatDateOnlyUtc(c.startDate)
          : String(c.startDate).slice(0, 10);
      const end = c.endDate
        ? c.endDate instanceof Date
          ? this.formatDateOnlyUtc(c.endDate)
          : String(c.endDate).slice(0, 10)
        : null;
      return {
        id: String(c.id),
        startDate: start,
        endDate: end,
        cycleLengthDays:
          typeof c.cycleLengthDays === "number" ? c.cycleLengthDays : null,
        periodDurationDays:
          typeof c.periodDurationDays === "number"
            ? c.periodDurationDays
            : preferences.defaultPeriodDuration,
        flowIntensity: String(c.flowIntensity ?? "MEDIUM"),
        symptoms: Array.isArray(c.symptoms)
          ? c.symptoms.map((s: unknown) => String(s))
          : [],
        mood: c.mood ? String(c.mood) : null,
        energyLevel: typeof c.energyLevel === "number" ? c.energyLevel : null,
        crampsSeverity: c.crampsSeverity ? String(c.crampsSeverity) : "NONE",
        notes: c.notesEncrypted ? String(c.notesEncrypted) : "",
        isIrregular: Boolean(c.isIrregular),
        createdAt:
          c.createdAt instanceof Date
            ? c.createdAt.toISOString()
            : String(c.createdAt ?? new Date().toISOString()),
      };
    });

    const dailyLogs = rawDailyLogs.map((d) => {
      const logDate =
        d.logDate instanceof Date
          ? this.formatDateOnlyUtc(d.logDate)
          : String(d.logDate).slice(0, 10);
      return {
        id: String(d.id),
        logDate,
        flowIntensity: d.flowIntensity ? String(d.flowIntensity) : null,
        crampsSeverity: String(d.crampsSeverity ?? "NONE"),
        mood: d.mood ? String(d.mood) : null,
        energyLevel: typeof d.energyLevel === "number" ? d.energyLevel : 3,
        symptoms: Array.isArray(d.symptoms)
          ? d.symptoms.map((s: unknown) => String(s))
          : [],
        hydrationGlasses:
          typeof d.hydrationGlasses === "number" ? d.hydrationGlasses : 0,
        sleepHours: typeof d.sleepHours === "number" ? d.sleepHours : null,
        notes: d.notesEncrypted ? String(d.notesEncrypted) : "",
      };
    });

    const sortedAsc = [...cycleLogs].sort((a, b) =>
      a.startDate.localeCompare(b.startDate),
    );
    const historicalCycleLengths: number[] = [];
    const historicalPeriodDurations: number[] = [];
    for (let i = 0; i < sortedAsc.length; i++) {
      const item = sortedAsc[i]!;
      if (
        typeof item.periodDurationDays === "number" &&
        item.periodDurationDays >= 1 &&
        item.periodDurationDays <= 15
      ) {
        historicalPeriodDurations.push(item.periodDurationDays);
      }
      if (i + 1 < sortedAsc.length) {
        const curDate = this.parseDateOnlyUtc(item.startDate);
        const nxtDate = this.parseDateOnlyUtc(sortedAsc[i + 1]!.startDate);
        const diff = this.diffDaysUtc(nxtDate, curDate);
        if (diff >= 15 && diff <= 60) {
          historicalCycleLengths.push(diff);
        }
      } else if (
        typeof item.cycleLengthDays === "number" &&
        item.cycleLengthDays >= 15 &&
        item.cycleLengthDays <= 60
      ) {
        historicalCycleLengths.push(item.cycleLengthDays);
      }
    }

    const latestCycleStart =
      cycleLogs.length > 0
        ? this.parseDateOnlyUtc(cycleLogs[0]!.startDate)
        : null;

    const predictionSummary = this.calculateMenstrualCyclePredictions({
      lastPeriodStart: latestCycleStart,
      historicalCycleLengths,
      historicalPeriodDurations,
      defaultCycleLength: preferences.defaultCycleLength,
      defaultPeriodDuration: preferences.defaultPeriodDuration,
      useCustomCycleLength: preferences.useCustomCycleLength,
      showFertilityEstimates: preferences.showFertilityEstimates,
      discreetNotifications: preferences.discreetNotifications,
      periodReminderDaysBefore: preferences.periodReminderDaysBefore,
    });

    return {
      source: "postgresql_live" as const,
      privacyIsolation: {
        ownerAccountId: session.accountId,
        hiddenFromPublicProfile: true,
        hiddenFromSocialWall: true,
        adminAccessBlocked: true,
        adAnalyticsBlocked: true,
        encryptedInTransitAndAtRest: true,
      },
      preferences,
      predictionSummary,
      cycleLogs,
      cycles: cycleLogs,
      dailyLogs,
      articles: Module2Service.MENSTRUAL_HEALTH_ARTICLES,
      faqs: Module2Service.MENSTRUAL_HEALTH_FAQS,
      medicalDisclaimer: Module2Service.MEDICAL_DISCLAIMER_TEXT,
    };
  }

  async upsertMenstrualCycleLog(
    authorization: string | undefined,
    dto: Record<string, unknown>,
    cycleId?: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const startDate = this.parseDateOnlyUtc(dto.startDate);
    const endDate =
      typeof dto.endDate === "string" && dto.endDate.trim().length > 0
        ? this.parseDateOnlyUtc(dto.endDate)
        : null;

    if (endDate && this.diffDaysUtc(endDate, startDate) < 0) {
      throw new BadRequestException(
        "Period end date cannot be earlier than the period start date.",
      );
    }

    const periodDurationDays = endDate
      ? Math.max(1, Math.min(15, this.diffDaysUtc(endDate, startDate) + 1))
      : Math.max(1, Math.min(15, Number(dto.periodDurationDays) || 5));

    const flowRaw = String(dto.flowIntensity ?? "MEDIUM")
      .trim()
      .toUpperCase();
    const flowIntensity = ["SPOTTING", "LIGHT", "MEDIUM", "HEAVY"].includes(
      flowRaw,
    )
      ? flowRaw
      : "MEDIUM";

    const crampsRaw = String(dto.crampsSeverity ?? "NONE")
      .trim()
      .toUpperCase();
    const crampsSeverity = ["NONE", "MILD", "MODERATE", "SEVERE"].includes(
      crampsRaw,
    )
      ? crampsRaw
      : "NONE";

    const symptoms = Array.isArray(dto.symptoms)
      ? dto.symptoms
          .map((s) => String(s).trim())
          .filter((s) => s.length > 0 && s.length <= 60)
      : [];

    const mood =
      typeof dto.mood === "string" && dto.mood.trim().length > 0
        ? dto.mood.trim().slice(0, 40)
        : null;
    const energyLevel =
      typeof dto.energyLevel === "number"
        ? Math.min(Math.max(Math.round(dto.energyLevel), 1), 5)
        : null;
    const notesEncrypted =
      typeof dto.notes === "string" && dto.notes.trim().length > 0
        ? dto.notes.trim().slice(0, 1000)
        : null;

    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.menstrualCycleLog?.create !== "function") {
      throw new ServiceUnavailableException(
        "Menstrual cycle database table is not initialized yet. Run the Module 7 migration.",
      );
    }

    if (cycleId && cycleId.trim().length > 0) {
      const existing = await anyPrisma.menstrualCycleLog.findFirst({
        where: { id: cycleId.trim(), accountId: session.accountId },
      });
      if (!existing) {
        throw new NotFoundException("Cycle record was not found in your account.");
      }
      await anyPrisma.menstrualCycleLog.update({
        where: { id: existing.id },
        data: {
          startDate,
          endDate,
          periodDurationDays,
          flowIntensity,
          crampsSeverity,
          symptoms,
          mood,
          energyLevel,
          notesEncrypted,
        },
      });
    } else {
      await anyPrisma.menstrualCycleLog.create({
        data: {
          id: randomUUID(),
          accountId: session.accountId,
          startDate,
          endDate,
          periodDurationDays,
          flowIntensity,
          crampsSeverity,
          symptoms,
          mood,
          energyLevel,
          notesEncrypted,
        },
      });
    }

    await this.recalculateUserCycleHistory(session.accountId);
    return this.getMenstrualCycleTracker(authorization);
  }

  async deleteMenstrualCycleLog(
    authorization: string | undefined,
    cycleId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.menstrualCycleLog?.deleteMany === "function") {
      await anyPrisma.menstrualCycleLog.deleteMany({
        where: { id: cycleId.trim(), accountId: session.accountId },
      });
      await this.recalculateUserCycleHistory(session.accountId);
    }
    return this.getMenstrualCycleTracker(authorization);
  }

  async upsertMenstrualDailyLog(
    authorization: string | undefined,
    dto: Record<string, unknown>,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const logDate = this.parseDateOnlyUtc(
      dto.logDate ?? new Date().toISOString().slice(0, 10),
    );
    const flowRaw =
      typeof dto.flowIntensity === "string" && dto.flowIntensity.trim().length > 0
        ? dto.flowIntensity.trim().toUpperCase()
        : null;
    const flowIntensity =
      flowRaw && ["NONE", "SPOTTING", "LIGHT", "MEDIUM", "HEAVY"].includes(flowRaw)
        ? flowRaw
        : null;

    const crampsRaw = String(dto.crampsSeverity ?? "NONE")
      .trim()
      .toUpperCase();
    const crampsSeverity = ["NONE", "MILD", "MODERATE", "SEVERE"].includes(
      crampsRaw,
    )
      ? crampsRaw
      : "NONE";

    const mood =
      typeof dto.mood === "string" && dto.mood.trim().length > 0
        ? dto.mood.trim().slice(0, 40)
        : null;
    const energyLevel =
      typeof dto.energyLevel === "number"
        ? Math.min(Math.max(Math.round(dto.energyLevel), 1), 5)
        : 3;
    const hydrationGlasses =
      typeof dto.hydrationGlasses === "number"
        ? Math.min(Math.max(Math.round(dto.hydrationGlasses), 0), 24)
        : 0;
    const sleepHours =
      typeof dto.sleepHours === "number"
        ? Math.min(Math.max(Number(dto.sleepHours), 0), 24)
        : null;
    const symptoms = Array.isArray(dto.symptoms)
      ? dto.symptoms
          .map((s) => String(s).trim())
          .filter((s) => s.length > 0 && s.length <= 60)
      : [];
    const notesText = dto.notes ?? dto.personalNotes;
    const notesEncrypted =
      typeof notesText === "string" && notesText.trim().length > 0
        ? notesText.trim().slice(0, 1000)
        : null;

    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.menstrualDailyLog?.upsert === "function") {
      await anyPrisma.menstrualDailyLog.upsert({
        where: {
          accountId_logDate: {
            accountId: session.accountId,
            logDate,
          },
        },
        create: {
          id: randomUUID(),
          accountId: session.accountId,
          logDate,
          flowIntensity,
          crampsSeverity,
          mood,
          energyLevel,
          symptoms,
          hydrationGlasses,
          sleepHours,
          notesEncrypted,
        },
        update: {
          flowIntensity,
          crampsSeverity,
          mood,
          energyLevel,
          symptoms,
          hydrationGlasses,
          sleepHours,
          notesEncrypted,
        },
      });
    }

    return this.getMenstrualCycleTracker(authorization);
  }

  async deleteMenstrualDailyLog(
    authorization: string | undefined,
    logId: string,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (typeof anyPrisma.menstrualDailyLog?.deleteMany === "function") {
      await anyPrisma.menstrualDailyLog.deleteMany({
        where: { id: logId.trim(), accountId: session.accountId },
      });
    }
    return this.getMenstrualCycleTracker(authorization);
  }

  async updateMenstrualTrackerPreferences(
    authorization: string | undefined,
    dto: Record<string, unknown>,
  ) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;

    const rawCycleLen = dto.defaultCycleLength ?? dto.averageCycleLength;
    const defaultCycleLength =
      typeof rawCycleLen === "number" && Number.isFinite(rawCycleLen)
        ? Math.min(Math.max(Math.round(rawCycleLen), 21), 40)
        : undefined;
    const rawPeriodLen =
      dto.defaultPeriodDuration ??
      dto.averagePeriodDuration ??
      dto.averagePeriodLength;
    const defaultPeriodDuration =
      typeof rawPeriodLen === "number" && Number.isFinite(rawPeriodLen)
        ? Math.min(Math.max(Math.round(rawPeriodLen), 2), 10)
        : undefined;
    const rawRemDays = dto.periodReminderDaysBefore ?? dto.reminderDaysBefore;
    const periodReminderDaysBefore =
      typeof rawRemDays === "number" && Number.isFinite(rawRemDays)
        ? Math.min(Math.max(Math.round(rawRemDays), 1), 7)
        : undefined;
    const useCustomCycleLength =
      typeof dto.useCustomCycleLength === "boolean"
        ? dto.useCustomCycleLength
        : undefined;

    if (typeof anyPrisma.menstrualTrackerPreference?.upsert === "function") {
      const baseCreate: Record<string, any> = {
        accountId: session.accountId,
        defaultCycleLength: defaultCycleLength ?? 28,
        defaultPeriodDuration: defaultPeriodDuration ?? 5,
        discreetNotifications:
          typeof dto.discreetNotifications === "boolean"
            ? dto.discreetNotifications
            : true,
        periodReminderEnabled:
          typeof dto.periodReminderEnabled === "boolean"
            ? dto.periodReminderEnabled
            : typeof dto.notificationsEnabled === "boolean"
              ? dto.notificationsEnabled
              : true,
        periodReminderDaysBefore: periodReminderDaysBefore ?? 2,
        ovulationReminderEnabled:
          typeof dto.ovulationReminderEnabled === "boolean"
            ? dto.ovulationReminderEnabled
            : false,
        hydrationReminderEnabled:
          typeof dto.hydrationReminderEnabled === "boolean"
            ? dto.hydrationReminderEnabled
            : true,
        selfCareReminderEnabled:
          typeof dto.selfCareReminderEnabled === "boolean"
            ? dto.selfCareReminderEnabled
            : true,
        showFertilityEstimates:
          typeof dto.showFertilityEstimates === "boolean"
            ? dto.showFertilityEstimates
            : typeof dto.fertilityTrackingEnabled === "boolean"
              ? dto.fertilityTrackingEnabled
              : true,
        medicalDisclaimerAcceptedAt:
          dto.acceptMedicalDisclaimer === true ? new Date() : null,
      };
      const baseUpdate: Record<string, any> = {
        ...(defaultCycleLength !== undefined ? { defaultCycleLength } : {}),
        ...(defaultPeriodDuration !== undefined
          ? { defaultPeriodDuration }
          : {}),
        ...(typeof dto.discreetNotifications === "boolean"
          ? { discreetNotifications: dto.discreetNotifications }
          : {}),
        ...(typeof dto.periodReminderEnabled === "boolean"
          ? { periodReminderEnabled: dto.periodReminderEnabled }
          : typeof dto.notificationsEnabled === "boolean"
            ? { periodReminderEnabled: dto.notificationsEnabled }
            : {}),
        ...(periodReminderDaysBefore !== undefined
          ? { periodReminderDaysBefore }
          : {}),
        ...(typeof dto.ovulationReminderEnabled === "boolean"
          ? { ovulationReminderEnabled: dto.ovulationReminderEnabled }
          : {}),
        ...(typeof dto.hydrationReminderEnabled === "boolean"
          ? { hydrationReminderEnabled: dto.hydrationReminderEnabled }
          : {}),
        ...(typeof dto.selfCareReminderEnabled === "boolean"
          ? { selfCareReminderEnabled: dto.selfCareReminderEnabled }
          : {}),
        ...(typeof dto.showFertilityEstimates === "boolean"
          ? { showFertilityEstimates: dto.showFertilityEstimates }
          : typeof dto.fertilityTrackingEnabled === "boolean"
            ? { showFertilityEstimates: dto.fertilityTrackingEnabled }
            : {}),
        ...(dto.acceptMedicalDisclaimer === true
          ? { medicalDisclaimerAcceptedAt: new Date() }
          : {}),
      };

      try {
        await anyPrisma.menstrualTrackerPreference.upsert({
          where: { accountId: session.accountId },
          create: {
            ...baseCreate,
            useCustomCycleLength: useCustomCycleLength ?? false,
          },
          update: {
            ...baseUpdate,
            ...(useCustomCycleLength !== undefined
              ? { useCustomCycleLength }
              : {}),
          },
        });
      } catch {
        await anyPrisma.menstrualTrackerPreference.upsert({
          where: { accountId: session.accountId },
          create: baseCreate,
          update: baseUpdate,
        });
      }
    }

    return this.getMenstrualCycleTracker(authorization);
  }

  async exportMenstrualTrackerData(authorization: string | undefined) {
    const tracker = await this.getMenstrualCycleTracker(authorization);
    const pred = tracker.predictionSummary;
    const lines: string[] = [
      "SAKHI WOMEN'S WELLNESS — PERSONAL MENSTRUAL CYCLE & SYMPTOM REPORT",
      `Generated At: ${new Date().toISOString()}`,
      "Privacy Notice: Strictly confidential personal health export for the account owner / consulting healthcare provider.",
      "",
      "--- CYCLE SUMMARY & ESTIMATES ---",
      `Prediction Mode: ${pred.predictionMode} (${pred.predictionBasis})`,
      `Average Cycle Length: ${pred.averageCycleLength} days`,
      `Average Period Duration: ${pred.averagePeriodDuration} days`,
      `Last Period Start: ${pred.lastPeriodStart ?? "Not logged"}`,
      `Estimated Next Period: ${pred.nextPeriodStart ?? "N/A"} to ${pred.nextPeriodEnd ?? "N/A"}`,
      `Cycle Regularity Status: ${pred.isIrregular ? "IRREGULAR FLAGGED" : "REGULAR (21–35 day norm)"}`,
      `Clinical Note: ${pred.irregularityReason}`,
      "",
      "--- LOGGED MENSTRUAL CYCLES ---",
    ];

    if (tracker.cycleLogs.length === 0) {
      lines.push("No menstrual cycle entries recorded.");
    } else {
      for (const c of tracker.cycleLogs) {
        lines.push(
          `• Start: ${c.startDate} | End: ${c.endDate ?? "Ongoing"} | Duration: ${c.periodDurationDays}d | Cycle Length: ${c.cycleLengthDays ? `${c.cycleLengthDays}d` : "Current"} | Flow: ${c.flowIntensity} | Cramps: ${c.crampsSeverity} | Symptoms: ${c.symptoms.join(", ") || "None"}${c.notes ? ` | Notes: ${c.notes}` : ""}`,
        );
      }
    }

    lines.push("", "--- RECENT DAILY SYMPTOM & WELLNESS LOGS ---");
    if (tracker.dailyLogs.length === 0) {
      lines.push("No daily symptom check-ins recorded.");
    } else {
      for (const d of tracker.dailyLogs) {
        lines.push(
          `• Date: ${d.logDate} | Flow: ${d.flowIntensity ?? "None"} | Cramps: ${d.crampsSeverity} | Mood: ${d.mood ?? "-"} | Energy: ${d.energyLevel}/5 | Water: ${d.hydrationGlasses} glasses | Symptoms: ${d.symptoms.join(", ") || "None"}${d.notes ? ` | Notes: ${d.notes}` : ""}`,
        );
      }
    }

    lines.push("", `Medical Disclaimer: ${tracker.medicalDisclaimer}`);

    return {
      exportedAt: new Date().toISOString(),
      clinicalSummaryText: lines.join("\n"),
      data: {
        preferences: tracker.preferences,
        predictionSummary: tracker.predictionSummary,
        cycleLogs: tracker.cycleLogs,
        dailyLogs: tracker.dailyLogs,
        medicalDisclaimer: tracker.medicalDisclaimer,
      },
    };
  }

  async deleteAllMenstrualTrackerData(authorization: string | undefined) {
    const session = await this.auth.authenticateAuthorization(authorization);
    const anyPrisma = this.prisma as Record<string, any>;
    if (
      typeof anyPrisma.menstrualCycleLog?.deleteMany !== "function" ||
      typeof anyPrisma.menstrualDailyLog?.deleteMany !== "function" ||
      typeof anyPrisma.menstrualTrackerPreference?.deleteMany !== "function"
    ) {
      throw new ServiceUnavailableException(
        "Menstrual tracker database tables are not initialized.",
      );
    }

    let deletedCycles = 0;
    let deletedDailyLogs = 0;
    let deletedPreferences = 0;

    if (typeof anyPrisma.$transaction === "function") {
      const [cRes, dRes, pRes] = await anyPrisma.$transaction([
        anyPrisma.menstrualCycleLog.deleteMany({
          where: { accountId: session.accountId },
        }),
        anyPrisma.menstrualDailyLog.deleteMany({
          where: { accountId: session.accountId },
        }),
        anyPrisma.menstrualTrackerPreference.deleteMany({
          where: { accountId: session.accountId },
        }),
      ]);
      deletedCycles = Number(cRes?.count ?? 0);
      deletedDailyLogs = Number(dRes?.count ?? 0);
      deletedPreferences = Number(pRes?.count ?? 0);
    } else {
      const [cRes, dRes, pRes] = await Promise.all([
        anyPrisma.menstrualCycleLog.deleteMany({
          where: { accountId: session.accountId },
        }),
        anyPrisma.menstrualDailyLog.deleteMany({
          where: { accountId: session.accountId },
        }),
        anyPrisma.menstrualTrackerPreference.deleteMany({
          where: { accountId: session.accountId },
        }),
      ]);
      deletedCycles = Number(cRes?.count ?? 0);
      deletedDailyLogs = Number(dRes?.count ?? 0);
      deletedPreferences = Number(pRes?.count ?? 0);
    }

    return {
      deleted: true,
      deletedCounts: {
        cycleLogs: deletedCycles,
        dailyLogs: deletedDailyLogs,
        preferences: deletedPreferences,
      },
      message:
        "All personal menstrual cycle logs, daily symptoms, and tracker preferences have been permanently deleted.",
      tracker: await this.getMenstrualCycleTracker(authorization),
    };
  }
}
