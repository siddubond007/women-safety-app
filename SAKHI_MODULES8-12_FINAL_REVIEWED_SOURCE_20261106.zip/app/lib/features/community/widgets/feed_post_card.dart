import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/constants/mock_data.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/sakhi_avatar.dart';
import '../../../core/widgets/sakhi_botanical_flower.dart';
import '../../../core/widgets/sakhi_buttons.dart';
import '../../../core/widgets/sakhi_card.dart';
import '../../../core/widgets/sakhi_dialogs.dart';
import '../../../core/widgets/sakhi_remote_media_image.dart';
import '../../../core/widgets/sakhi_remote_media_video.dart';
import '../../complaints/screens/discreet_complaint_hub_screen.dart';
import '../../explore/screens/explore_discovery_screens.dart';
import 'breathing_exercise_banner.dart';

/// Module 3 Social Wall Post Card supporting:
/// - Working "+ Follow" / "Following" toggle button
/// - Compact animated bouncing emoji reaction stack (scalable to 10,000+ reactions)
/// - Continuous hold-and-drag 360° Reaction Wheel (selects on finger slide & release without lifting first)
/// - Up to 5 inline preview comments + Instagram/Facebook-style Draggable Comments Sheet with @username replies
class FeedPostCard extends StatefulWidget {
  final FeedPostModel post;
  final Future<bool> Function() onLikeTap;
  final Future<bool> Function() onSaveTap;
  final bool showVerifiedCheck;

  const FeedPostCard({
    super.key,
    required this.post,
    required this.onLikeTap,
    required this.onSaveTap,
    this.showVerifiedCheck = false,
  });

  static const Map<String, Map<String, String>> _reactions = {
    'LOVE': {'emoji': '❤️', 'label': 'Love'},
    'SUPPORT': {'emoji': '🌸', 'label': 'Support'},
    'SOLIDARITY': {'emoji': '🤝', 'label': 'Solidarity'},
    'HAHA': {'emoji': '😂', 'label': 'Haha'},
    'CRYING': {'emoji': '😢', 'label': 'Crying'},
    'FIERCE': {'emoji': '🔥', 'label': 'Fierce'},
    'GRATEFUL': {'emoji': '🙏', 'label': 'Grateful'},
    'APPLAUD': {'emoji': '👏', 'label': 'Applaud'},
    'LIKE': {'emoji': '❤️', 'label': 'Love'},
    'INSPIRED': {'emoji': '✨', 'label': 'Inspired'},
    'HAPPY': {'emoji': '😊', 'label': 'Happy'},
    'STRONG': {'emoji': '💪', 'label': 'Strong'},
    'CARE': {'emoji': '🌸', 'label': 'Care'},
  };

  static const List<Map<String, String>> _wheelReactions = [
    {'key': 'LOVE', 'emoji': '❤️', 'label': 'Love', 'fx': 'Pulse Heart'},
    {'key': 'SUPPORT', 'emoji': '🌸', 'label': 'Support', 'fx': 'Lotus Bloom'},
    {
      'key': 'SOLIDARITY',
      'emoji': '🤝',
      'label': 'Solidarity',
      'fx': 'Sisterhood',
    },
    {'key': 'HAHA', 'emoji': '😂', 'label': 'Haha', 'fx': 'Joy Burst'},
    {'key': 'CRYING', 'emoji': '😢', 'label': 'Crying', 'fx': 'Empathy Tear'},
    {'key': 'FIERCE', 'emoji': '🔥', 'label': 'Fierce', 'fx': 'Power Flame'},
    {'key': 'GRATEFUL', 'emoji': '🙏', 'label': 'Grateful', 'fx': 'Warmth'},
    {'key': 'APPLAUD', 'emoji': '👏', 'label': 'Applaud', 'fx': 'Ovation'},
  ];

  @override
  State<FeedPostCard> createState() => _FeedPostCardState();
}

class _FeedPostCardState extends State<FeedPostCard> {
  final ValueNotifier<Offset?> _dragGlobalPosition = ValueNotifier<Offset?>(
    null,
  );
  final ValueNotifier<int> _dragReleaseSignal = ValueNotifier<int>(0);
  bool _wheelDialogOpen = false;
  bool _togglingFollow = false;
  int _activeMediaIndex = 0;

  FeedPostModel get post => widget.post;

  @override
  void initState() {
    super.initState();
    _syncCommentsIfNeeded();
  }

  @override
  void didUpdateWidget(covariant FeedPostCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.post.id != widget.post.id) {
      _syncCommentsIfNeeded();
    }
  }

  void _syncCommentsIfNeeded() {
    if (post.comments.isEmpty && post.commentsCount > 0) {
      unawaited(SakhiPrototypeState.instance.loadComments(post.id, post));
    }
  }

  @override
  void dispose() {
    _dragGlobalPosition.dispose();
    _dragReleaseSignal.dispose();
    super.dispose();
  }

  bool _isRemoteUrl(String path) =>
      path.startsWith('http://') ||
      path.startsWith('https://') ||
      path.startsWith('/api/v1/');

  double _aspectRatioForPreset(String preset) {
    switch (preset) {
      case '1:1':
        return 1.0;
      case '16:9':
        return 16 / 9;
      case '4:5':
      default:
        return 4 / 5;
    }
  }

  Future<void> _handleFollowToggle() async {
    if (_togglingFollow) return;
    setState(() => _togglingFollow = true);
    HapticFeedback.lightImpact();
    final state = SakhiPrototypeState.instance;
    final wasFollowing = state.isFollowingAuthor(post);
    await state.toggleFollowPostAuthor(post);
    if (!mounted) return;
    setState(() => _togglingFollow = false);
    final nowFollowing = state.isFollowingAuthor(post);
    if (wasFollowing != nowFollowing) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            duration: const Duration(milliseconds: 1400),
            content: Text(
              nowFollowing
                  ? 'Following ${post.authorName}'
                  : 'Unfollowed ${post.authorName}',
            ),
          ),
        );
    }
  }

  void _startContinuousReactionWheel(
    BuildContext context,
    Offset initialGlobalPosition,
  ) {
    if (_wheelDialogOpen) return;
    _dragGlobalPosition.value = initialGlobalPosition;
    _showReactionPickerSheet(context, startedFromHold: true);
  }

  void _updateContinuousReactionWheel(Offset globalPosition) {
    if (_wheelDialogOpen) {
      _dragGlobalPosition.value = globalPosition;
    }
  }

  void _endContinuousReactionWheel() {
    if (_wheelDialogOpen) {
      _dragReleaseSignal.value++;
    }
  }

  (IconData, String, Color, List<Color>) _resolvePostIntentPill({
    required bool isQuestion,
    required bool isResource,
  }) {
    if (isQuestion) {
      return (
        Icons.help_outline_rounded,
        'Community Question \u2022 Advice Welcome',
        AppColors.primaryPurple,
        const [Color(0xFFF3E4FA), Color(0xFFFFEAF2)],
      );
    }
    if (isResource) {
      return (
        Icons.menu_book_rounded,
        'Verified Resource \u2022 Community Guide',
        const Color(0xFF0F766E),
        const [Color(0xFFE6FFFA), Color(0xFFF0FDF4)],
      );
    }
    final slug = post.categorySlug.trim().toLowerCase();
    final badge = (post.categoryBadge ?? '').trim();
    final badgeLower = badge.toLowerCase();
    if (slug == 'safety_awareness' || badgeLower.contains('safety')) {
      return (
        Icons.shield_outlined,
        badge.isNotEmpty && badgeLower != 'safety_awareness'
            ? '$badge \u2022 Safety Alert'
            : 'Safety Awareness \u2022 Verified Alert',
        const Color(0xFFB91C1C),
        const [Color(0xFFFFF1F2), Color(0xFFFFE4E6)],
      );
    }
    if (slug == 'business_updates' ||
        badgeLower.contains('business') ||
        post.shareToBusinessProfile) {
      return (
        Icons.storefront_rounded,
        badge.isNotEmpty && badgeLower != 'business_updates'
            ? '$badge \u2022 Women-Owned'
            : 'Business Updates \u2022 Women-Owned Spotlight',
        const Color(0xFF7B228E),
        const [Color(0xFFFDF4FF), Color(0xFFFAE8FF)],
      );
    }
    if (slug == 'wellness_lifestyle' || badgeLower.contains('wellness')) {
      return (
        Icons.spa_outlined,
        badge.isNotEmpty && badgeLower != 'wellness_lifestyle'
            ? badge.replaceAll('Wellness and Lifestyle', 'Wellness & Lifestyle')
            : 'Wellness & Lifestyle \u2022 Mindful Care',
        const Color(0xFF15803D),
        const [Color(0xFFF0FDF4), Color(0xFFDCFCE7)],
      );
    }
    if (slug == 'trending' || badgeLower.contains('trending')) {
      return (
        Icons.trending_up_rounded,
        'Trending \u2022 Sisterhood Highlight',
        const Color(0xFFC2410C),
        const [Color(0xFFFFF7ED), Color(0xFFFFEDD5)],
      );
    }
    final cleanBadge = badge.isEmpty || badgeLower == 'community'
        ? 'Community Update \u2022 Sisterhood Wall'
        : badge;
    return (
      Icons.auto_awesome_rounded,
      cleanBadge,
      AppColors.primaryPurple,
      const [Color(0xFFF5ECFA), Color(0xFFFDF2F8)],
    );
  }

  Widget _buildFormattedPostContent(BuildContext context, String rawContent) {
    var body = rawContent.trim();
    // Clean any accidental legacy mojibake stored in older DB posts
    body = body
        .replaceAll('â€œ', '\u201c')
        .replaceAll('â€\u009d', '\u201d')
        .replaceAll('â€”', '\u2014')
        .replaceAll('â€¢', '\u2022')
        .replaceAll('âœ¨', '\u{2728}')
        .replaceAll('ðŸŒ¸', '\u{1F338}');

    var isCommunityQuestion = false;
    var isResourcePost = false;
    if (body.startsWith('Community Question\n')) {
      isCommunityQuestion = true;
      body = body.substring('Community Question\n'.length).trim();
    } else if (body.startsWith('Community Question:')) {
      isCommunityQuestion = true;
      body = body.substring('Community Question:'.length).trim();
    } else if (body.startsWith('\u2753 Question:')) {
      isCommunityQuestion = true;
      body = body.substring('\u2753 Question:'.length).trim();
    } else if (body.startsWith('Question:')) {
      isCommunityQuestion = true;
      body = body.substring('Question:'.length).trim();
    } else if (body.startsWith('\u{1F4D8} Resource')) {
      isResourcePost = true;
    } else if (post.hashtags.any((h) => h.toLowerCase().contains('question')) ||
        (post.categoryBadge?.toLowerCase().contains('question') ?? false)) {
      isCommunityQuestion = true;
    } else if (post.hashtags.any((h) => h.toLowerCase().contains('resource')) ||
        (post.categoryBadge?.toLowerCase().contains('resource') ?? false)) {
      isResourcePost = true;
    }

    String? resourceUrl;
    final resourceLineMatch = RegExp(
      r'\n?(?:Resource|(?:\u{1F517}\s*)?Contact / Link):\s*(https?://\S+)',
      caseSensitive: false,
    ).firstMatch(body);
    if (resourceLineMatch != null) {
      resourceUrl = resourceLineMatch.group(1)?.trim();
      body = body.replaceRange(
        resourceLineMatch.start,
        resourceLineMatch.end,
        '',
      ).trim();
    } else {
      final anyUrlMatch = RegExp(r'(https?://\S+)').firstMatch(body);
      if (anyUrlMatch != null) {
        resourceUrl = anyUrlMatch.group(1)?.trim();
      }
    }

    final (pillIcon, pillLabel, pillColor, pillGradient) =
        _resolvePostIntentPill(
          isQuestion: isCommunityQuestion,
          isResource: isResourcePost || resourceUrl != null,
        );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: pillGradient),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: pillColor.withValues(alpha: 0.28),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                pillIcon,
                size: 14,
                color: pillColor,
              ),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  pillLabel,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.caption.copyWith(
                    color: pillColor,
                    fontWeight: FontWeight.w800,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
        if (body.isNotEmpty)
          Text(
            body,
            style: isCommunityQuestion
                ? AppTypography.bodyMedium.copyWith(
                    fontSize: 14.5,
                    color: AppColors.textPrimary,
                    height: 1.4,
                  )
                : AppTypography.bodyRegular,
          ),
        if (resourceUrl != null && resourceUrl.isNotEmpty) ...[
          const SizedBox(height: 9),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () async {
              final uri = Uri.tryParse(resourceUrl!);
              if (uri != null) {
                try {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } catch (_) {}
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppColors.primaryPurple.withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppColors.pastelLavender,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.link_rounded,
                      size: 16,
                      color: AppColors.primaryPurple,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Shared Community Resource',
                          style: AppTypography.caption.copyWith(
                            fontWeight: FontWeight.w800,
                            color: AppColors.primaryPurple,
                            fontSize: 11,
                          ),
                        ),
                        Text(
                          resourceUrl,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.subtitle.copyWith(
                            fontSize: 11.5,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.open_in_new_rounded,
                    size: 15,
                    color: AppColors.primaryPurple,
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = SakhiPrototypeState.instance;
    final activeReaction = post.viewerReaction != null
        ? FeedPostCard._reactions[post.viewerReaction!]
        : null;
    final isOwn =
        post.isOwnPost ||
        (post.authorAccountId.isNotEmpty &&
            post.authorAccountId == state.currentUser.accountId) ||
        (post.authorUsername.isNotEmpty &&
            post.authorUsername.toLowerCase() ==
                state.currentUser.username.toLowerCase());
    final isFollowing = !isOwn && state.isFollowingAuthor(post);

    // Top 4 active reaction emojis sorted by count for compact bouncing stack
    final sortedReactionEntries = post.reactionBreakdown.entries
        .where((e) => e.value > 0)
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topEmojis = <String>[];
    for (final entry in sortedReactionEntries) {
      final emoji = FeedPostCard._reactions[entry.key]?['emoji'] ?? '❤️';
      if (!topEmojis.contains(emoji)) {
        topEmojis.add(emoji);
      }
      if (topEmojis.length >= 4) break;
    }
    if (topEmojis.isEmpty && post.likesCount > 0) {
      topEmojis.add(activeReaction?['emoji'] ?? '❤️');
    }

    return SakhiCard(
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        child: Stack(
          children: [
            const Positioned(
              right: -12,
              top: -14,
              child: SakhiBotanicalFlower(
                type: SakhiFlowerType.babysBreath,
                width: 62,
                height: 76,
                opacity: 0.25,
                angle: -0.25,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      SakhiAvatar(
                        imageAsset: post.authorAvatar,
                        fallbackLabel: post.authorName,
                        size: 44,
                        onAvatarTap: () => _openAuthorProfile(context),
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(4),
                                    onTap: () => _openAuthorProfile(context),
                                    child: Text(
                                      post.authorName,
                                      style: AppTypography.cardTitle.copyWith(
                                        color: AppColors.textPrimary,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                                if (widget.showVerifiedCheck ||
                                    post.authorVerified) ...[
                                  const SizedBox(width: 4),
                                  const Icon(
                                    Icons.verified_rounded,
                                    size: 16,
                                    color: AppColors.primaryPurple,
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text(
                              [
                                post.timestamp,
                                if (post.locationTag != null &&
                                    post.locationTag!.isNotEmpty)
                                  post.locationTag!,
                                if (post.visibility == 'FOLLOWERS_ONLY')
                                  'Followers Only',
                                if (post.visibility == 'PRIVATE_SELF')
                                  'Only Me',
                              ].join(' • '),
                              style: AppTypography.subtitle,
                            ),
                          ],
                        ),
                      ),
                      if (post.categoryBadge != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.pastelLavender,
                            borderRadius: BorderRadius.circular(
                              AppSpacing.radiusPill,
                            ),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.85),
                            ),
                          ),
                          child: Text(
                            post.categoryBadge!,
                            style: AppTypography.subtitle.copyWith(
                              color: AppColors.primaryPurple,
                              fontWeight: FontWeight.w700,
                              fontSize: 11,
                            ),
                          ),
                        ),
                      if (!isOwn) ...[
                        const SizedBox(width: 6),
                        Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(
                              AppSpacing.radiusPill,
                            ),
                            onTap: _handleFollowToggle,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4.5,
                              ),
                              decoration: BoxDecoration(
                                color: isFollowing
                                    ? AppColors.primaryPurple.withValues(
                                        alpha: 0.12,
                                      )
                                    : const Color(0xFFFFEAF2),
                                borderRadius: BorderRadius.circular(
                                  AppSpacing.radiusPill,
                                ),
                                border: Border.all(
                                  color: isFollowing
                                      ? AppColors.primaryPurple.withValues(
                                          alpha: 0.35,
                                        )
                                      : const Color(0xFFE5BDD1),
                                ),
                              ),
                              child: Text(
                                isFollowing ? 'Following' : '+ Follow',
                                style: AppTypography.subtitle.copyWith(
                                  color: AppColors.primaryPurple,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                      IconButton(
                        icon: const Icon(
                          Icons.more_horiz_rounded,
                          color: AppColors.textMuted,
                        ),
                        onPressed: () => _showPostOptionsSheet(context),
                      ),
                    ],
                  ),

                  const SizedBox(height: 11),
                  _buildFormattedPostContent(context, post.content),

                  if (post.hashtags.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: post.hashtags.map((tag) {
                        final normalized = tag.startsWith('#') ? tag : '#$tag';
                        return InkWell(
                          borderRadius: BorderRadius.circular(6),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) =>
                                  SearchResultsScreen(initialQuery: normalized),
                            ),
                          ),
                          child: Text(
                            normalized,
                            style: AppTypography.subtitle.copyWith(
                              color: AppColors.primaryPurple,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],

                  if (post.pollOptions.length >= 2) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.78),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppColors.primaryPurple.withValues(alpha: 0.2),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.poll_outlined,
                                size: 16,
                                color: AppColors.primaryPurple,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Community Poll • Tap an option to vote',
                                style: AppTypography.caption.copyWith(
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.primaryPurple,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          for (int i = 0; i < post.pollOptions.length; i++) ...[
                            Builder(
                              builder: (context) {
                                final counts =
                                    post.pollVoteCounts.length ==
                                        post.pollOptions.length
                                    ? post.pollVoteCounts
                                    : List<int>.filled(
                                        post.pollOptions.length,
                                        0,
                                      );
                                final totalVotes = counts.fold<int>(
                                  0,
                                  (a, b) => a + b,
                                );
                                final count = counts[i];
                                final pct = totalVotes > 0
                                    ? (count / totalVotes)
                                    : 0.0;
                                final isSelected = post.viewerPollChoice == i;
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 7),
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(12),
                                    onTap: () async {
                                      HapticFeedback.selectionClick();
                                      await state.voteOnPoll(post, i);
                                      if (mounted) setState(() {});
                                    },
                                    child: Stack(
                                      children: [
                                        Container(
                                          height: 38,
                                          decoration: BoxDecoration(
                                            color: AppColors.pastelLavender
                                                .withValues(alpha: 0.38),
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            border: Border.all(
                                              color: isSelected
                                                  ? AppColors.primaryPurple
                                                  : AppColors.borderSubtle,
                                              width: isSelected ? 1.5 : 1.0,
                                            ),
                                          ),
                                        ),
                                        FractionallySizedBox(
                                          widthFactor: pct.clamp(0.04, 1.0),
                                          child: Container(
                                            height: 38,
                                            decoration: BoxDecoration(
                                              color: AppColors.primaryPurple
                                                  .withValues(
                                                    alpha: isSelected
                                                        ? 0.25
                                                        : 0.14,
                                                  ),
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 38,
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 12,
                                          ),
                                          alignment: Alignment.centerLeft,
                                          child: Row(
                                            children: [
                                              if (isSelected) ...[
                                                const Icon(
                                                  Icons.check_circle_rounded,
                                                  size: 15,
                                                  color:
                                                      AppColors.primaryPurple,
                                                ),
                                                const SizedBox(width: 6),
                                              ],
                                              Expanded(
                                                child: Text(
                                                  post.pollOptions[i],
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    fontSize: 12.5,
                                                    fontWeight: isSelected
                                                        ? FontWeight.w800
                                                        : FontWeight.w600,
                                                    color:
                                                        AppColors.textPrimary,
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                '${(pct * 100).round()}% ($count)',
                                                style: const TextStyle(
                                                  fontSize: 11.5,
                                                  fontWeight: FontWeight.w800,
                                                  color:
                                                      AppColors.primaryPurple,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],

                  if (post.mediaItems.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () => _showMediaViewer(context),
                      onDoubleTap: () => _handleLikeTap(context),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(
                          AppSpacing.radiusMd,
                        ),
                        child: Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                            color: Color(0xFF1E0D26),
                          ),
                          child: (post.mediaContentType == 'video/mp4' ||
                                  post.mediaItems.first
                                      .toLowerCase()
                                      .endsWith('.mp4'))
                              ? AspectRatio(
                                  aspectRatio: 16 / 9,
                                  child: _buildSingleMediaWidget(
                                    post.mediaItems.first,
                                  ),
                                )
                              : post.mediaItems.length == 1
                              ? ConstrainedBox(
                                  constraints: const BoxConstraints(
                                    minHeight: 180,
                                    maxHeight: 560,
                                  ),
                                  child: _buildSingleMediaWidget(
                                    post.mediaItems.first,
                                    naturalFit: true,
                                  ),
                                )
                              : AspectRatio(
                                  aspectRatio: _aspectRatioForPreset(
                                    post.cropPreset,
                                  ),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      PageView.builder(
                                        itemCount: post.mediaItems.length,
                                        onPageChanged: (idx) => setState(
                                          () => _activeMediaIndex = idx,
                                        ),
                                        itemBuilder: (context, idx) =>
                                            _buildSingleMediaWidget(
                                              post.mediaItems[idx],
                                              naturalFit: true,
                                            ),
                                      ),
                                      Positioned(
                                        top: 10,
                                        right: 10,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 10,
                                            vertical: 4,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withValues(
                                              alpha: 0.65,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(999),
                                          ),
                                          child: Text(
                                            '${(_activeMediaIndex + 1).clamp(1, post.mediaItems.length)}/${post.mediaItems.length}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ],

                  if (post.hasBreathingExerciseCard) ...[
                    const SizedBox(height: 12),
                    const BreathingExerciseBanner(),
                  ],

                  // Compact Animated Bouncing Emoji Stack (never overflows even with 1,000+ reactions)
                  if (topEmojis.isNotEmpty && post.likesCount > 0) ...[
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () =>
                          _showReactionPickerSheet(context, startedFromHold: false),
                      child: _SakhiBouncingReactionBadges(
                        emojis: topEmojis,
                        totalReactions: post.likesCount,
                      ),
                    ),
                  ],

                  const SizedBox(height: 10),
                  Row(
                    children: [
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => _handleLikeTap(context),
                        onLongPressStart: (details) =>
                            _startContinuousReactionWheel(
                              context,
                              details.globalPosition,
                            ),
                        onLongPressMoveUpdate: (details) =>
                            _updateContinuousReactionWheel(
                              details.globalPosition,
                            ),
                        onLongPressEnd: (_) => _endContinuousReactionWheel(),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 4,
                          ),
                          child: Row(
                            children: [
                              if (activeReaction != null)
                                Text(
                                  activeReaction['emoji']!,
                                  style: const TextStyle(fontSize: 18),
                                )
                              else
                                Icon(
                                  post.isLiked
                                      ? Icons.favorite_rounded
                                      : Icons.favorite_border_rounded,
                                  color: post.isLiked
                                      ? AppColors.heartPink
                                      : AppColors.primaryPurple,
                                  size: 21,
                                ),
                              const SizedBox(width: 5),
                              Text(
                                '${post.likesCount}',
                                style: AppTypography.subtitle.copyWith(
                                  color: AppColors.textPrimary,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => _showReactionPickerSheet(
                          context,
                          startedFromHold: false,
                        ),
                        onLongPressStart: (details) =>
                            _startContinuousReactionWheel(
                              context,
                              details.globalPosition,
                            ),
                        onLongPressMoveUpdate: (details) =>
                            _updateContinuousReactionWheel(
                              details.globalPosition,
                            ),
                        onLongPressEnd: (_) => _endContinuousReactionWheel(),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.pastelLavender.withValues(
                              alpha: 0.72,
                            ),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.9),
                            ),
                          ),
                          child: Text(
                            'React +',
                            style: AppTypography.subtitle.copyWith(
                              color: AppColors.primaryPurple,
                              fontWeight: FontWeight.w800,
                              fontSize: 11.5,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      InkWell(
                        onTap: () => _showCommentsSheet(context),
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 4,
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.chat_bubble_outline_rounded,
                                color: AppColors.primaryPurple,
                                size: 20,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                '${post.comments.isNotEmpty ? post.comments.length : post.commentsCount}',
                                style: AppTypography.subtitle.copyWith(
                                  color: AppColors.textPrimary,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        tooltip: 'Share post',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(
                          Icons.share_outlined,
                          color: AppColors.primaryPurple,
                          size: 20,
                        ),
                        onPressed: () => _sharePost(context),
                      ),
                      IconButton(
                        tooltip: post.isSaved
                            ? 'Remove saved post'
                            : 'Save post',
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          post.isSaved
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          color: AppColors.primaryPurple,
                          size: 21,
                        ),
                        onPressed: () => _handleSaveTap(context),
                      ),
                      const Spacer(),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(
                          Icons.more_horiz_rounded,
                          color: AppColors.primaryPurple,
                          size: 20,
                        ),
                        onPressed: () => _showPostOptionsSheet(context),
                      ),
                    ],
                  ),

                  // Inline Preview: Up to 5 Recent Comments (Instagram / Facebook style)
                  if (post.comments.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: () => _showCommentsSheet(context),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 9,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.pastelLavender.withValues(
                            alpha: 0.48,
                          ),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.85),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final c in post.comments.reversed.take(5).toList().reversed)
                              Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  text: TextSpan(
                                    style: AppTypography.bodyRegular.copyWith(
                                      fontSize: 12.5,
                                      color: AppColors.textPrimary,
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '${c.authorName} ',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: AppColors.primaryPurple,
                                        ),
                                      ),
                                      if (c.replyToHandle != null &&
                                          c.replyToHandle!.isNotEmpty)
                                        TextSpan(
                                          text: '${c.replyToHandle!.startsWith('@') ? c.replyToHandle! : '@${c.replyToHandle!}'} ',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w700,
                                            color: Color(0xFF8B2E9D),
                                          ),
                                        ),
                                      TextSpan(
                                        text: _stripDuplicateReplyPrefix(
                                          c.body,
                                          c.replyToHandle,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            if (post.comments.length > 5)
                              Padding(
                                padding: const EdgeInsets.only(top: 3),
                                child: Text(
                                  'View all ${post.comments.length} comments',
                                  style: AppTypography.subtitle.copyWith(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.primaryPurple,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],

                  if (post.allowComments) ...[
                    const SizedBox(height: 9),
                    InkWell(
                      borderRadius: BorderRadius.circular(999),
                      onTap: () =>
                          _showCommentsSheet(context, autoFocusInput: true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8.5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.84),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.95),
                            width: 1.2,
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.add_comment_outlined,
                              size: 16,
                              color: AppColors.primaryPurple,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Write a supportive comment…',
                                style: AppTypography.subtitle.copyWith(
                                  fontSize: 12,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ),
                            const Text(
                              'Reply',
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w800,
                                color: AppColors.primaryPurple,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openAuthorProfile(BuildContext context) async {
    final state = SakhiPrototypeState.instance;
    final username = post.authorUsername.trim();
    final normalized = username.replaceFirst(RegExp(r'^@'), '').toLowerCase();
    FollowerUserModel? member;

    for (final candidate in state.followers) {
      if (post.authorAccountId.isNotEmpty &&
          candidate.id == post.authorAccountId) {
        member = candidate;
        break;
      }
      if (normalized.isNotEmpty &&
          candidate.username.replaceFirst(RegExp(r'^@'), '').toLowerCase() ==
              normalized) {
        member = candidate;
        break;
      }
    }

    if (member == null && username.isNotEmpty) {
      final members = await state.searchVisibleMembers(username);
      if (!context.mounted) return;
      if (members != null) {
        for (final candidate in members) {
          if (post.authorAccountId.isNotEmpty &&
              candidate.id == post.authorAccountId) {
            member = candidate;
            break;
          }
          if (candidate.username
                  .replaceFirst(RegExp(r'^@'), '')
                  .toLowerCase() ==
              normalized) {
            member = candidate;
            break;
          }
        }
      }
    }

    member ??= FollowerUserModel(
      id: post.authorAccountId,
      name: post.authorName,
      username: username.isNotEmpty
          ? (username.startsWith('@') ? username : '@$username')
          : '@sakhi_member',
      location: post.locationTag ?? 'India',
      avatarAsset: post.authorAvatar,
      isFollowing: state.isFollowingAuthor(post),
      isVerified: post.authorVerified,
      canFollow: post.authorAccountId.isNotEmpty &&
          post.authorAccountId != state.currentUser.accountId,
    );

    if (!context.mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SearchResultMemberProfileScreen(member: member!),
      ),
    );
  }

  Future<void> _handleLikeTap(BuildContext context) async {
    final succeeded = await widget.onLikeTap();
    if (!context.mounted || succeeded) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Your reaction was not saved. Check your connection and retry.',
        ),
      ),
    );
  }

  Future<void> _handleSaveTap(BuildContext context) async {
    final succeeded = await widget.onSaveTap();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          succeeded
              ? (post.isSaved
                    ? 'Added to Saved Posts.'
                    : 'Removed from Saved Posts.')
              : 'Saved posts could not be updated. No change was kept.',
        ),
      ),
    );
  }

  Future<void> _sharePost(BuildContext context) async {
    final hashtags = post.hashtags
        .map((tag) => tag.startsWith('#') ? tag : '#$tag')
        .join(' ');
    final text = [
      post.content.trim(),
      if (hashtags.isNotEmpty) hashtags,
      '— ${post.authorName} (${post.authorUsername}) on Sakhi',
    ].where((part) => part.isNotEmpty).join('\n\n');
    try {
      await SharePlus.instance.share(
        ShareParams(text: text, subject: 'Sakhi community post'),
      );
    } catch (_) {
      await Clipboard.setData(ClipboardData(text: text));
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Post text copied. A share sheet was not available.'),
          ),
        );
      }
    }
  }

  void _showMediaViewer(BuildContext context) {
    final source = post.imageAsset?.trim() ?? '';
    if (source.isEmpty) return;
    final size = MediaQuery.sizeOf(context);
    final isVideo = post.mediaContentType == 'video/mp4';
    showDialog<void>(
      context: context,
      barrierColor: Colors.black,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: SizedBox(
          width: size.width,
          height: size.height * 0.94,
          child: Stack(
            children: [
              Positioned.fill(
                child: Center(
                  child: InteractiveViewer(
                    minScale: 1,
                    maxScale: 4,
                    child: SizedBox(
                      width: size.width,
                      height: size.height * 0.78,
                      child: isVideo
                          ? SakhiRemoteMediaVideo(
                              source: source,
                              fit: BoxFit.contain,
                            )
                          : _isRemoteUrl(source)
                          ? SakhiRemoteMediaImage(
                              source: source,
                              width: size.width,
                              height: size.height * 0.78,
                              fit: BoxFit.contain,
                              errorBuilder: (_, _, _) => const Center(
                                child: Text(
                                  'Media could not be loaded.',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            )
                          : Image.asset(
                              source,
                              fit: BoxFit.contain,
                              errorBuilder: (_, _, _) => const Center(
                                child: Text(
                                  'Media could not be loaded.',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: SafeArea(
                  child: IconButton(
                    tooltip: 'Close media viewer',
                    onPressed: () => Navigator.of(dialogContext).pop(),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.black54,
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ),
              ),
              if (!isVideo)
                Positioned(
                  bottom: 18,
                  left: 16,
                  right: 16,
                  child: SafeArea(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.of(dialogContext).pop();
                        _handleLikeTap(context);
                      },
                      icon: const Icon(Icons.favorite_border_rounded),
                      label: const Text('Like this post'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white70),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImageFallback() {
    return Container(
      color: AppColors.pastelPink,
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.broken_image_outlined,
              color: AppColors.primaryPurple,
              size: 32,
            ),
            SizedBox(height: 4),
            Text('Media unavailable right now', style: AppTypography.subtitle),
          ],
        ),
      ),
    );
  }

  void _showReactionPickerSheet(
    BuildContext context, {
    required bool startedFromHold,
  }) {
    if (_wheelDialogOpen) return;
    _wheelDialogOpen = true;
    HapticFeedback.mediumImpact();
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Close reaction wheel',
      barrierColor: Colors.black.withValues(alpha: 0.36),
      transitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (dialogContext, anim1, anim2) {
        return _SakhiRadialReactionWheelDialog(
          post: post,
          reactions: FeedPostCard._wheelReactions,
          externalDragGlobalPosition: _dragGlobalPosition,
          externalDragReleaseSignal: _dragReleaseSignal,
          startedFromHold: startedFromHold,
          onSelectReaction: (reactionKey, emoji, label) async {
            HapticFeedback.lightImpact();
            await SakhiPrototypeState.instance.reactToPost(post, reactionKey);
          },
        );
      },
      transitionBuilder: (ctx, anim, _, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: curved, child: child),
        );
      },
    ).whenComplete(() {
      _wheelDialogOpen = false;
      _dragGlobalPosition.value = null;
    });
  }

  String _stripDuplicateReplyPrefix(String body, String? replyHandle) {
    final trimmed = body.trim();
    if (replyHandle == null || replyHandle.trim().isEmpty) return trimmed;
    final norm = replyHandle.trim().startsWith('@')
        ? replyHandle.trim()
        : '@${replyHandle.trim()}';
    if (trimmed.toLowerCase().startsWith('${norm.toLowerCase()} ')) {
      final rest = trimmed.substring(norm.length).trim();
      if (rest.isNotEmpty) return rest;
    }
    return trimmed;
  }

  Widget _buildSingleMediaWidget(String mediaSource, {bool naturalFit = false}) {
    final isVideo =
        post.mediaContentType == 'video/mp4' ||
        mediaSource.toLowerCase().endsWith('.mp4');
    if (isVideo) {
      return SakhiRemoteMediaVideo(source: mediaSource, fit: BoxFit.contain);
    }
    final imageFit = naturalFit ? BoxFit.contain : BoxFit.cover;
    if (_isRemoteUrl(mediaSource)) {
      return SakhiRemoteMediaImage(
        source: mediaSource,
        width: double.infinity,
        fit: imageFit,
        errorBuilder: (_, _, _) => _buildImageFallback(),
      );
    }
    return Image.asset(
      mediaSource,
      width: double.infinity,
      fit: imageFit,
      filterQuality: FilterQuality.high,
      isAntiAlias: true,
      errorBuilder: (_, _, _) => _buildImageFallback(),
    );
  }

  void _showCommentsSheet(BuildContext context, {bool autoFocusInput = false}) {
    final state = SakhiPrototypeState.instance;
    unawaited(state.loadComments(post.id, post));
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _SakhiInstagramCommentsSheet(
        post: post,
        autoFocusInput: autoFocusInput,
      ),
    );
  }

  void _showEditPostDialog(BuildContext context) {
    final controller = TextEditingController(text: post.content);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardSurface,
        title: const Text('Edit Your Post', style: AppTypography.sectionTitle),
        content: TextField(
          controller: controller,
          maxLines: 4,
          decoration: const InputDecoration(hintText: 'Update your post...'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          SakhiPillButton(
            label: 'Save Changes',
            onPressed: () async {
              final updated = await SakhiPrototypeState.instance.updatePost(
                post,
                content: controller.text,
              );
              if (!ctx.mounted) return;
              if (!updated) {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Post could not be updated. No change was made.',
                    ),
                  ),
                );
                return;
              }
              Navigator.pop(ctx);
              SakhiDialogs.showPrototypeSnackbar(
                context,
                'Your post was updated.',
              );
            },
          ),
        ],
      ),
    );
  }

  void _showReportDialog(BuildContext context) {
    const reasons = [
      'Harassment or bullying',
      'Fake account or impersonation',
      'Inappropriate or unsafe content',
      'Spam or scam',
      'Hate speech or discrimination',
      'Other safety concern',
    ];
    var selected = reasons.first;
    var alsoBlockAuthor = false;
    final detailsCtrl = TextEditingController();

    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: AppColors.cardSurface,
          title: const Text('Report Post', style: AppTypography.sectionTitle),
          content: SingleChildScrollView(
            child: RadioGroup<String>(
              groupValue: selected,
              onChanged: (value) {
                if (value != null) {
                  setDialogState(() => selected = value);
                }
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Confidential: Your identity is never disclosed to the reported member, and this post will be hidden from your feed immediately.',
                    style: AppTypography.subtitle,
                  ),
                  const SizedBox(height: 8),
                  ...reasons.map(
                    (r) => RadioListTile<String>(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      value: r,
                      activeColor: AppColors.primaryPurple,
                      title: Text(r, style: AppTypography.bodyRegular),
                    ),
                  ),
                  TextField(
                    controller: detailsCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Additional details (optional)',
                    ),
                  ),
                  const SizedBox(height: 8),
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    activeColor: AppColors.sosRed,
                    value: alsoBlockAuthor,
                    onChanged: (val) =>
                        setDialogState(() => alsoBlockAuthor = val ?? false),
                    title: Text(
                      'Also block ${post.authorName} (${post.authorUsername})',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: AppColors.sosRed,
                      ),
                    ),
                    subtitle: const Text(
                      'Hide all posts, comments, profile views, and messages from this member',
                      style: TextStyle(fontSize: 11.5),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            SakhiPillButton(
              label: alsoBlockAuthor ? 'Report & Block' : 'Submit Report',
              backgroundColor: AppColors.sosRed,
              onPressed: () async {
                final submitted = await SakhiPrototypeState.instance
                    .reportUserOrPost(
                      targetHandle: post.authorUsername,
                      postId: post.id,
                      category: selected.toLowerCase().replaceAll(' ', '_'),
                      reason: selected,
                      details: detailsCtrl.text,
                      alsoBlockUser: alsoBlockAuthor,
                      authorDisplayName: post.authorName,
                    );
                if (!ctx.mounted) return;
                if (!submitted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'The report was not submitted. Check your connection and retry.',
                      ),
                    ),
                  );
                  return;
                }
                Navigator.pop(ctx);
                SakhiDialogs.showPrototypeSnackbar(
                  context,
                  alsoBlockAuthor
                      ? 'Post reported and ${post.authorUsername} blocked.'
                      : 'Post reported and removed from your feed.',
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showPostOptionsSheet(BuildContext context) {
    final isOwn =
        post.isOwnPost ||
        post.authorUsername ==
            SakhiPrototypeState.instance.currentUser.username;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.cardSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isOwn) ...[
                ListTile(
                  leading: const Icon(
                    Icons.edit_outlined,
                    color: AppColors.primaryPurple,
                  ),
                  title: const Text('Edit Post'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _showEditPostDialog(context);
                  },
                ),
                ListTile(
                  leading: const Icon(
                    Icons.delete_outline_rounded,
                    color: AppColors.sosRed,
                  ),
                  title: const Text(
                    'Delete Post',
                    style: TextStyle(color: AppColors.sosRed),
                  ),
                  onTap: () async {
                    Navigator.pop(ctx);
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (dialogContext) => AlertDialog(
                        title: const Text('Delete this post?'),
                        content: const Text(
                          'This removes the post from the Social Wall. This action cannot be undone.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () =>
                                Navigator.pop(dialogContext, false),
                            child: const Text('Cancel'),
                          ),
                          FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: AppColors.sosRed,
                            ),
                            onPressed: () => Navigator.pop(dialogContext, true),
                            child: const Text('Delete Post'),
                          ),
                        ],
                      ),
                    );
                    if (confirmed != true || !context.mounted) return;
                    final deleted = await SakhiPrototypeState.instance
                        .deletePost(post.id);
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          deleted
                              ? 'Your post was deleted.'
                              : 'The post could not be deleted. No change was made.',
                        ),
                      ),
                    );
                  },
                ),
              ],
              ListTile(
                leading: const Icon(
                  Icons.bookmark_border_rounded,
                  color: AppColors.primaryPurple,
                ),
                title: Text(
                  post.isSaved ? 'Remove from Saved Posts' : 'Save Post',
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  widget.onSaveTap();
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.share_outlined,
                  color: AppColors.primaryPurple,
                ),
                title: const Text('Share Post'),
                subtitle: const Text(
                  'Open the device share sheet or copy the post text.',
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  _sharePost(context);
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.visibility_off_outlined,
                  color: AppColors.primaryPurple,
                ),
                title: const Text('Hide Post from Feed'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await SakhiPrototypeState.instance.toggleHidePost(post.id);
                  if (!context.mounted) return;
                  SakhiDialogs.showPrototypeSnackbar(
                    context,
                    'Post hidden from your Social Wall view.',
                  );
                },
              ),
              if (!isOwn)
                ListTile(
                  leading: const Icon(
                    Icons.volume_off_outlined,
                    color: AppColors.primaryPurple,
                  ),
                  title: Text('Mute ${post.authorName} (${post.authorUsername})'),
                  onTap: () async {
                    Navigator.pop(ctx);
                    await SakhiPrototypeState.instance.toggleMuteUser(
                      username: post.authorUsername,
                      displayName: post.authorName,
                    );
                    if (!context.mounted) return;
                    SakhiDialogs.showPrototypeSnackbar(
                      context,
                      'Muted ${post.authorUsername} from your feed.',
                    );
                  },
                ),
              if (!isOwn) ...[
                ListTile(
                  leading: const Icon(
                    Icons.flag_outlined,
                    color: AppColors.sosRed,
                  ),
                  title: const Text('Report Post'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _showReportDialog(context);
                  },
                ),
                ListTile(
                  leading: const Icon(
                    Icons.shield_moon_rounded,
                    color: AppColors.primaryPurple,
                  ),
                  title: const Text(
                    'Report Discreetly (Anonymous / Confidential)',
                  ),
                  subtitle: const Text(
                    'File an anonymous or confidential safety report with photo privacy protection',
                  ),
                  onTap: () {
                    Navigator.pop(ctx);
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => DiscreetComplaintHubScreen(
                          initialLinkedPostId: post.id,
                          initialLinkedProfileHandle: post.authorUsername,
                        ),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(
                    Icons.block_rounded,
                    color: AppColors.sosRed,
                  ),
                  title: Text(
                    'Block ${post.authorName}',
                    style: const TextStyle(color: AppColors.sosRed),
                  ),
                  onTap: () async {
                    Navigator.pop(ctx);
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (dialogContext) => AlertDialog(
                        title: Text('Block ${post.authorUsername}?'),
                        content: const Text(
                          'Blocked members are removed from your Social Wall view. You can manage blocked members in Settings.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () =>
                                Navigator.pop(dialogContext, false),
                            child: const Text('Cancel'),
                          ),
                          FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: AppColors.sosRed,
                            ),
                            onPressed: () => Navigator.pop(dialogContext, true),
                            child: const Text('Block Member'),
                          ),
                        ],
                      ),
                    );
                    if (confirmed != true || !context.mounted) return;
                    final blocked = await SakhiPrototypeState.instance
                        .toggleBlockedUser(
                          username: post.authorUsername,
                          displayName: post.authorName,
                          accountId: post.authorAccountId,
                        );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          blocked
                              ? '${post.authorName} was blocked.'
                              : 'Member could not be blocked. No change was made.',
                        ),
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Compact Animated Bouncing Emoji Reaction Stack.
/// Displays at most the top 3–4 active emojis with a subtle floating bounce animation
/// plus a compact total count so even 10,000+ reactions never clutter the post card.
class _SakhiBouncingReactionBadges extends StatefulWidget {
  final List<String> emojis;
  final int totalReactions;

  const _SakhiBouncingReactionBadges({
    required this.emojis,
    required this.totalReactions,
  });

  @override
  State<_SakhiBouncingReactionBadges> createState() =>
      _SakhiBouncingReactionBadgesState();
}

class _SakhiBouncingReactionBadgesState
    extends State<_SakhiBouncingReactionBadges>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatCount(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4.5),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.white.withValues(alpha: 0.88),
                AppColors.pastelLavender.withValues(alpha: 0.72),
              ],
            ),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.94),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryPurple.withValues(alpha: 0.06),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (int i = 0; i < widget.emojis.length; i++)
                Transform.translate(
                  offset: Offset(
                    0,
                    math.sin((_controller.value * math.pi) + (i * 0.9)) * -2.2,
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(right: i == widget.emojis.length - 1 ? 6 : 3),
                    child: Text(
                      widget.emojis[i],
                      style: const TextStyle(fontSize: 13.5),
                    ),
                  ),
                ),
              Text(
                '${_formatCount(widget.totalReactions)} ${widget.totalReactions == 1 ? 'reaction' : 'reactions'}',
                style: AppTypography.subtitle.copyWith(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primaryPurple,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Instagram / Facebook-Style Draggable Comments Bottom Sheet with @username Threaded Replies.
class _SakhiInstagramCommentsSheet extends StatefulWidget {
  final FeedPostModel post;
  final bool autoFocusInput;

  const _SakhiInstagramCommentsSheet({
    required this.post,
    this.autoFocusInput = false,
  });

  @override
  State<_SakhiInstagramCommentsSheet> createState() =>
      _SakhiInstagramCommentsSheetState();
}

class _SakhiInstagramCommentsSheetState
    extends State<_SakhiInstagramCommentsSheet> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _inputFocusNode = FocusNode();
  PostCommentItem? _replyingTo;
  bool _isSubmitting = false;

  FeedPostModel get _livePost =>
      SakhiPrototypeState.instance.resolveLivePost(widget.post);

  static const List<String> _quickEmojis = [
    '❤️',
    '🙌',
    '🔥',
    '🌸',
    '💜',
    '👏',
    '✨',
    '🙏',
  ];

  @override
  void initState() {
    super.initState();
    _refreshComments();
    if (widget.autoFocusInput && widget.post.allowComments) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _inputFocusNode.requestFocus();
        }
      });
    }
  }

  Future<void> _refreshComments() async {
    if (!mounted) return;
    await SakhiPrototypeState.instance.loadComments(
      widget.post.id,
      widget.post,
    );
    if (!mounted) return;
  }

  void _openCommenterProfile(PostCommentItem comment) {
    final state = SakhiPrototypeState.instance;
    final handle = _resolveHandle(comment);
    final normHandle = handle.replaceFirst(RegExp(r'^@'), '').toLowerCase();
    FollowerUserModel? member;
    for (final f in state.followers) {
      if (comment.authorAccountId.isNotEmpty &&
          f.id == comment.authorAccountId) {
        member = f;
        break;
      }
      if (normHandle.isNotEmpty &&
          f.username.replaceFirst(RegExp(r'^@'), '').toLowerCase() ==
              normHandle) {
        member = f;
        break;
      }
    }
    member ??= FollowerUserModel(
      id: comment.authorAccountId.isNotEmpty
          ? comment.authorAccountId
          : handle,
      name: comment.authorName,
      username: handle,
      avatarAsset: comment.authorAvatar,
      isFollowing: false,
      isVerified: true,
      bio: 'Verified Sakhi community member.',
      interests: const <String>['Community', 'Safety'],
    );
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SearchResultMemberProfileScreen(member: member!),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _inputFocusNode.dispose();
    super.dispose();
  }

  String _resolveHandle(PostCommentItem comment) {
    if (comment.authorUsername.trim().isNotEmpty &&
        comment.authorUsername != '@member') {
      return comment.authorUsername.startsWith('@')
          ? comment.authorUsername.trim()
          : '@${comment.authorUsername.trim()}';
    }
    return '@${comment.authorName.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_')}';
  }

  void _startReply(PostCommentItem comment) {
    final prevHandle = _replyingTo != null ? _resolveHandle(_replyingTo!) : null;
    var currentText = _controller.text;
    if (prevHandle != null &&
        currentText.toLowerCase().startsWith('${prevHandle.toLowerCase()} ')) {
      currentText = currentText.substring(prevHandle.length).trimLeft();
      _controller.text = currentText;
      _controller.selection = TextSelection.fromPosition(
        TextPosition(offset: _controller.text.length),
      );
    }
    setState(() {
      _replyingTo = comment;
    });
    _inputFocusNode.requestFocus();
  }

  void _cancelReply() {
    final prevHandle = _replyingTo != null ? _resolveHandle(_replyingTo!) : null;
    var currentText = _controller.text;
    if (prevHandle != null &&
        currentText.toLowerCase().startsWith('${prevHandle.toLowerCase()} ')) {
      currentText = currentText.substring(prevHandle.length).trimLeft();
      _controller.text = currentText;
      _controller.selection = TextSelection.fromPosition(
        TextPosition(offset: _controller.text.length),
      );
    }
    setState(() {
      _replyingTo = null;
    });
  }

  void _insertEmoji(String emoji) {
    final text = _controller.text;
    final next = '$text$emoji';
    _controller.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: next.length),
    );
    _inputFocusNode.requestFocus();
  }

  Future<void> _submitComment() async {
    var rawText = _controller.text.trim();
    if (rawText.isEmpty || _isSubmitting) return;
    setState(() => _isSubmitting = true);

    final replyTarget = _replyingTo;
    final replyHandle = replyTarget != null ? _resolveHandle(replyTarget) : null;
    if (replyHandle != null &&
        rawText.toLowerCase().startsWith('${replyHandle.toLowerCase()} ')) {
      final stripped = rawText.substring(replyHandle.length).trim();
      if (stripped.isNotEmpty) {
        rawText = stripped;
      }
    }

    // If replying to a child reply, attach to the root parent comment so threads stay cleanly grouped
    final effectiveParentId = replyTarget != null
        ? ((replyTarget.parentCommentId != null &&
                  replyTarget.parentCommentId!.isNotEmpty)
              ? replyTarget.parentCommentId
              : replyTarget.id)
        : null;

    final submitted = await SakhiPrototypeState.instance.addPostComment(
      widget.post,
      rawText,
      parentCommentId: effectiveParentId,
      replyToHandle: replyHandle,
    );

    if (!mounted) return;
    setState(() {
      _isSubmitting = false;
      if (submitted) {
        _controller.clear();
        _replyingTo = null;
      }
    });
    if (!submitted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Comment could not be posted. Check your connection and retry.',
          ),
        ),
      );
    }
  }

  void _showEditCommentDialog(PostCommentItem comment) {
    final editCtrl = TextEditingController(text: comment.body);
    showDialog<void>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        backgroundColor: AppColors.cardSurface,
        title: const Text('Edit Comment', style: AppTypography.sectionTitle),
        content: TextField(
          controller: editCtrl,
          maxLines: 3,
          maxLength: 500,
          decoration: const InputDecoration(
            hintText: 'Update your comment...',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(),
            child: const Text('Cancel'),
          ),
          SakhiPillButton(
            label: 'Save',
            onPressed: () async {
              final nextText = editCtrl.text.trim();
              if (nextText.isEmpty) return;
              final ok = await SakhiPrototypeState.instance.editComment(
                widget.post.id,
                comment.id,
                nextText,
                widget.post,
              );
              if (!dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              if (!mounted) return;
              setState(() {});
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    ok ? 'Comment updated.' : 'Could not update comment.',
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Future<void> _confirmAndDeleteComment(PostCommentItem comment) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.cardSurface,
        title: const Text('Delete Comment?', style: AppTypography.sectionTitle),
        content: const Text(
          'Are you sure you want to remove this comment from the conversation?',
          style: AppTypography.bodyRegular,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.sosRed),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final ok = await SakhiPrototypeState.instance.removeComment(
      widget.post.id,
      comment.id,
      widget.post,
    );
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Comment deleted.'
              : 'Could not delete comment. Please try again.',
        ),
      ),
    );
  }

  Future<void> _reportComment(PostCommentItem comment) async {
    final ok = await SakhiPrototypeState.instance.reportMember(
      targetHandle: _resolveHandle(comment),
      postId: widget.post.id,
      commentId: comment.id,
      reason: 'Inappropriate or unsupportive comment',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Comment reported confidentially to Sakhi Trust & Safety.'
              : 'Report submitted for moderator review.',
        ),
      ),
    );
  }

  bool _isCommentOwnedByViewer(
    PostCommentItem comment,
    SakhiPrototypeState state,
  ) {
    if (comment.isOwnComment) return true;
    final myAccountId = state.currentUser.accountId.trim();
    if (comment.authorAccountId.trim().isNotEmpty && myAccountId.isNotEmpty) {
      return comment.authorAccountId.trim() == myAccountId;
    }
    final myUsername = state.currentUser.username
        .trim()
        .replaceFirst(RegExp(r'^@'), '')
        .toLowerCase();
    final cUsername = comment.authorUsername
        .trim()
        .replaceFirst(RegExp(r'^@'), '')
        .toLowerCase();
    if (myUsername.isNotEmpty &&
        cUsername.isNotEmpty &&
        cUsername != 'member') {
      return myUsername == cUsername;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final state = SakhiPrototypeState.instance;
    final mq = MediaQuery.of(context);
    final availableHeight = math.max(
      260.0,
      mq.size.height - mq.viewInsets.bottom - mq.padding.top - 16,
    );
    final sheetHeight = math.min(mq.size.height * 0.78, availableHeight);

    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final livePost = _livePost;
        final comments = state.groupThreadedComments(livePost.comments);
        return Padding(
          padding: EdgeInsets.only(bottom: mq.viewInsets.bottom),
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
              child: Container(
                height: sheetHeight,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.white.withValues(alpha: 0.94),
                      const Color(0xFFFDF4FA).withValues(alpha: 0.96),
                    ],
                  ),
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(28),
                  ),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.95),
                    width: 1.5,
                  ),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    Container(
                      width: 42,
                      height: 4.5,
                      decoration: BoxDecoration(
                        color: AppColors.textMuted.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(999),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 12, 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Comments (${comments.length})',
                              textAlign: TextAlign.center,
                              style: AppTypography.sectionTitle.copyWith(
                                fontSize: 16.5,
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            icon: const Icon(Icons.close_rounded, size: 20),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                        ],
                      ),
                    ),
                    const Divider(height: 1),
                    Expanded(
                      child: comments.isEmpty
                          ? SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 24,
                                vertical: 18,
                              ),
                              child: Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      Icons.chat_bubble_outline_rounded,
                                      size: 36,
                                      color: AppColors.primaryPurple.withValues(
                                        alpha: 0.45,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    const Text(
                                      'No comments yet',
                                      style: AppTypography.cardTitle,
                                    ),
                                    const SizedBox(height: 4),
                                    const Text(
                                      'Start the conversation with a supportive reply.',
                                      style: AppTypography.subtitle,
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : ListView.separated(
                              physics: const BouncingScrollPhysics(),
                              padding: const EdgeInsets.fromLTRB(
                                16,
                                14,
                                16,
                                18,
                              ),
                              itemCount: comments.length,
                              separatorBuilder: (_, _) =>
                                  const SizedBox(height: 14),
                              itemBuilder: (context, idx) {
                                final comment = comments[idx];
                                final isReply =
                                    (comment.parentCommentId != null &&
                                        comment.parentCommentId!.isNotEmpty) ||
                                    (comment.replyToHandle != null &&
                                        comment.replyToHandle!.isNotEmpty);
                                final isOwn = _isCommentOwnedByViewer(
                                  comment,
                                  state,
                                );
                                final canDelete =
                                    isOwn ||
                                    comment.canDelete ||
                                    widget.post.isOwnPost;
                                final handle = _resolveHandle(comment);
                                final timeLabel =
                                    formatSakhiRelativeTimestamp(
                                      comment.createdAt,
                                    );
                                return Padding(
                                  padding: EdgeInsets.only(
                                    left: isReply ? 28.0 : 0.0,
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SakhiAvatar(
                                        imageAsset: comment.authorAvatar,
                                        fallbackLabel: comment.authorName,
                                        size: isReply ? 28 : 34,
                                        onAvatarTap: () =>
                                            _openCommenterProfile(comment),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Wrap(
                                              crossAxisAlignment:
                                                  WrapCrossAlignment.center,
                                              spacing: 5,
                                              children: [
                                                InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                  onTap: () =>
                                                      _openCommenterProfile(
                                                        comment,
                                                      ),
                                                  child: Text(
                                                    comment.authorName,
                                                    style: AppTypography
                                                        .bodyMedium
                                                        .copyWith(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.w800,
                                                        ),
                                                  ),
                                                ),
                                                InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                  onTap: () =>
                                                      _openCommenterProfile(
                                                        comment,
                                                      ),
                                                  child: Text(
                                                    handle,
                                                    style: AppTypography.caption
                                                        .copyWith(
                                                          fontSize: 11,
                                                          color: AppColors
                                                              .primaryPurple,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  '• $timeLabel${comment.isEdited ? " (edited)" : ""}',
                                                  style: AppTypography.caption
                                                      .copyWith(fontSize: 11),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 3),
                                            RichText(
                                              text: TextSpan(
                                                style: AppTypography.bodyRegular
                                                    .copyWith(
                                                      fontSize: 13.5,
                                                      color:
                                                          AppColors.textPrimary,
                                                    ),
                                                children: [
                                                  if (comment.replyToHandle !=
                                                          null &&
                                                      comment.replyToHandle!
                                                          .isNotEmpty)
                                                    TextSpan(
                                                      text:
                                                          '${comment.replyToHandle!.startsWith('@') ? comment.replyToHandle! : '@${comment.replyToHandle!}'} ',
                                                      style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.w800,
                                                        color:
                                                            AppColors.primaryPurple,
                                                      ),
                                                    ),
                                                  TextSpan(text: comment.body),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(height: 5),
                                            Row(
                                              children: [
                                                InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(6),
                                                  onTap: () =>
                                                      _startReply(comment),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          vertical: 2,
                                                          horizontal: 4,
                                                        ),
                                                    child: Text(
                                                      'Reply',
                                                      style: AppTypography
                                                          .caption
                                                          .copyWith(
                                                            fontWeight:
                                                                FontWeight.w800,
                                                            color: AppColors
                                                                .primaryPurple,
                                                          ),
                                                    ),
                                                  ),
                                                ),
                                                if (isOwn) ...[
                                                  const SizedBox(width: 12),
                                                  InkWell(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    onTap: () =>
                                                        _showEditCommentDialog(
                                                          comment,
                                                        ),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            vertical: 2,
                                                            horizontal: 4,
                                                          ),
                                                      child: Text(
                                                        'Edit',
                                                        style: AppTypography
                                                            .caption
                                                            .copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                                if (canDelete) ...[
                                                  const SizedBox(width: 12),
                                                  InkWell(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    onTap: () =>
                                                        _confirmAndDeleteComment(
                                                          comment,
                                                        ),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            vertical: 2,
                                                            horizontal: 4,
                                                          ),
                                                      child: Text(
                                                        'Delete',
                                                        style: AppTypography
                                                            .caption
                                                            .copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: AppColors
                                                                  .sosRed,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                                if (!isOwn) ...[
                                                  const SizedBox(width: 12),
                                                  InkWell(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          6,
                                                        ),
                                                    onTap: () =>
                                                        _reportComment(comment),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            vertical: 2,
                                                            horizontal: 4,
                                                          ),
                                                      child: Text(
                                                        'Report',
                                                        style: AppTypography
                                                            .caption
                                                            .copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: AppColors
                                                                  .textMuted,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      InkWell(
                                        borderRadius: BorderRadius.circular(12),
                                        onTap: () async {
                                          HapticFeedback.lightImpact();
                                          await state.toggleCommentLike(
                                            widget.post.id,
                                            comment.id,
                                            widget.post,
                                          );
                                          if (mounted) setState(() {});
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 4,
                                            vertical: 4,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                comment.isLiked
                                                    ? Icons.favorite_rounded
                                                    : Icons
                                                          .favorite_border_rounded,
                                                size: 16,
                                                color: comment.isLiked
                                                    ? AppColors.heartPink
                                                    : AppColors.textMuted,
                                              ),
                                              if (comment.likesCount > 0)
                                                Text(
                                                  '${comment.likesCount}',
                                                  style: AppTypography.caption
                                                      .copyWith(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                      ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                    if (_replyingTo != null)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 6,
                        ),
                        color: AppColors.pastelLavender,
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Replying to ${_replyingTo!.authorName} (${_resolveHandle(_replyingTo!)})',
                                style: AppTypography.caption.copyWith(
                                  color: AppColors.primaryPurple,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: _cancelReply,
                              child: const Icon(
                                Icons.close_rounded,
                                size: 16,
                                color: AppColors.primaryPurple,
                              ),
                            ),
                          ],
                        ),
                      ),
                    if (widget.post.allowComments) ...[
                      const Divider(height: 1),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 5,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: _quickEmojis
                              .map(
                                (emoji) => GestureDetector(
                                  onTap: () => _insertEmoji(emoji),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 4,
                                      vertical: 2,
                                    ),
                                    child: Text(
                                      emoji,
                                      style: const TextStyle(fontSize: 19),
                                    ),
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                      SafeArea(
                        top: false,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
                          child: Row(
                            children: [
                              SakhiAvatar(
                                imageAsset: state.currentUser.avatarAsset,
                                fallbackLabel: state.currentUser.displayName,
                                size: 32,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: TextField(
                                  controller: _controller,
                                  focusNode: _inputFocusNode,
                                  textInputAction: TextInputAction.send,
                                  onSubmitted: (_) => _submitComment(),
                                  decoration: InputDecoration(
                                    hintText: _replyingTo != null
                                        ? 'Reply to ${_replyingTo!.authorName}...'
                                        : 'Add a supportive comment...',
                                    isDense: true,
                                    contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 10,
                                    ),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(999),
                                      borderSide: const BorderSide(
                                        color: AppColors.borderSubtle,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(999),
                                      borderSide: const BorderSide(
                                        color: AppColors.borderSubtle,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              SakhiPillButton(
                                label: _isSubmitting ? '...' : 'Post Comment',
                                onPressed: _isSubmitting
                                    ? null
                                    : _submitComment,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SakhiRadialReactionWheelDialog extends StatefulWidget {
  final FeedPostModel post;
  final List<Map<String, String>> reactions;
  final ValueNotifier<Offset?> externalDragGlobalPosition;
  final ValueNotifier<int> externalDragReleaseSignal;
  final bool startedFromHold;
  final Future<void> Function(String key, String emoji, String label)
  onSelectReaction;

  const _SakhiRadialReactionWheelDialog({
    required this.post,
    required this.reactions,
    required this.externalDragGlobalPosition,
    required this.externalDragReleaseSignal,
    required this.startedFromHold,
    required this.onSelectReaction,
  });

  @override
  State<_SakhiRadialReactionWheelDialog> createState() =>
      _SakhiRadialReactionWheelDialogState();
}

class _SakhiRadialReactionWheelDialogState
    extends State<_SakhiRadialReactionWheelDialog>
    with SingleTickerProviderStateMixin {
  final GlobalKey _wheelKey = GlobalKey();
  int? _hoveredIndex;
  String? _burstEmoji;
  String? _burstLabel;
  bool _hasDraggedOntoSector = false;
  bool _isSelecting = false;
  late final AnimationController _burstController;

  @override
  void initState() {
    super.initState();
    final currentKey = widget.post.viewerReaction;
    if (currentKey != null) {
      final idx = widget.reactions.indexWhere((r) => r['key'] == currentKey);
      if (idx != -1) _hoveredIndex = idx;
    }
    _burstController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 480),
    );
    widget.externalDragGlobalPosition.addListener(_onExternalFingerMove);
    widget.externalDragReleaseSignal.addListener(_onExternalFingerRelease);
  }

  @override
  void dispose() {
    widget.externalDragGlobalPosition.removeListener(_onExternalFingerMove);
    widget.externalDragReleaseSignal.removeListener(_onExternalFingerRelease);
    _burstController.dispose();
    super.dispose();
  }

  void _onExternalFingerMove() {
    final globalPos = widget.externalDragGlobalPosition.value;
    if (globalPos == null || !mounted) return;
    final box = _wheelKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    final localPos = box.globalToLocal(globalPos);
    _updateHoverFromOffset(localPos, box.size);
  }

  void _onExternalFingerRelease() {
    if (!mounted || _isSelecting) return;
    if (_hasDraggedOntoSector && _hoveredIndex != null) {
      _triggerSelection(_hoveredIndex!);
    }
  }

  void _updateHoverFromOffset(Offset localPosition, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final dx = localPosition.dx - center.dx;
    final dy = localPosition.dy - center.dy;
    final dist = math.sqrt(dx * dx + dy * dy);
    if (dist < 24 || dist > 200) return;

    var angle = math.atan2(dy, dx);
    if (angle < 0) angle += 2 * math.pi;
    final sectorAngle = (2 * math.pi) / widget.reactions.length;
    final normalized = (angle + math.pi / 2 + sectorAngle / 2) % (2 * math.pi);
    final index = (normalized / sectorAngle).floor() % widget.reactions.length;
    _hasDraggedOntoSector = true;
    if (_hoveredIndex != index) {
      HapticFeedback.selectionClick();
      setState(() => _hoveredIndex = index);
    }
  }

  Future<void> _triggerSelection(int index) async {
    if (_isSelecting) return;
    _isSelecting = true;
    final item = widget.reactions[index];
    setState(() {
      _hoveredIndex = index;
      _burstEmoji = item['emoji'];
      _burstLabel = item['label'];
    });
    _burstController.forward(from: 0);
    await widget.onSelectReaction(
      item['key']!,
      item['emoji']!,
      item['label']!,
    );
    await Future<void>.delayed(const Duration(milliseconds: 300));
    if (mounted && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    const double wheelSize = 320;
    const double orbitRadius = 112;
    final hovered = _hoveredIndex != null
        ? widget.reactions[_hoveredIndex!]
        : null;

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerMove: (event) {
        final box = _wheelKey.currentContext?.findRenderObject() as RenderBox?;
        if (box != null && box.hasSize) {
          _updateHoverFromOffset(box.globalToLocal(event.position), box.size);
        }
      },
      onPointerUp: (_) {
        if (_hasDraggedOntoSector && _hoveredIndex != null) {
          _triggerSelection(_hoveredIndex!);
        }
      },
      child: Center(
        child: Material(
          color: Colors.transparent,
          child: GestureDetector(
            onPanStart: (details) => _updateHoverFromOffset(
              details.localPosition,
              const Size(wheelSize, wheelSize),
            ),
            onPanUpdate: (details) => _updateHoverFromOffset(
              details.localPosition,
              const Size(wheelSize, wheelSize),
            ),
            onPanEnd: (_) {
              if (_hoveredIndex != null) {
                _triggerSelection(_hoveredIndex!);
              }
            },
            child: SizedBox(
              width: wheelSize,
              height: wheelSize + 58,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.88),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.95),
                          ),
                        ),
                        child: Text(
                          hovered != null
                              ? '${hovered['emoji']} ${hovered['label']} • Release or Tap to React'
                              : 'Slide Finger or Tap Any Emoji • Sisterhood Wheel',
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.primaryPurple,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    key: _wheelKey,
                    width: wheelSize,
                    height: wheelSize,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        ClipOval(
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                            child: Container(
                              width: wheelSize,
                              height: wheelSize,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    const Color(
                                      0xFFFDF4FA,
                                    ).withValues(alpha: 0.58),
                                    const Color(
                                      0xFFF3E2FA,
                                    ).withValues(alpha: 0.90),
                                  ],
                                ),
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: 0.94),
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.primaryPurple.withValues(
                                      alpha: 0.24,
                                    ),
                                    blurRadius: 32,
                                    spreadRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        AnimatedBuilder(
                          animation: _burstController,
                          builder: (context, _) {
                            final burstScale =
                                1.0 +
                                math.sin(_burstController.value * math.pi) *
                                    0.45;
                            return Transform.scale(
                              scale: _burstEmoji != null ? burstScale : 1.0,
                              child: Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Color(0xFF88299F),
                                      Color(0xFF5A1868),
                                    ],
                                  ),
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 2.5,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0x445A1868),
                                      blurRadius: 16,
                                      offset: Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      _burstEmoji ?? hovered?['emoji'] ?? '🌸',
                                      style: const TextStyle(fontSize: 30),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      _burstLabel ??
                                          hovered?['label'] ??
                                          'React',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w800,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                        for (int i = 0; i < widget.reactions.length; i++)
                          Builder(
                            builder: (context) {
                              final item = widget.reactions[i];
                              final angle =
                                  -math.pi / 2 +
                                  (i * 2 * math.pi / widget.reactions.length);
                              final dx = orbitRadius * math.cos(angle);
                              final dy = orbitRadius * math.sin(angle);
                              final isSelected =
                                  _hoveredIndex == i ||
                                  widget.post.viewerReaction == item['key'];

                              return Transform.translate(
                                offset: Offset(dx, dy),
                                child: GestureDetector(
                                  onTap: () => _triggerSelection(i),
                                  child: AnimatedScale(
                                    duration: const Duration(milliseconds: 140),
                                    scale: isSelected ? 1.28 : 1.0,
                                    child: Container(
                                      width: 64,
                                      height: 64,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isSelected
                                            ? AppColors.primaryPurple
                                            : Colors.white.withValues(
                                                alpha: 0.94,
                                              ),
                                        border: Border.all(
                                          color: isSelected
                                              ? Colors.white
                                              : AppColors.borderSubtle,
                                          width: isSelected ? 2.2 : 1.2,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: AppColors.primaryPurple
                                                .withValues(
                                                  alpha: isSelected
                                                      ? 0.34
                                                      : 0.08,
                                                ),
                                            blurRadius: isSelected ? 14 : 6,
                                            offset: const Offset(0, 3),
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            item['emoji']!,
                                            style: const TextStyle(
                                              fontSize: 22,
                                            ),
                                          ),
                                          const SizedBox(height: 1),
                                          Text(
                                            item['label']!,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 8.5,
                                              fontWeight: FontWeight.w800,
                                              color: isSelected
                                                  ? Colors.white
                                                  : AppColors.textPrimary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
