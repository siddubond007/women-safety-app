import '../../../core/widgets/sakhi_quote_loader.dart';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/navigation/app_routes.dart';
import '../../notifications/screens/messages_and_notifications_inbox_screens.dart';

import '../../../core/assets/app_assets.dart';
import '../../../core/constants/mock_data.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../core/widgets/sakhi_avatar.dart';
import '../../../core/widgets/sakhi_card.dart';
import '../../../core/widgets/sakhi_chip.dart';
import '../../../core/widgets/sakhi_empty_state.dart';
import '../../../core/widgets/sakhi_section_header.dart';
import '../../../core/widgets/sakhi_remote_media_image.dart';
import '../../business/screens/business_hub_screen.dart';
import '../../community/widgets/feed_post_card.dart';
import '../../followers/screens/followers_following_screen.dart';
import '../../safety/models/safety_models.dart';

Future<void> showCircleMembershipUnavailable(
  BuildContext context,
  String circleName,
) async {
  final state = SakhiPrototypeState.instance;
  await state.joinOrCreateCommunityCircle(circleName);
  if (!context.mounted) return;
  final isJoined = state.isCircleJoined(circleName);
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        isJoined
            ? 'Joined "$circleName" circle!'
            : 'Left "$circleName" circle.',
      ),
    ),
  );
}

class SakhiJoinCircleButton extends StatefulWidget {
  const SakhiJoinCircleButton({super.key, required this.circleName});

  final String circleName;

  @override
  State<SakhiJoinCircleButton> createState() => _SakhiJoinCircleButtonState();
}

class _SakhiJoinCircleButtonState extends State<SakhiJoinCircleButton> {
  bool _busy = false;

  Future<void> _toggleJoin() async {
    if (_busy) return;
    setState(() => _busy = true);
    final state = SakhiPrototypeState.instance;
    await state.joinOrCreateCommunityCircle(widget.circleName);
    if (!mounted) return;
    setState(() => _busy = false);
    final isJoined = state.isCircleJoined(widget.circleName);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isJoined
              ? 'You joined ${widget.circleName}!'
              : 'You left ${widget.circleName}.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = SakhiPrototypeState.instance;
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final joined = state.isCircleJoined(widget.circleName);
        return FilledButton.tonal(
          onPressed: _busy ? null : _toggleJoin,
          style: FilledButton.styleFrom(
            backgroundColor: joined
                ? AppColors.pastelLavender
                : AppColors.primaryPurple,
            foregroundColor: joined ? AppColors.primaryPurple : Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            minimumSize: const Size(0, 34),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          child: _busy
              ? const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : Text(
                  joined ? 'Joined ✓' : 'Join',
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
        );
      },
    );
  }
}

/// Category destination and privacy-aware search destinations used by Explore,
/// Home search, hashtag chips, and the Social Wall search action.
class CategoryDestinationScreen extends StatefulWidget {
  const CategoryDestinationScreen({
    super.key,
    required this.categorySlug,
    required this.title,
  });

  final String categorySlug;
  final String title;

  @override
  State<CategoryDestinationScreen> createState() =>
      _CategoryDestinationScreenState();
}

class _CategoryDestinationScreenState extends State<CategoryDestinationScreen> {
  List<FeedPostModel> _posts = const [];
  bool _loading = true;
  bool _failed = false;

  String get _description => switch (widget.categorySlug) {
    'health_wellness' =>
      'Wellbeing resources, mindful routines, and supportive conversations.',
    'safety_awareness' =>
      'Commute tips, helpline resources, and practical safety awareness.',
    'education_career' =>
      'Mentorship circles, career resources, and skill-sharing for women.',
    _ => 'Discover hobbies, everyday inspiration, and community stories.',
  };

  List<String> get _keywords => switch (widget.categorySlug) {
    'health_wellness' => ['wellness', 'health', 'mindful', 'mental', 'fitness'],
    'safety_awareness' => ['safety', 'commute', 'helpline', 'awareness'],
    'education_career' => [
      'education',
      'career',
      'job',
      'tech',
      'startup',
      'learn',
    ],
    _ => ['lifestyle', 'hobby', 'travel', 'reading', 'art', 'journal'],
  };

  @override
  void initState() {
    super.initState();
    unawaited(_loadCategory());
  }

  Future<void> _loadCategory() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final state = SakhiPrototypeState.instance;
    await state.syncFromBackend();
    final categorySlug = switch (widget.categorySlug) {
      'health_wellness' || 'lifestyle_hobbies' => 'wellness_lifestyle',
      'safety_awareness' => 'safety_awareness',
      _ => 'all',
    };
    final result = await state.fetchPosts(
      categorySlug: categorySlug,
      limit: 30,
    );
    if (!mounted) return;
    final keywordSet = _keywords;
    setState(() {
      _failed = result == null;
      final candidates = result ?? const <FeedPostModel>[];
      _posts =
          widget.categorySlug == 'education_career' ||
              widget.categorySlug == 'lifestyle_hobbies'
          ? candidates
                .where((post) {
                  final searchable =
                      '${post.content} ${post.categoryBadge ?? ''} ${post.categorySlug} ${post.hashtags.join(' ')}'
                          .toLowerCase();
                  return keywordSet.any(searchable.contains);
                })
                .toList(growable: false)
          : candidates;
      _loading = false;
    });
  }

  List<CommunityGroupModel> _matchingGroups(SakhiPrototypeState state) {
    return state.groups
        .where((group) {
          final value = '${group.name} ${group.description} ${group.category}'
              .toLowerCase();
          return _keywords.any(value.contains);
        })
        .toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final state = SakhiPrototypeState.instance;
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackground,
        elevation: 0,
        leading: IconButton(
          tooltip: 'Back to Explore',
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        title: Text('${widget.title} Hub', style: AppTypography.appBarTitle),
      ),
      body: AnimatedBuilder(
        animation: state,
        builder: (context, _) {
          final groups = _matchingGroups(state);
          return RefreshIndicator(
            onRefresh: _loadCategory,
            color: AppColors.primaryPurple,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.screenPaddingH,
                4,
                AppSpacing.screenPaddingH,
                96,
              ),
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: AppColors.heroBannerGradient,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.borderSubtle),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${widget.title} Hub',
                              style: AppTypography.sectionTitle.copyWith(
                                fontSize: 19,
                              ),
                            ),
                            const SizedBox(height: 7),
                            Text(
                              _description,
                              style: AppTypography.bodyRegular,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: SizedBox(
                          width: 88,
                          height: 88,
                          child: Image.asset(
                            AppAssets.educationCareerHubBanner,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                const SakhiSectionHeader(title: 'Featured Circles'),
                const SizedBox(height: 10),
                if (_loading && state.groups.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: SakhiQuoteLoader.inline(
                      statusLabel: 'Discovering active circles near you…',
                    ),
                  )
                else if (groups.isEmpty)
                  SakhiEmptyState(
                    icon: Icons.groups_outlined,
                    title: 'No circles in this category yet',
                    message: state.isBackendSynced
                        ? 'Circles will appear here when the community has relevant groups.'
                        : 'Connect to Sakhi to load real circles from your account.',
                    actionLabel: state.isBackendSynced ? null : 'Retry',
                    onAction: state.isBackendSynced
                        ? null
                        : () => unawaited(state.syncFromBackend()),
                  )
                else
                  ...groups.map(
                    (group) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: SakhiCard(
                        child: Row(
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                color: AppColors.pastelLavender,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: const Icon(
                                Icons.groups_rounded,
                                color: AppColors.primaryPurple,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    group.name,
                                    style: AppTypography.cardTitle,
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    '${group.membersCount} members • ${group.description}',
                                    style: AppTypography.subtitle,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 4),
                            SakhiJoinCircleButton(circleName: group.name),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                const SakhiSectionHeader(
                  title: 'Top Community Posts & Resources',
                ),
                const SizedBox(height: 10),
                if (_loading)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(22),
                      child: CircularProgressIndicator(),
                    ),
                  )
                else if (_failed)
                  SakhiEmptyState(
                    icon: Icons.cloud_off_outlined,
                    title: "Couldn't refresh latest posts",
                    message:
                        'Your posts could not be loaded from the Sakhi API.',
                    actionLabel: 'Retry',
                    onAction: () => unawaited(_loadCategory()),
                  )
                else if (_posts.isEmpty)
                  SakhiEmptyState(
                    icon: Icons.auto_awesome_outlined,
                    title: 'No posts in ${widget.title} yet',
                    message: 'Be among the first members to share a useful story or resource in this category.',
                  )
                else
                  ..._posts.map(
                    (post) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: FeedPostCard(
                        post: post,
                        onLikeTap: () => state.togglePostLike(post),
                        onSaveTap: () => state.togglePostSaved(post),
                        showVerifiedCheck: true,
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class SearchResultsScreen extends StatefulWidget {
  const SearchResultsScreen({super.key, this.initialQuery = ''});

  final String initialQuery;

  @override
  State<SearchResultsScreen> createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  late final TextEditingController _controller;
  Timer? _debounce;
  String _activeFilter = 'All';
  List<FeedPostModel> _posts = const [];
  List<FollowerUserModel> _members = const [];
  List<BusinessPageModel> _businesses = const [];
  List<Map<String, dynamic>> _products = const [];
  List<Map<String, dynamic>> _wellnessGuides = const [];
  List<Map<String, dynamic>> _nearbyPoliceStations = const [];
  bool _loading = false;
  bool _failed = false;
  bool _postsUnavailable = false;
  bool _membersUnavailable = false;
  String _requestedQuery = '';

  static const _filters = [
    'All',
    'Posts',
    'Members',
    'Businesses',
    'Products',
    'Circles',
    'Wellness',
    'Nearby Safety',
  ];
  static const _starterTopics = [
    '#MentalWellness',
    '#WomenInTech',
    '#SafetyTips',
    '#SmallBusiness',
    'Period Pain Help',
    'Guided Meditation',
  ];

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialQuery);
    unawaited(SakhiPrototypeState.instance.syncFromBackend());
    if (_controller.text.trim().isNotEmpty) {
      _scheduleSearch(_controller.text, immediate: true);
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _scheduleSearch(String raw, {bool immediate = false}) {
    _debounce?.cancel();
    final query = raw.trim();
    if (query.isEmpty) {
      setState(() {
        _requestedQuery = '';
        _posts = const [];
        _members = const [];
        _businesses = const [];
        _loading = false;
        _failed = false;
        _postsUnavailable = false;
        _membersUnavailable = false;
      });
      return;
    }
    _debounce = Timer(
      immediate ? Duration.zero : const Duration(milliseconds: 300),
      () => unawaited(_runSearch(query)),
    );
  }

  Future<void> _runSearch(String query) async {
    setState(() {
      _requestedQuery = query;
      _loading = true;
      _failed = false;
      _postsUnavailable = false;
      _membersUnavailable = false;
    });

    final state = SakhiPrototypeState.instance;
    state.addRecentSearch(query);
    final postsFuture = state.fetchPosts(
      search: query,
      categorySlug: 'all',
      limit: 30,
    );
    final membersFuture = state.searchVisibleMembers(query);
    final businessesFuture = state.fetchBusinesses(search: query);
    final unifiedFuture = state.unifiedSearch(q: query);
    final postsResult = await postsFuture;
    final membersResult = await membersFuture;
    final businessesResult = await businessesFuture;
    final unifiedResult = await unifiedFuture;

    if (!mounted || query != _controller.text.trim()) return;
    setState(() {
      _posts = (postsResult ?? const [])
          .where((p) => !state.isPostSuppressed(p))
          .toList(growable: false);
      _members = (membersResult ?? const [])
          .where((m) => !state.isUsernameBlocked(m.username))
          .toList(growable: false);
      _businesses = businessesResult
          .map(BusinessPageModel.fromJson)
          .toList(growable: false);
      _products = List<Map<String, dynamic>>.from(
        unifiedResult['products'] ?? const [],
      );
      _wellnessGuides = List<Map<String, dynamic>>.from(
        unifiedResult['wellness'] ?? const [],
      );
      _nearbyPoliceStations = List<Map<String, dynamic>>.from(
        unifiedResult['nearbyPoliceStations'] ?? const [],
      );
      _postsUnavailable = postsResult == null;
      _membersUnavailable = membersResult == null;
      _failed =
          postsResult == null &&
          membersResult == null &&
          businessesResult.isEmpty &&
          _wellnessGuides.isEmpty;
      _loading = false;
    });
  }

  void _openTopic(String topic) {
    _controller.text = topic;
    _controller.selection = TextSelection.collapsed(
      offset: _controller.text.length,
    );
    setState(() => _activeFilter = 'All');
    _scheduleSearch(topic, immediate: true);
  }

  List<FollowerUserModel> _matchingMembers(SakhiPrototypeState state) {
    final query = _requestedQuery.toLowerCase().replaceFirst('#', '');
    if (query.isEmpty) return const [];
    return _members
        .where((member) {
          final searchable = [
            member.name,
            member.username,
            member.bio ?? '',
            ...member.interests,
          ].join(' ').toLowerCase();
          return searchable.contains(query);
        })
        .toList(growable: false);
  }

  List<CommunityGroupModel> _matchingGroups(SakhiPrototypeState state) {
    final query = _requestedQuery.toLowerCase().replaceFirst('#', '');
    if (query.isEmpty) return const [];
    return state.groups
        .where((group) {
          return '${group.name} ${group.description} ${group.category}'
              .toLowerCase()
              .contains(query);
        })
        .toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final state = SakhiPrototypeState.instance;
    final query = _requestedQuery.toLowerCase().replaceFirst('#', '');
    final posts = _posts
        .where((post) {
          if (query.isEmpty) return false;
          final searchable =
              '${post.content} ${post.authorName} ${post.authorUsername} ${post.categoryBadge ?? ''} ${post.hashtags.join(' ')}'
                  .toLowerCase();
          return searchable.contains(query);
        })
        .toList(growable: false);
    final members = _matchingMembers(state);
    final businessMembers = members
        .where((member) => (member.businessProfileUrl ?? '').trim().isNotEmpty)
        .toList(growable: false);
    final groups = _matchingGroups(state);

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackground,
        elevation: 0,
        leading: IconButton(
          tooltip: 'Back',
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        title: const Text('Search Sakhi', style: AppTypography.appBarTitle),
      ),
      body: AnimatedBuilder(
        animation: state,
        builder: (context, _) => Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.screenPaddingH,
                4,
                AppSpacing.screenPaddingH,
                12,
              ),
              child: TextField(
                controller: _controller,
                autofocus: widget.initialQuery.isEmpty,
                onChanged: (value) {
                  setState(() {});
                  _scheduleSearch(value);
                },
                textInputAction: TextInputAction.search,
                onSubmitted: (value) => _scheduleSearch(value, immediate: true),
                decoration: InputDecoration(
                  hintText: 'Search people, topics, circles, businesses...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _controller.text.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Clear search',
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () {
                            _controller.clear();
                            _scheduleSearch('');
                            setState(() {});
                          },
                        ),
                ),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.screenPaddingH,
                ),
                children: _filters.map((filter) {
                  final selected = _activeFilter == filter;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: SakhiChip(
                      label: filter,
                      isSelected: selected,
                      onTap: () => setState(() => _activeFilter = filter),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.screenPaddingH,
                  8,
                  AppSpacing.screenPaddingH,
                  96,
                ),
                children: [
                  if (_controller.text.trim().isEmpty) ...[
                    if (state.recentSearches.isNotEmpty) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Recent searches',
                            style: AppTypography.sectionTitle,
                          ),
                          TextButton(
                            onPressed: state.clearRecentSearches,
                            child: const Text('Clear all'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: state.recentSearches
                            .map(
                              (item) => SakhiChip(
                                label: item,
                                onTap: () => _openTopic(item),
                              ),
                            )
                            .toList(),
                      ),
                      const SizedBox(height: 18),
                    ],
                    const Text(
                      'Explore topics',
                      style: AppTypography.sectionTitle,
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _starterTopics
                          .map(
                            (topic) => SakhiChip(
                              label: topic,
                              onTap: () => _openTopic(topic),
                            ),
                          )
                          .toList(),
                    ),
                    const SizedBox(height: 22),
                    const SakhiEmptyState(
                      icon: Icons.search_rounded,
                      title: 'Find your Sakhi community',
                      message: 'Search visible member profiles, community posts, circles, and women-owned businesses.',
                    ),
                  ] else if (_loading) ...[
                    const SizedBox(height: 44),
                    const Center(child: CircularProgressIndicator()),
                    const SizedBox(height: 14),
                    const Center(child: Text('Searching Sakhi...')),
                  ] else if (_failed) ...[
                    SakhiEmptyState(
                      icon: Icons.cloud_off_outlined,
                      title: 'Search is unavailable',
                      message: 'Sakhi could not retrieve results from the connected API. Please try again.',
                      actionLabel: 'Retry',
                      onAction: () =>
                          _scheduleSearch(_controller.text, immediate: true),
                    ),
                  ] else ...[
                    if (_activeFilter == 'All' || _activeFilter == 'Posts') ...[
                      const SakhiSectionHeader(title: 'Posts'),
                      const SizedBox(height: 10),
                      if (_postsUnavailable)
                        SakhiEmptyState(
                          icon: Icons.cloud_off_outlined,
                          title: 'Posts could not be loaded',
                          message: 'Sakhi could not retrieve posts for this search. Your member results may still be available.',
                          actionLabel: 'Retry',
                          onAction: () => _scheduleSearch(
                            _controller.text,
                            immediate: true,
                          ),
                        )
                      else if (posts.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No matching posts were found.',
                        )
                      else
                        ...posts.map(
                          (post) => Padding(
                            padding: const EdgeInsets.only(bottom: 14),
                            child: FeedPostCard(
                              post: post,
                              onLikeTap: () => state.togglePostLike(post),
                              onSaveTap: () => state.togglePostSaved(post),
                              showVerifiedCheck: true,
                            ),
                          ),
                        ),
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Members') ...[
                      const SakhiSectionHeader(title: 'Visible Members'),
                      const SizedBox(height: 10),
                      if (_membersUnavailable)
                        const _InlineEmptyResult(
                          text: 'Verified member search is unavailable. Retry to load current privacy-filtered results.',
                        )
                      else if (members.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No visible, verified member profiles matched this search.',
                        )
                      else
                        ...members.map(
                          (member) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Material(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              child: ListTile(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  side: const BorderSide(
                                    color: AppColors.borderSubtle,
                                  ),
                                ),
                                leading: SakhiAvatar(
                                  imageAsset: member.avatarAsset,
                                  fallbackLabel: member.name,
                                  size: 46,
                                ),
                                title: Row(
                                  children: [
                                    Flexible(
                                      child: Text(
                                        member.name,
                                        overflow: TextOverflow.ellipsis,
                                        style: AppTypography.cardTitle,
                                      ),
                                    ),
                                    if (member.isVerified) ...[
                                      const SizedBox(width: 5),
                                      const Icon(
                                        Icons.verified_rounded,
                                        size: 16,
                                        color: AppColors.primaryPurple,
                                      ),
                                    ],
                                  ],
                                ),
                                subtitle: Text(
                                  [
                                    member.username,
                                    if (member.bio?.trim().isNotEmpty == true)
                                      member.bio!.trim(),
                                  ].join(' • '),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: const Icon(
                                  Icons.chevron_right_rounded,
                                ),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (_) =>
                                        SearchResultMemberProfileScreen(
                                          member: member,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Circles') ...[
                      const SizedBox(height: 12),
                      const SakhiSectionHeader(title: 'Circles'),
                      const SizedBox(height: 10),
                      if (groups.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No matching circles were found.',
                        )
                      else
                        ...groups.map(
                          (group) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const CircleAvatar(
                                  backgroundColor: AppColors.pastelLavender,
                                  child: Icon(
                                    Icons.groups_rounded,
                                    color: AppColors.primaryPurple,
                                  ),
                                ),
                                title: Text(group.name),
                                subtitle: Text(
                                  '${group.membersCount} members • ${group.description}',
                                ),
                                trailing: SakhiJoinCircleButton(
                                  circleName: group.name,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Businesses') ...[
                      const SizedBox(height: 12),
                      const SakhiSectionHeader(title: 'Women-Owned Businesses'),
                      const SizedBox(height: 10),
                      if (_businesses.isEmpty && businessMembers.isEmpty)
                        const _InlineEmptyResult(
                          text:
                              'No women-owned businesses matched this search.',
                        )
                      else ...[
                        ..._businesses.map(
                          (biz) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const CircleAvatar(
                                  backgroundColor: Color(0xFFFFF3E0),
                                  child: Icon(
                                    Icons.storefront_rounded,
                                    color: Color(0xFFB45309),
                                  ),
                                ),
                                title: Text(
                                  biz.businessName,
                                  style: AppTypography.cardTitle,
                                ),
                                subtitle: Text(
                                  '${biz.category} • ${biz.city} • ${biz.priceRange}',
                                ),
                                trailing: const Icon(
                                  Icons.chevron_right_rounded,
                                ),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (_) => BusinessProfileDetailScreen(
                                      businessId: biz.id,
                                      initialModel: biz,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        ...businessMembers.map(
                          (member) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              child: ListTile(
                                leading: const CircleAvatar(
                                  backgroundColor: AppColors.pastelLavender,
                                  child: Icon(
                                    Icons.storefront_outlined,
                                    color: AppColors.primaryPurple,
                                  ),
                                ),
                                title: Text(
                                  (member.businessProfileName ?? '')
                                          .trim()
                                          .isNotEmpty
                                      ? member.businessProfileName!
                                      : 'Linked business profile',
                                  style: AppTypography.cardTitle,
                                ),
                                subtitle: Text(
                                  '${member.businessCategory ?? 'Women-owned business'} • ${member.name}',
                                ),
                                trailing: const Icon(
                                  Icons.chevron_right_rounded,
                                ),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (_) =>
                                        SearchResultMemberProfileScreen(
                                          member: member,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Products') ...[
                      const SizedBox(height: 12),
                      const SakhiSectionHeader(title: 'Products & Services'),
                      const SizedBox(height: 10),
                      if (_products.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No matching products or services were found.',
                        )
                      else
                        ..._products.map(
                          (prod) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const CircleAvatar(
                                  backgroundColor: Color(0xFFFDF2F8),
                                  child: Icon(
                                    Icons.shopping_bag_outlined,
                                    color: Color(0xFFBE185D),
                                  ),
                                ),
                                title: Text(
                                  (prod['title'] ?? '').toString(),
                                  style: AppTypography.cardTitle,
                                ),
                                subtitle: Text(
                                  '${prod['businessName'] ?? 'Verified Business'} • ${prod['priceLabel'] ?? ''} • ${prod['city'] ?? ''}',
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Wellness') ...[
                      const SizedBox(height: 12),
                      const SakhiSectionHeader(
                        title: 'Wellness, Period Care & Meditation Guides',
                      ),
                      const SizedBox(height: 10),
                      if (_wellnessGuides.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No matching wellness guides were found.',
                        )
                      else
                        ..._wellnessGuides.map(
                          (guide) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              onTap: () {
                                final link =
                                    (guide['deepLink'] ?? '').toString();
                                if (link.contains('cycle-tracker')) {
                                  Navigator.pushNamed(
                                    context,
                                    AppRoutes.menstrualCycleTracker,
                                  );
                                } else {
                                  Navigator.pushNamed(
                                    context,
                                    AppRoutes.wellness,
                                  );
                                }
                              },
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const CircleAvatar(
                                  backgroundColor: Color(0xFFF3E8FF),
                                  child: Icon(
                                    Icons.self_improvement_rounded,
                                    color: AppColors.primaryPurple,
                                  ),
                                ),
                                title: Text(
                                  (guide['title'] ?? '').toString(),
                                  style: AppTypography.cardTitle,
                                ),
                                subtitle: Text(
                                  '${guide['category'] ?? 'Wellness'} • ${guide['readTime'] ?? '4 min read'}\n${guide['subtitle'] ?? ''}',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: const Icon(
                                  Icons.chevron_right_rounded,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                    if (_activeFilter == 'All' ||
                        _activeFilter == 'Nearby Safety') ...[
                      const SizedBox(height: 12),
                      const SakhiSectionHeader(
                        title: 'Verified Police Stations & Safety Resources',
                      ),
                      const SizedBox(height: 10),
                      if (_nearbyPoliceStations.isEmpty)
                        const _InlineEmptyResult(
                          text: 'No matching police stations were found.',
                        )
                      else
                        ..._nearbyPoliceStations.map(
                          (st) => Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: SakhiCard(
                              child: ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const CircleAvatar(
                                  backgroundColor: Color(0xFFE0F2FE),
                                  child: Icon(
                                    Icons.local_police_outlined,
                                    color: Color(0xFF0369A1),
                                  ),
                                ),
                                title: Text(
                                  (st['name'] ?? 'Police Station').toString(),
                                  style: AppTypography.cardTitle,
                                ),
                                subtitle: Text(
                                  '${st['address'] ?? ''} • Emergency: ${st['emergencyNumber'] ?? '112'}',
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SearchResultMemberProfileScreen extends StatefulWidget {
  const SearchResultMemberProfileScreen({super.key, required this.member});

  final FollowerUserModel member;

  @override
  State<SearchResultMemberProfileScreen> createState() =>
      _SearchResultMemberProfileScreenState();
}

class _SearchResultMemberProfileScreenState
    extends State<SearchResultMemberProfileScreen> {
  bool _updatingFollow = false;
  bool _loadingOverview = true;
  bool _followsMe = false;
  int _postsCount = 0;
  int _followersCount = 0;
  int _followingCount = 0;
  int _selectedProfileTab = 0; // 0: Posts, 1: Media, 2: About
  List<FeedPostModel> _memberPosts = const <FeedPostModel>[];

  @override
  void initState() {
    super.initState();
    _followsMe = widget.member.followsMe;
    _postsCount = widget.member.postsCount;
    _followersCount = widget.member.followersCount;
    _followingCount = widget.member.followingCount;
    unawaited(_loadProfileOverview());
  }

  Future<void> _loadProfileOverview() async {
    final state = SakhiPrototypeState.instance;
    final handleClean = widget.member.username
        .trim()
        .replaceFirst(RegExp(r'^@'), '')
        .toLowerCase();
    final localPosts = <FeedPostModel>[
      for (final p in [
        ...state.communityPosts,
        ...state.exploreRecommendedPosts,
      ])
        if ((widget.member.id.isNotEmpty &&
                p.authorAccountId == widget.member.id) ||
            (handleClean.isNotEmpty &&
                p.authorUsername
                        .trim()
                        .replaceFirst(RegExp(r'^@'), '')
                        .toLowerCase() ==
                    handleClean))
          p,
    ];
    final uniqueLocal = <String, FeedPostModel>{
      for (final p in localPosts) p.id: p,
    }.values.toList();

    final targetKey = widget.member.id.trim().isNotEmpty
        ? widget.member.id.trim()
        : widget.member.username.trim();
    final overview = targetKey.isNotEmpty
        ? await state.fetchTargetMemberProfileOverview(targetKey)
        : null;
    if (!mounted) return;

    if (overview != null) {
      final rawPosts = overview['posts'];
      final parsedPosts = rawPosts is List
          ? rawPosts
                .whereType<Map<String, dynamic>>()
                .map(FeedPostModel.fromJson)
                .toList()
          : uniqueLocal;
      setState(() {
        _loadingOverview = false;
        if (overview['isFollowing'] is bool) {
          widget.member.isFollowing = overview['isFollowing'] as bool;
        }
        _followsMe = overview['followsMe'] == true || widget.member.followsMe;
        _memberPosts = parsedPosts.isNotEmpty ? parsedPosts : uniqueLocal;
        _postsCount =
            (overview['postsCount'] as num?)?.toInt() ?? _memberPosts.length;
        _followersCount =
            (overview['followersCount'] as num?)?.toInt() ?? _followersCount;
        _followingCount =
            (overview['followingCount'] as num?)?.toInt() ?? _followingCount;
      });
    } else {
      setState(() {
        _loadingOverview = false;
        _memberPosts = uniqueLocal;
        if (_postsCount == 0) _postsCount = uniqueLocal.length;
      });
    }
  }

  Future<void> _toggleFollow() async {
    if (_updatingFollow || !widget.member.canFollow) return;
    setState(() => _updatingFollow = true);
    final succeeded = await SakhiPrototypeState.instance
        .toggleFollowSearchMember(widget.member);
    if (!mounted) return;
    setState(() {
      _updatingFollow = false;
      if (succeeded) {
        _followersCount =
            (_followersCount + (widget.member.isFollowing ? 1 : -1)).clamp(
              0,
              999999,
            );
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          succeeded
              ? (widget.member.isFollowing
                    ? 'You are now following ${widget.member.name}.'
                    : 'You unfollowed ${widget.member.name}.')
              : 'Follow could not be updated. No change was kept.',
        ),
      ),
    );
  }

  void _showMemberProfileOptionsSheet(
    BuildContext context,
    SakhiPrototypeState state,
  ) {
    final member = widget.member;
    final isBlocked = state.isUsernameBlocked(member.username);
    final isMuted = state.isUsernameMuted(member.username);
    final isRestricted = state.isUsernameRestricted(member.username);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.link_rounded, color: AppColors.primaryPurple),
              title: const Text('Copy Profile Link'),
              onTap: () {
                Navigator.pop(ctx);
                Clipboard.setData(
                  ClipboardData(
                    text: 'https://sakhi.app/u/${member.username.replaceFirst("@", "")}',
                  ),
                );
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Copied link for ${member.username}')),
                );
              },
            ),
            ListTile(
              leading: Icon(
                isMuted ? Icons.volume_up_outlined : Icons.volume_off_outlined,
                color: AppColors.primaryPurple,
              ),
              title: Text(
                isMuted ? 'Unmute ${member.name}' : 'Mute ${member.name}',
              ),
              subtitle: const Text('Hide their posts from your feed without blocking'),
              onTap: () async {
                Navigator.pop(ctx);
                final nowMuted = await state.toggleMuteUser(
                  username: member.username,
                  displayName: member.name,
                );
                if (!mounted || !context.mounted) return;
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      nowMuted
                          ? 'Muted ${member.username}.'
                          : 'Unmuted ${member.username}.',
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(
                isRestricted ? Icons.shield_outlined : Icons.privacy_tip_outlined,
                color: AppColors.primaryPurple,
              ),
              title: Text(
                isRestricted
                    ? 'Unrestrict ${member.name}'
                    : 'Restrict ${member.name}',
              ),
              subtitle: const Text(
                'Move their messages to Message Requests without notifying them',
              ),
              onTap: () async {
                Navigator.pop(ctx);
                final nowRestricted = await state.toggleRestrictUser(
                  username: member.username,
                  displayName: member.name,
                );
                if (!mounted || !context.mounted) return;
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      nowRestricted
                          ? 'Restricted ${member.username}.'
                          : 'Unrestricted ${member.username}.',
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.flag_outlined, color: AppColors.sosRed),
              title: Text('Report ${member.name}'),
              subtitle: const Text('Confidentially report impersonation, spam, or harassment'),
              onTap: () async {
                Navigator.pop(ctx);
                await state.reportUserOrPost(
                  targetHandle: member.username,
                  targetType: 'MEMBER',
                  category: 'SAFETY_CONCERN',
                  reason: 'Reported member profile from profile options',
                  authorDisplayName: member.name,
                );
                if (!mounted || !context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Confidential report submitted for ${member.username}.',
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(
                isBlocked ? Icons.lock_open_rounded : Icons.block_rounded,
                color: AppColors.sosRed,
              ),
              title: Text(
                isBlocked ? 'Unblock ${member.name}' : 'Block ${member.name}',
                style: const TextStyle(
                  color: AppColors.sosRed,
                  fontWeight: FontWeight.w700,
                ),
              ),
              onTap: () async {
                Navigator.pop(ctx);
                await state.toggleBlockedUser(
                  username: member.username,
                  displayName: member.name,
                );
                if (!mounted || !context.mounted) return;
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      state.isUsernameBlocked(member.username)
                          ? 'Blocked ${member.username}.'
                          : 'Unblocked ${member.username}.',
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _openConnections({required bool initialFollowing}) {
    final targetKey = widget.member.id.trim().isNotEmpty
        ? widget.member.id.trim()
        : widget.member.username.trim();
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => FollowersFollowingScreen(
          initialFollowing: initialFollowing,
          targetMemberId: targetKey,
          targetMemberName: widget.member.name,
          targetMemberUsername: widget.member.username,
          initialFollowersCount: _followersCount,
          initialFollowingCount: _followingCount,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final member = widget.member;
    final state = SakhiPrototypeState.instance;
    final businessUrl = (member.businessProfileUrl ?? '').trim();
    final interests = member.interests;
    final followLabel = member.isFollowing
        ? 'Following'
        : (_followsMe ? 'Follow Back' : '+ Follow');

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackground,
        title: Text(member.name, style: AppTypography.appBarTitle),
        actions: [
          IconButton(
            tooltip: 'Share Profile',
            icon: const Icon(Icons.share_outlined),
            onPressed: () {
              Clipboard.setData(
                ClipboardData(
                  text: 'https://sakhi.app/u/${member.username.replaceFirst("@", "")}',
                ),
              );
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Copied profile link for ${member.username}'),
                ),
              );
            },
          ),
          IconButton(
            tooltip: 'Member Safety & Profile Options',
            icon: const Icon(Icons.more_vert_rounded),
            onPressed: () => _showMemberProfileOptionsSheet(context, state),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadProfileOverview,
        color: AppColors.primaryPurple,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenPaddingH,
            12,
            AppSpacing.screenPaddingH,
            96,
          ),
          children: [
            SakhiCard(
              child: Column(
                children: [
                  const SizedBox(height: 8),
                  SakhiAvatar(
                    imageAsset: member.avatarAsset,
                    fallbackLabel: member.name,
                    size: 100,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Text(
                          member.name,
                          textAlign: TextAlign.center,
                          style: AppTypography.sectionTitle,
                        ),
                      ),
                      if (member.isVerified) ...[
                        const SizedBox(width: 6),
                        const Icon(
                          Icons.verified_rounded,
                          color: AppColors.primaryPurple,
                          size: 20,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    member.username,
                    style: AppTypography.subtitle,
                    textAlign: TextAlign.center,
                  ),
                  if (member.location.trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.location_on_outlined,
                          size: 14,
                          color: AppColors.primaryPurple,
                        ),
                        const SizedBox(width: 3),
                        Text(member.location, style: AppTypography.subtitle),
                      ],
                    ),
                  ],
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFAF5FC),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.borderSubtle),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _MemberStatItem(
                          count: '$_postsCount',
                          label: 'Posts',
                          onTap: () {},
                        ),
                        Container(
                          height: 26,
                          width: 1,
                          color: AppColors.dividerColor,
                        ),
                        _MemberStatItem(
                          count: '$_followersCount',
                          label: 'Followers',
                          onTap: () =>
                              _openConnections(initialFollowing: false),
                        ),
                        Container(
                          height: 26,
                          width: 1,
                          color: AppColors.dividerColor,
                        ),
                        _MemberStatItem(
                          count: '$_followingCount',
                          label: 'Following',
                          onTap: () => _openConnections(initialFollowing: true),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: member.canFollow
                            ? FilledButton(
                                onPressed: _updatingFollow
                                    ? null
                                    : _toggleFollow,
                                style: FilledButton.styleFrom(
                                  backgroundColor: member.isFollowing
                                      ? AppColors.pastelLavender
                                      : AppColors.primaryPurple,
                                  foregroundColor: member.isFollowing
                                      ? AppColors.primaryPurple
                                      : Colors.white,
                                ),
                                child: _updatingFollow
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : Text(
                                        followLabel,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                              )
                            : const OutlinedButton(
                                onPressed: null,
                                child: Text('Follow unavailable'),
                              ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: state.isUsernameBlocked(member.username)
                              ? null
                              : () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute<void>(
                                      builder: (_) =>
                                          SakhiDirectConversationScreen(
                                        peerId: member.id.isNotEmpty
                                            ? member.id
                                            : member.username,
                                        peerName: member.name,
                                        peerUsername: member.username,
                                        peerAvatar: member.avatarAsset,
                                      ),
                                    ),
                                  );
                                },
                          icon: const Icon(
                            Icons.chat_bubble_outline_rounded,
                            size: 16,
                          ),
                          label: Text(
                            member.isFollowing ? 'Message' : 'Message Request',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if ((member.bio ?? '').trim().isNotEmpty) ...[
              const SizedBox(height: 14),
              SakhiCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('About', style: AppTypography.sectionTitle),
                    const SizedBox(height: 8),
                    Text(member.bio!.trim(), style: AppTypography.bodyRegular),
                  ],
                ),
              ),
            ],
            if (interests.isNotEmpty) ...[
              const SizedBox(height: 14),
              SakhiCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Interests', style: AppTypography.sectionTitle),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: interests
                          .map((interest) => SakhiChip(label: interest))
                          .toList(),
                    ),
                  ],
                ),
              ),
            ],
            if (businessUrl.isNotEmpty) ...[
              const SizedBox(height: 14),
              SakhiCard(
                onTap: () {
                  final bizId = businessUrl
                      .replaceFirst('sakhi://business/', '')
                      .trim();
                  if (bizId.isNotEmpty) {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) =>
                            BusinessProfileDetailScreen(businessId: bizId),
                      ),
                    );
                  }
                },
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Linked Business Profile',
                            style: AppTypography.sectionTitle,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            (member.businessProfileName ?? '')
                                    .trim()
                                    .isNotEmpty
                                ? member.businessProfileName!
                                : 'Women-owned business',
                            style: AppTypography.cardTitle,
                          ),
                          if ((member.businessCategory ?? '')
                              .trim()
                              .isNotEmpty) ...[
                            const SizedBox(height: 3),
                            Text(
                              member.businessCategory!,
                              style: AppTypography.subtitle,
                            ),
                          ],
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right_rounded,
                      color: AppColors.primaryPurple,
                    ),
                  ],
                ),
              ),
            ],
            if (state.isUsernameBlocked(member.username)) ...[
              const SizedBox(height: 14),
              SakhiCard(
                child: Column(
                  children: [
                    const Icon(
                      Icons.block_rounded,
                      color: AppColors.sosRed,
                      size: 32,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'You have blocked ${member.name} (${member.username})',
                      style: AppTypography.cardTitle,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Their posts, comments, and direct messages are hidden from your account.',
                      textAlign: TextAlign.center,
                      style: AppTypography.subtitle,
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton(
                      onPressed: () async {
                        await state.toggleBlockedUser(
                          username: member.username,
                          displayName: member.name,
                        );
                        if (mounted) setState(() {});
                      },
                      child: const Text('Unblock Member'),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 18),
            Row(
              children: [
                ChoiceChip(
                  label: Text('Posts (${_memberPosts.length})'),
                  selected: _selectedProfileTab == 0,
                  onSelected: (_) => setState(() => _selectedProfileTab = 0),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: Text(
                    'Media (${_memberPosts.where((p) => (p.imageAsset ?? "").trim().isNotEmpty).length})',
                  ),
                  selected: _selectedProfileTab == 1,
                  onSelected: (_) => setState(() => _selectedProfileTab = 1),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (_loadingOverview)
              const Padding(
                padding: EdgeInsets.all(18),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_memberPosts.isEmpty)
              const SakhiEmptyState(
                icon: Icons.grid_on_outlined,
                title: 'No public posts yet',
                message: 'When this member shares posts visible to your account, they will appear here.',
              )
            else
              GridView.builder(
                padding: EdgeInsets.zero,
                  shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: (_selectedProfileTab == 1
                        ? _memberPosts
                            .where((p) => (p.imageAsset ?? '').trim().isNotEmpty)
                            .toList()
                        : _memberPosts)
                    .length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1,
                ),
                itemBuilder: (context, index) {
                  final visibleList = _selectedProfileTab == 1
                      ? _memberPosts
                          .where((p) => (p.imageAsset ?? '').trim().isNotEmpty)
                          .toList()
                      : _memberPosts;
                  final post = visibleList[index];
                  final source = post.imageAsset?.trim() ?? '';
                  return InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => showDialog<void>(
                      context: context,
                      builder: (dialogContext) => Dialog(
                        backgroundColor: Colors.transparent,
                        insetPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 24,
                        ),
                        child: AnimatedBuilder(
                          animation: state,
                          builder: (context, _) => SingleChildScrollView(
                            padding: const EdgeInsets.all(4),
                            child: FeedPostCard(
                              post: post,
                              showVerifiedCheck: true,
                              onLikeTap: () => state.togglePostLike(post),
                              onSaveTap: () => state.togglePostSaved(post),
                            ),
                          ),
                        ),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: source.isEmpty
                          ? Container(
                              padding: const EdgeInsets.all(9),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(0xFFFDF2F7),
                                    Color(0xFFF3E6FA),
                                  ],
                                ),
                                border: Border.all(
                                  color: AppColors.borderSubtle,
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    (post.categoryBadge ?? post.categorySlug)
                                        .replaceAll('_', ' '),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 8.5,
                                      fontWeight: FontWeight.w800,
                                      color: AppColors.primaryPurple,
                                    ),
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 4,
                                      ),
                                      child: Text(
                                        post.content,
                                        maxLines: 4,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 10.5,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '❤️ ${post.likesCount}  💬 ${post.commentsCount}',
                                    style: const TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : (source.startsWith('http://') ||
                                source.startsWith('https://') ||
                                source.startsWith('/api/v1/'))
                          ? SakhiRemoteMediaImage(source: source)
                          : Image.asset(source, fit: BoxFit.cover),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _MemberStatItem extends StatelessWidget {
  const _MemberStatItem({
    required this.count,
    required this.label,
    required this.onTap,
  });

  final String count;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        child: Column(
          children: [
            Text(
              count,
              style: AppTypography.sectionTitle.copyWith(fontSize: 17),
            ),
            const SizedBox(height: 2),
            Text(label, style: AppTypography.subtitle),
          ],
        ),
      ),
    );
  }
}

/// Live GPS-powered Active Circles Near You screen.
class NearbyCirclesScreen extends StatefulWidget {
  const NearbyCirclesScreen({super.key});

  @override
  State<NearbyCirclesScreen> createState() => _NearbyCirclesScreenState();
}

class _NearbyCirclesScreenState extends State<NearbyCirclesScreen> {
  bool _loading = true;
  double _selectedRadiusKm = 25;
  List<CommunityGroupModel> _circles = const <CommunityGroupModel>[];
  List<FollowerUserModel> _nearbyMembers = const <FollowerUserModel>[];
  String _locationLabel = 'Detecting your live location…';

  @override
  void initState() {
    super.initState();
    unawaited(_loadNearbyCircles());
  }

  Future<void> _loadNearbyCircles({bool requestGps = true}) async {
    setState(() => _loading = true);
    final safety = SakhiSafetyController.instance;
    if (requestGps && !safety.hasRecentDeviceLocation) {
      await safety.requestDeviceLocation();
    }
    final state = SakhiPrototypeState.instance;
    final res = await state.fetchNearbyCircles(
      lat: safety.hasRecentDeviceLocation ? safety.currentLatitude : null,
      lng: safety.hasRecentDeviceLocation ? safety.currentLongitude : null,
      radiusKm: _selectedRadiusKm,
      city: state.currentUser.location,
    );
    if (!mounted) return;

    final rawCircles = res?['activeCircles'] ?? res?['circles'];
    final parsedCircles = rawCircles is List
        ? rawCircles
              .whereType<Map<String, dynamic>>()
              .map(CommunityGroupModel.fromJson)
              .toList()
        : state.groups;

    final rawMembers = res?['nearbyMembers'];
    final parsedMembers = rawMembers is List
        ? rawMembers
              .whereType<Map<String, dynamic>>()
              .map(FollowerUserModel.fromJson)
              .toList()
        : state.followers;

    setState(() {
      _loading = false;
      _circles = parsedCircles;
      _nearbyMembers = parsedMembers;
      _locationLabel = safety.hasRecentDeviceLocation
          ? safety.currentLocationLabel
          : (state.currentUser.location.isNotEmpty
                ? state.currentUser.location
                : 'Your Sakhi Area');
    });
  }

  Future<void> _showCreateCircleSheet() async {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final created = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Create Local Sakhi Circle'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Circle Name *',
                hintText: 'e.g., Guntur Women Safety & Wellness Circle',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: descCtrl,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Description',
                hintText: 'Local support, safe commute updates & networking',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () async {
              final name = nameCtrl.text.trim();
              if (name.length < 3) return;
              await SakhiPrototypeState.instance.joinOrCreateCommunityCircle(
                name,
                description: descCtrl.text.trim().isNotEmpty
                    ? descCtrl.text.trim()
                    : 'Local verified Sakhi circle in $_locationLabel',
                category: 'Local Community',
              );
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('Create & Join'),
          ),
        ],
      ),
    );
    if (created == true && mounted) {
      await _loadNearbyCircles(requestGps: false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final safety = SakhiSafetyController.instance;
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: AppBar(
        backgroundColor: AppColors.scaffoldBackground,
        elevation: 0,
        title: const Text(
          'Active Circles Near You',
          style: AppTypography.appBarTitle,
        ),
        actions: [
          IconButton(
            tooltip: 'Create Circle',
            icon: const Icon(
              Icons.add_circle_outline_rounded,
              color: AppColors.primaryPurple,
            ),
            onPressed: _showCreateCircleSheet,
          ),
          IconButton(
            tooltip: 'Refresh GPS',
            icon: const Icon(
              Icons.my_location_rounded,
              color: AppColors.primaryPurple,
            ),
            onPressed: () => _loadNearbyCircles(requestGps: true),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => _loadNearbyCircles(requestGps: true),
        color: AppColors.primaryPurple,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.screenPaddingH,
            8,
            AppSpacing.screenPaddingH,
            96,
          ),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppColors.heroBannerGradient,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.borderSubtle),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.location_on_rounded,
                        color: AppColors.primaryPurple,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _locationLabel,
                          style: AppTypography.cardTitle,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    safety.hasRecentDeviceLocation
                        ? 'Live GPS active (${safety.currentLatitude.toStringAsFixed(4)}, ${safety.currentLongitude.toStringAsFixed(4)}) • Showing real database circles & verified members.'
                        : 'Enable device GPS to discover active Sakhi circles and verified women in your neighbourhood.',
                    style: AppTypography.subtitle,
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    children: [10.0, 25.0, 50.0].map((rad) {
                      final selected = _selectedRadiusKm == rad;
                      return ChoiceChip(
                        label: Text('Within ${rad.toInt()} km'),
                        selected: selected,
                        selectedColor: AppColors.primaryPurple,
                        labelStyle: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: selected
                              ? Colors.white
                              : AppColors.textPrimary,
                        ),
                        onSelected: (_) {
                          setState(() => _selectedRadiusKm = rad);
                          unawaited(_loadNearbyCircles(requestGps: false));
                        },
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SakhiSectionHeader(title: 'Active Circles (${_circles.length})'),
            const SizedBox(height: 10),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(20),
                child: SakhiQuoteLoader.inline(
                  statusLabel:
                      'Finding active Sakhi circles near your location…',
                ),
              )
            else if (_circles.isEmpty)
              SakhiEmptyState(
                icon: Icons.groups_outlined,
                title: 'No circles found in this radius yet',
                message: 'Try expanding the radius to 50 km or start the first verified Sakhi circle in your area.',
                actionLabel: '+ Create Local Circle',
                onAction: _showCreateCircleSheet,
              )
            else
              ..._circles.map(
                (group) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SakhiCard(
                    child: Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: AppColors.pastelLavender,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(
                            Icons.groups_rounded,
                            color: AppColors.primaryPurple,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(group.name, style: AppTypography.cardTitle),
                              const SizedBox(height: 3),
                              Text(
                                '${group.membersCount} verified member(s) • ${group.description}',
                                style: AppTypography.subtitle,
                              ),
                            ],
                          ),
                        ),
                        SakhiJoinCircleButton(circleName: group.name),
                      ],
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 18),
            SakhiSectionHeader(
              title: 'Verified Sakhi Members Nearby (${_nearbyMembers.length})',
            ),
            const SizedBox(height: 10),
            if (!_loading && _nearbyMembers.isEmpty)
              const _InlineEmptyResult(
                text: 'No public member profiles are currently sharing location in this area.',
              )
            else
              ..._nearbyMembers.map(
                (member) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SakhiCard(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: SakhiAvatar(
                        imageAsset: member.avatarAsset,
                        fallbackLabel: member.name,
                        size: 46,
                      ),
                      title: Row(
                        children: [
                          Flexible(
                            child: Text(
                              member.name,
                              style: AppTypography.cardTitle,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (member.isVerified) ...[
                            const SizedBox(width: 4),
                            const Icon(
                              Icons.verified_rounded,
                              size: 16,
                              color: AppColors.primaryPurple,
                            ),
                          ],
                        ],
                      ),
                      subtitle: Text('${member.username} • ${member.location}'),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) =>
                              SearchResultMemberProfileScreen(member: member),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _InlineEmptyResult extends StatelessWidget {
  const _InlineEmptyResult({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(text, style: AppTypography.subtitle),
    );
  }
}
