import 'package:flutter/material.dart';

import 'app_route_paths.dart';

import '../../features/account_security/screens/account_security_screen.dart';
import '../../features/business/screens/business_hub_screen.dart';
import '../../features/community/screens/community_screen.dart';
import '../../features/complaints/screens/complaint_submission_wizard_screen.dart';
import '../../features/complaints/screens/complaint_tracking_screens.dart';
import '../../features/complaints/screens/discreet_complaint_hub_screen.dart';
import '../../features/explore/screens/explore_screen.dart';
import '../../features/followers/screens/followers_following_screen.dart';
import '../../features/home/screens/home_screen.dart';
import '../../features/notifications/screens/messages_and_notifications_inbox_screens.dart';
import '../../features/notifications/screens/notification_preferences_screen.dart';
import '../../features/profile/screens/edit_profile_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/safety/screens/safety_screen.dart';
import '../../features/settings/screens/more_options_menu_screen.dart';
import '../../features/settings/screens/privacy_settings_screen.dart';
import '../../features/wellness/screens/menstrual_cycle_tracker_screen.dart';
import '../../features/wellness/screens/wellness_screen.dart';
import 'app_navigation_shell.dart';

/// Centralized route definitions for Sakhi mobile screens (Modules 1–6).
class AppRoutes {
  AppRoutes._();

  static const String root = '/';
  static const String home = '/home';
  static const String explore = '/explore';
  static const String community = '/community';
  static const String wellness = '/wellness';
  static const String safety = '/safety';
  static const String profile = '/profile';
  static const String memberProfile = '/member-profile';
  static const String editProfile = '/edit-profile';
  static const String privacySettings = '/privacy-settings';
  static const String notificationPreferences = '/notification-preferences';
  static const String notificationsInbox = sakhiNotificationsInboxRoute;
  static const String messagesInbox = sakhiMessagesInboxRoute;
  static const String followers = '/followers';
  static const String following = '/following';
  static const String groups = '/groups';
  static const String myGroups = '/my-groups';
  static const String accountSecurity = '/account-security';
  static const String moreOptions = '/more-options';

  // Module 5: Discreet and Anonymous Complaint System Routes
  static const String discreetComplaintHub = '/discreet-complaints';
  static const String complaintWizard = '/complaint-wizard';
  static const String complaintTracker = '/complaint-tracker';
  static const String complaintTrackingLookup = '/complaint-tracking-lookup';
  static const String quickExitJournal = '/quick-exit-journal';

  // Module 6: Women-Owned Business Pages Routes (SRS Section 8)
  static const String businessHub = '/businesses';
  static const String businessCreate = '/businesses/create';
  static const String businessEnquiries = '/businesses/enquiries';

  // Module 7: Women's Menstrual Cycle Tracker Route (SRS Section 9)
  static const String menstrualCycleTracker = sakhiMenstrualCycleTrackerRoute;

  static Map<String, WidgetBuilder> get routes => {
    root: (_) => const AppNavigationShell(),
    home: (_) => const Scaffold(body: HomeScreen()),
    explore: (_) => const Scaffold(body: ExploreScreen()),
    community: (_) => const Scaffold(body: CommunityScreen()),
    wellness: (_) => const WellnessScreen(showBackButton: true),
    safety: (_) => const SafetyScreen(showBackButton: true),
    profile: (_) => const Scaffold(body: ProfileScreen()),
    memberProfile: (_) => const Scaffold(body: ProfileScreen()),
    editProfile: (_) => const EditProfileScreen(),
    privacySettings: (_) => const PrivacySettingsScreen(),
    notificationPreferences: (_) => const NotificationPreferencesScreen(),
    notificationsInbox: (_) => const SakhiNotificationsInboxScreen(),
    messagesInbox: (_) => const SakhiMessagesInboxScreen(),
    followers: (_) => const FollowersFollowingScreen(),
    following: (_) => const FollowersFollowingScreen(initialFollowing: true),
    groups: (_) => const Scaffold(body: ExploreScreen()),
    myGroups: (_) => const Scaffold(body: ExploreScreen()),
    accountSecurity: (_) => const AccountSecurityScreen(),
    moreOptions: (_) => const MoreOptionsMenuScreen(),
    discreetComplaintHub: (_) => const DiscreetComplaintHubScreen(),
    complaintWizard: (_) => const ComplaintSubmissionWizardScreen(),
    complaintTracker: (_) => const ComplaintTrackingLookupScreen(),
    complaintTrackingLookup: (_) => const ComplaintTrackingLookupScreen(),
    quickExitJournal: (_) => const QuickExitWellnessCamouflageScreen(),
    businessHub: (_) => const WomenBusinessHubScreen(showBackButton: true),
    businessCreate: (_) => const BusinessRegistrationWizardScreen(),
    businessEnquiries: (_) => const BusinessEnquiryInboxScreen(),
    menstrualCycleTracker: (_) => const MenstrualCycleTrackerScreen(),
  };
}
